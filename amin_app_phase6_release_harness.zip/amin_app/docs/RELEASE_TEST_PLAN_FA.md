# برنامه تست Release اندروید «امین»

## Quality gates خودکار

1. Flutter 3.47.5 stable
2. `flutter analyze --fatal-infos --fatal-warnings`
3. `flutter test`
4. `flutter build apk --release`
5. Integration smoke روی Android API 35 emulator
6. Probe سرعت موتور متن روی Android runtime
7. SHA-256 برای APK خروجی

## تست فیزیکی گوشی

برای ادعای «تست روی گوشی واقعی» باید APK روی یک دستگاه Android واقعی نصب شود. اسکریپت زیر cold-start، نسخه، حافظه و hash را ثبت می‌کند:

```bash
./tool/device_release_smoke.sh dist/Amin-0.5.0-build5.apk
```

سپس مسیر داوری متن، منبع، OCR، History و حالت Airplane به‌صورت دستی بررسی می‌شود.

## معیار پذیرش مسابقه

- Crash: صفر در مسیر 60 ثانیه‌ای داوری.
- متن: نتیجه نمونه مسابقه باید بدون اینترنت قابل تکرار باشد.
- Source Detail: مرجع و provenance قابل باز شدن باشد.
- History: پس از force-stop باقی بماند.
- OCR: نتیجه OCR قبل از منبع‌یابی قابل ویرایش باشد.
- فونت/RTL: overflow یا به‌هم‌ریختگی در مقیاس متن پیش‌فرض وجود نداشته باشد.
- APK: نصب با `adb install -r` موفق، package برابر `ir.amin.thaqalayn`.
