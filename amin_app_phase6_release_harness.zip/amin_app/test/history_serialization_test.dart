import 'package:amin_app/features/result/domain/verification_result.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('VerificationResult round-trips through JSON map', () {
    const VerificationResult original = VerificationResult(
      score: 87,
      matchLevel: MatchLevel.medium,
      statusTitle: 'متن مشابه یافت شد',
      summary: 'نمونه',
      sourceId: 'quran-2-153',
      sourceTitle: 'قرآن کریم',
      sourceReference: 'سوره بقره، آیه ۱۵۳',
      userText: 'ان الله الصابرین',
      sourceText: 'إِنَّ اللَّهَ مَعَ الصَّابِرِينَ',
      matchedSourceText: 'إِنَّ اللَّهَ مَعَ الصَّابِرِينَ',
      userDiffSegments: <DiffSegment>[
        DiffSegment(text: 'ان', type: DiffType.same),
        DiffSegment(text: 'الله', type: DiffType.same),
      ],
      sourceDiffSegments: <DiffSegment>[
        DiffSegment(text: 'إِنَّ', type: DiffType.same),
        DiffSegment(text: 'اللَّهَ', type: DiffType.same),
      ],
      tokenSimilarity: 80,
      characterSimilarity: 88,
      ngramSimilarity: 84,
      sequenceSimilarity: 82,
      relatedMatches: <RelatedMatch>[
        RelatedMatch(sourceId: 'quran-8-46', title: 'قرآن کریم', reference: 'سوره انفال، آیه ۴۶', score: 70),
      ],
    );

    final VerificationResult restored = VerificationResult.fromJson(original.toJson());

    expect(restored.score, 87);
    expect(restored.matchLevel, MatchLevel.medium);
    expect(restored.sourceId, 'quran-2-153');
    expect(restored.userDiffSegments.length, 2);
    expect(restored.relatedMatches.single.sourceId, 'quran-8-46');
  });
}
