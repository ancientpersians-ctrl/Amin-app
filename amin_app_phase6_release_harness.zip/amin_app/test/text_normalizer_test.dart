import 'package:amin_app/features/verification/domain/text_normalizer.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const TextNormalizer normalizer = TextNormalizer();

  test('normalizes Arabic diacritics and Persian/Arabic letter variants', () {
    expect(
      normalizer.normalize('إِنَّ اللَّهَ مَعَ الصَّابِرِينَ'),
      'ان الله مع الصابرین',
    );
  });

  test('joins standalone Arabic clitics used by some classical transcriptions', () {
    expect(normalizer.normalize('فَإِلَيْكَ أَفِرُّ، وَ مِنْكَ أَخَافُ، وَ بِكَ أَسْتَغِيثُ'), 'فالیک افر ومنک اخاف وبک استغیث');
  });

  test('normalizes punctuation and whitespace', () {
    expect(normalizer.normalize('  انّ  الله،  مع الصابرین! '), 'ان الله مع الصابرین');
  });
}
