import 'package:amin_app/app.dart';
import 'package:amin_app/features/history/data/memory_history_repository.dart';
import 'package:amin_app/features/verification/data/seed_source_repository.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Amin home renders after branded splash', (WidgetTester tester) async {
    final MemoryHistoryRepository historyRepository = MemoryHistoryRepository();
    await tester.pumpWidget(
      AminApp(
        repository: const SeedSourceRepository(),
        historyRepository: historyRepository,
      ),
    );
    await tester.pump(const Duration(milliseconds: 800));

    expect(find.text('امین'), findsWidgets);
    expect(find.text('اجرای نمونه واقعی'), findsOneWidget);

    await historyRepository.close();
  });
}
