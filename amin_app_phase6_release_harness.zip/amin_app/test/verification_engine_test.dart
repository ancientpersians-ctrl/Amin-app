import 'package:amin_app/features/result/domain/verification_result.dart';
import 'package:amin_app/features/verification/data/seed_source_repository.dart';
import 'package:amin_app/features/verification/domain/verification_engine.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const VerificationEngine engine = VerificationEngine(
    repository: SeedSourceRepository(),
  );

  test('finds exact Quran excerpt despite diacritics and Arabic/Persian variants', () async {
    final VerificationResult result = await engine.verify('ان الله مع الصابرین');
    expect(result.hasReliableMatch, isTrue);
    expect(result.sourceId, 'quran-2-153');
    expect(result.score, greaterThanOrEqualTo(97));
  });

  test('finds a one-word altered quote as a non-exact candidate', () async {
    final VerificationResult result = await engine.verify('الناس اعداء ما لا يعرفون');
    expect(result.score, lessThan(97));
  });

  test('returns no reliable source for unrelated text', () async {
    final VerificationResult result = await engine.verify('این یک جمله کاملا نامرتبط برای آزمون است');
    expect(result.hasReliableMatch, isFalse);
  });
}
