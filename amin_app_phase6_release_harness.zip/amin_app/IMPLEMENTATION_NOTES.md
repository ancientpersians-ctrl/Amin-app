# Amin Phase 3 — Corpus + Benchmark Implementation Notes

## مسیر واقعی اجرا

`TextCheckPage → AnalysisPage → VerificationEngine → DatabaseSourceRepository → SQLite indexed corpus → Similarity/Diff → ResultPage`

مسیر OCR نیز پس از استخراج و بازبینی متن وارد همین موتور می‌شود.

## Repository تولیدی

UI دیگر از `SeedSourceRepository` استفاده نمی‌کند. `main.dart` در شروع برنامه فایل SQLite نسخه‌دار را با `DatabaseSourceRepository.open()` باز می‌کند و همان Repository به کل Shell تزریق می‌شود.

`SeedSourceRepository` فقط برای Unit Test باقی مانده است.

## Candidate Retrieval

برای هر Query:

1. `TextNormalizer` نسخه normalized و tokenها را می‌سازد.
2. `token_index` و `gram_index` کاندیداها را رتبه‌بندی می‌کنند.
3. حداکثر ۸ passage برای Scoring دقیق بارگیری می‌شود.
4. VerificationEngine روی Candidateها چهار سیگنال شباهت را محاسبه می‌کند.

این معماری Full Scan روی ۶۳۱۷ passage را در هر درخواست حذف می‌کند.

## Similarity signals

Score نهایی:

- 30% Query coverage
- 20% Token Jaccard
- 25% Character Levenshtein similarity
- 15% Character bigram Dice
- 10% Token-order LCS similarity

برای تفاوت‌های محدود رسم‌الخط Uthmani / تایپ عادی، یک guarded orthographic skeleton فقط برای equivalence check استفاده می‌شود. متن منبع هرگز با این کلید جایگزین نمی‌شود.

## آستانه‌ها

آستانه پذیرش دیگر حدس مهندسی نیست. روی Dev split Benchmark v1 کالیبره و Freeze شده است:

- acceptance: `0.63`
- high: `0.85`
- direct/equivalent UI label: `0.985`
- candidate limit: `8`

منبع اعداد: `benchmark/BENCHMARK_REPORT.md`

## Data integrity

- SQLite `PRAGMA quick_check` در Runtime
- 114 سوره / 6236 آیه به‌عنوان شرط سخت Build
- passage IDs یکتا
- normalized text غیرخالی
- SHA-256 هر passage و کل DB
- نسخه و provenance هر Source در جدول `sources`

## Corpus coverage

- Quran: complete, 6236 ayahs
- Nahj al-Balagha: 55 verified selected passages
- Sahifa Sajjadiya: 26 verified selected passages

هیچ ادعای پوشش کامل نهج و صحیفه در Corpus v1 وجود ندارد.

## Benchmark

دو لایه دارد:

- 720 مورد reproducible synthetic+curated با Dev/Test تفکیک‌شده
- 55 مورد دستی Frozen که در Calibration استفاده نشده‌اند

نتایج فعلی در `benchmark/BENCHMARK_REPORT.md` ثبت شده است.

## محدودیت محیط Build

Flutter/Dart SDK در محیط تولید این بسته نصب نیست؛ بنابراین Compile نهایی Flutter هنوز باید در محیط Flutter واقعی اجرا شود. در مقابل، Build/Integrity پایگاه SQLite و Python reference benchmark در همین محیط اجرا و نتیجه Freeze شده‌اند.

## Phase 4 — Source detail, full-corpus search, validation UI, OCR evidence

- `SourcesPage` now searches the full 6,317-passage SQLite corpus through `token_index` plus contiguous normalized phrase preference, with Quran/Nahj/Sahifa filters.
- `SourceDetailPage` displays the untouched source text, exact reference, edition/version, attribution/license, provenance locator, and previous/next passage navigation.
- `ResultPage` and related-match cards now deep-link into `SourceDetailPage` using the passage ID returned by the verification engine.
- `DataValidationPage` reads packaged machine-readable release, benchmark, challenge-set, and OCR reports so the judge can inspect corpus coverage, SHA-256, validation checks, source-retrieval metrics, and limitations inside the app.
- OCR preprocessing is intentionally **adaptive**, not always-on. The controlled real-Tesseract benchmark showed that fixed grayscale/contrast/upscale and fixed thresholding degraded average transcription. Amin first OCRs the raw crop and only invokes two fallback preprocessing variants when the Arabic-text quality heuristic is below `0.85`.
- OCR benchmark evidence is stored under `benchmark/ocr_*` and summarized in `benchmark/OCR_BENCHMARK_REPORT.md`. The mandatory OCR review/edit screen remains part of the product because Quran OCR is materially weaker than the text-verification engine.


## Phase 5 — Persistent history and competition release preparation

### History

- User verification history is stored in a **separate writable SQLite database** (`amin_user_data.sqlite3`), never inside the read-only source corpus.
- Stored snapshot includes input type (`text`/`image`), input text, score, match level, source identity, timestamp, complete serialized `VerificationResult`, diff segments, similarity metrics and related matches.
- `AnalysisPage` saves after the engine returns; a history write failure never blocks the primary Result page.
- `PRAGMA quick_check` is executed when the history store opens. If optional history storage fails, `main.dart` falls back to an in-memory session repository so verification remains usable.
- `HistoryPage` listens to repository revisions, persists across restarts, can reopen the saved Result snapshot, supports per-item deletion/swipe and clear-all confirmation.
- OCR history stores the **extracted/reviewed text result**, not a copied image file.

### About / Privacy / Guide

- About states product purpose, author identity, build/version/package, provenance link and the scientific limitation that text matching is not hadith-chain authentication.
- Privacy documents local processing, sandboxed SQLite history, no account/tracking/cloud requirement, image non-retention, permissions and user deletion controls.
- Guide explains text/image flows, mandatory OCR review and interpretation of match levels.

### Competition build identity

- Package: `ir.amin.thaqalayn`
- Version: `0.5.0+5`
- Author identity is injected at compile time with `AMIN_AUTHOR_NAME`; the competition build script refuses to run without it.
- Branding source assets live in `assets/branding/`; pre-generated Android resource bundles live in `build_support/android_branding/`.
- `tool/build_competition_android.sh` generates the Android platform scaffold using the **installed Flutter version**, applies package/manifest/icon/splash branding, runs `flutter analyze` + `flutter test`, builds a Release APK, and copies it to `dist/`.

### Judge delivery docs

- `docs/INSTALLATION_GUIDE_FA.md`
- `docs/JUDGING_60_SECOND_SCRIPT_FA.md`
- `docs/COMPETITION_RELEASE_CHECKLIST_FA.md`
