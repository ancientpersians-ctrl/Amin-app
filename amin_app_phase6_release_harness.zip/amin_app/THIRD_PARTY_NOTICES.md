# Third-party notices and data attribution

## Quran text

The bundled Quran corpus is built from the Uthmani text shipped with the LaTeX `quran` package (corpus build source version 2.3 in the current build environment).

Upstream package: CTAN `quran` / Seiied-Mohammad-Javad Razavian
Package license: LaTeX Project Public License 1.3c+

The quran package changelog states that its Quran text was updated to comply with Tanzil Quran Text v1.1. Tanzil requires source attribution and does not allow changing the Quran text itself. Amin preserves the original display text and applies normalization only in separate derived search fields.

Tanzil attribution for canonical Quran text compatibility:

Tanzil Quran Text — Copyright (C) 2007–2021 Tanzil Project — CC BY 3.0. Source: Tanzil Project.

## Nahj al-Balagha structured reference

External structured reference dataset: `aliahabeeb/nahj-al-balagha` on Hugging Face.

Dataset license: MIT.

The Amin corpus includes a curated selected subset labeled against the Muhammad Abduh edition; it does not claim complete coverage.

## Sahifa Sajjadiya transcription

Selected excerpts are frozen from Arabic Wikisource revision `oldid=591900` and retain a source locator per record.

Wikisource content attribution/share-alike requirements must be preserved in any redistribution of the transcription. The current project records the revision ID and attribution in the corpus manifest.

## Tesseract language data

`assets/tessdata/ara.traineddata` and `assets/tessdata/fas.traineddata` are Tesseract language data files from the `tessdata_fast` family.

Upstream project: `tesseract-ocr/tessdata_fast`
License: Apache License 2.0.

The Flutter wrapper dependency `tesseract_ocr` is distributed under its own license; consult package metadata and Flutter-generated dependency licenses for release builds.
