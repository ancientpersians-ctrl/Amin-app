# امین — Amin

اپلیکیشن موبایل راستی‌آزمایی متون قرآن و عترت؛ پروژه مسابقه «فناوری و تولیدات رسانه‌ای / نرم‌افزار کاربردی».

## وضعیت فعلی: Phase 5 — History + Competition Release Prep

مسیر اصلی دیگر Demo نیست:

`متن → Normalizer → SQLite Candidate Retrieval → Similarity Engine → Diff Engine → Result`

مسیر تصویر:

`دوربین/گالری → Tesseract OCR (ara+fas) → بازبینی متن → همان Verification Engine → Result`

## پایگاه واقعی منابع

فایل: `assets/data/amin_corpus.sqlite3`

- کل: **6317** passage
- قرآن کریم: **6236 آیه / 114 سوره — کامل**
- نهج‌البلاغه: **55 فراز منتخب مستند**
- صحیفه سجادیه: **26 فراز منتخب مستند**

نهج و صحیفه در Corpus v1 عمداً به‌عنوان `verified_subset` معرفی می‌شوند و برنامه ادعای پوشش کامل آن‌ها را ندارد.

شناسنامه کامل: [DATA_PROVENANCE.md](DATA_PROVENANCE.md)

## Benchmark قابل دفاع

Benchmark v1 دارای Dev/Test جدا و Challenge Set دستی مستقل است.

نتایج Test Frozen (480 case):

- Strict Precision: **99.50%**
- Strict Recall: **100.00%**
- Strict F1: **99.75%**
- False Positive Rate: **2.50%**
- Top-1 passage accuracy on positives: **100%**

Challenge Set دستی (55 case):

- Accuracy: **98.18%**
- Correct quotes: **19/19**
- Altered quotes: **17/18**
- Unrelated: **18/18**

گزارش و محدودیت‌ها: [benchmark/BENCHMARK_REPORT.md](benchmark/BENCHMARK_REPORT.md)

> این اعداد تطبیق و منبع‌یابی متن را می‌سنجند، نه صحت سند حدیث یا داوری رجالی/فقهی.

## آستانه Freeze شده

`VerificationPolicy.acceptanceThreshold = 0.63`

این مقدار فقط روی Dev انتخاب شده و Test Frozen برای گزارش نهایی نگه داشته شده است.

## معماری داده

SQLite جداول زیر را دارد:

- `sources` — نسخه، scope، license، attribution و provenance هر منبع
- `passages` — متن اصلی + normalized search field + hash
- `token_index` — retrieval واژه‌ای
- `gram_index` — retrieval مقاوم‌تر در برابر typo/OCR
- `meta` — نسخه corpus و counts

متن اصلی هرگز توسط Normalizer بازنویسی نمی‌شود؛ Normalization فقط برای search field است.

## اجرای توسعه

در محیط دارای Flutter Stable:

```bash
flutter create --platforms=android .
flutter pub get
flutter test
flutter run
```

## Build مسابقه‌ای Android

Package ID نهایی: `ir.amin.thaqalayn`  
Version: `0.5.0+5`

Build Release عمداً از یک اسکریپت reproducible انجام می‌شود تا Android scaffold با همان Flutter SDK موجود روی ماشین Build تولید شود و سپس Splash/Icon/Package ID اختصاصی امین روی آن اعمال شود:

```bash
export AMIN_AUTHOR_NAME="نام و نام خانوادگی صاحب اثر"
export AMIN_AUTHOR_AFFILIATION="نام دانشگاه / واحد"  # اختیاری
./tool/build_competition_android.sh
```

خروجی: `dist/Amin-0.5.0-build5.apk`

راهنمای کامل: `docs/INSTALLATION_GUIDE_FA.md`

### محدودیت محیط فعلی

Flutter SDK در محیطی که این بسته تولید شده نصب نیست؛ بنابراین APK Release در این محیط ساخته نشده است. اسکریپت Build قبل از خروجی نهایی، `flutter analyze` و `flutter test` را اجباری اجرا می‌کند. SQLite integrity check و Benchmarkهای Python/Tesseract در همین محیط اجرا شده‌اند.

## بازتولید Benchmark

در محیط دارای Python dependencies پروژه:

```bash
python tool/generate_benchmark.py
python tool/run_benchmark.py
python tool/build_challenge_set.py
python tool/run_challenge_set.py
```

برای مسابقه، فایل‌های Frozen داخل `benchmark/` را نگه دارید و Test Set را پس از گزارش نتیجه دستکاری نکنید.

## Phase 4 highlights

- Real search UI over all 6,317 corpus passages with source filters.
- Source Detail with provenance, edition/version, attribution/license, and adjacent-passage navigation.
- In-app **Data & Validation** screen exposing corpus coverage, release integrity checks, benchmark metrics and scientific limitations.
- Adaptive multi-pass Tesseract OCR: raw first, fallback preprocessing only for low-quality outputs.
- Executed OCR benchmark: 60 controlled images / 180 real OCR runs. Adaptive policy reached 78.33% Top-1 downstream source retrieval on this controlled set; see `benchmark/OCR_BENCHMARK_REPORT.md` for limitations.


## Phase 5 highlights

- History واقعی روی SQLite محلی با snapshot کامل `VerificationResult`، نوع ورودی (متن/تصویر)، تاریخ و منبع؛ حذف تکی و حذف کامل داخل UI.
- History بعد از restart باقی می‌ماند؛ در صورت خرابی Store اختیاری History، هسته راستی‌آزمایی با fallback session-only همچنان قابل استفاده است.
- صفحات کامل «درباره امین»، «حریم خصوصی و داده‌ها» و «راهنمای استفاده» اضافه شدند.
- نام صاحب اثر با `--dart-define=AMIN_AUTHOR_NAME=...` تزریق می‌شود و Build مسابقه‌ای بدون آن متوقف می‌شود.
- هویت Build نهایی: `ir.amin.thaqalayn`, version `0.5.0+5`.
- App Icon، Adaptive Icon، Native Android Splash و Flutter branded splash آماده شده‌اند.
- Build script سازگار با Flutter نصب‌شده، Android scaffold را تولید، branding را اعمال، analyze/test را اجرا و APK Release را در `dist/` آماده می‌کند.
- سناریوی داوری ۶۰ ثانیه‌ای و راهنمای نصب در `docs/` قرار دارند.
