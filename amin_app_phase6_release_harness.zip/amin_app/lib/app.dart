import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/theme/app_theme.dart';
import 'features/history/data/history_repository.dart';
import 'features/shell/presentation/main_shell.dart';
import 'features/splash/presentation/splash_gate.dart';
import 'features/verification/domain/source_models.dart';

class AminApp extends StatelessWidget {
  const AminApp({
    super.key,
    required this.repository,
    required this.historyRepository,
  });

  final SourceRepository repository;
  final HistoryRepository historyRepository;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'امین',
      locale: const Locale('fa'),
      supportedLocales: const <Locale>[
        Locale('fa'),
        Locale('ar'),
        Locale('en'),
      ],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.system,
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: SplashGate(
          child: MainShell(
            repository: repository,
            historyRepository: historyRepository,
          ),
        ),
      ),
    );
  }
}
