import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

class AminLogoMark extends StatelessWidget {
  const AminLogoMark({super.key, this.size = 44});

  final double size;

  @override
  Widget build(BuildContext context) {
    final bool dark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: size,
      height: size,
      padding: EdgeInsets.all(size * 0.10),
      decoration: BoxDecoration(
        color: dark
            ? AppColors.primary.withValues(alpha: 0.20)
            : AppColors.primary,
        borderRadius: BorderRadius.circular(size * 0.28),
      ),
      child: CustomPaint(
        painter: _AminLogoPainter(
          foreground: Colors.white,
          accent: dark ? AppColors.darkAccent : AppColors.accent,
        ),
      ),
    );
  }
}

class _AminLogoPainter extends CustomPainter {
  const _AminLogoPainter({required this.foreground, required this.accent});

  final Color foreground;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final Paint outline = Paint()
      ..color = foreground
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.075
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final Paint check = Paint()
      ..color = accent
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.10
      ..strokeCap = StrokeCap.square
      ..strokeJoin = StrokeJoin.round;

    final double w = size.width;
    final double h = size.height;
    final Path shield = Path()
      ..moveTo(w * 0.50, h * 0.13)
      ..lineTo(w * 0.79, h * 0.26)
      ..lineTo(w * 0.75, h * 0.53)
      ..lineTo(w * 0.50, h * 0.82)
      ..lineTo(w * 0.25, h * 0.53)
      ..lineTo(w * 0.21, h * 0.26)
      ..close();
    canvas.drawPath(shield, outline);

    final Path bookLeft = Path()
      ..moveTo(w * 0.50, h * 0.57)
      ..lineTo(w * 0.13, h * 0.53)
      ..lineTo(w * 0.13, h * 0.68)
      ..lineTo(w * 0.50, h * 0.74);
    final Path bookRight = Path()
      ..moveTo(w * 0.50, h * 0.57)
      ..lineTo(w * 0.87, h * 0.53)
      ..lineTo(w * 0.87, h * 0.68)
      ..lineTo(w * 0.50, h * 0.74);
    canvas.drawPath(bookLeft, outline);
    canvas.drawPath(bookRight, outline);

    final Path tick = Path()
      ..moveTo(w * 0.33, h * 0.44)
      ..lineTo(w * 0.45, h * 0.55)
      ..lineTo(w * 0.69, h * 0.34);
    canvas.drawPath(tick, check);
  }

  @override
  bool shouldRepaint(covariant _AminLogoPainter oldDelegate) =>
      oldDelegate.foreground != foreground || oldDelegate.accent != accent;
}
