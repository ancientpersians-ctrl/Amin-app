import 'package:flutter/material.dart';

abstract final class AppColors {
  // Light theme
  static const Color primary = Color(0xFF0C5D55);
  static const Color primaryContainer = Color(0xFFDDEFEA);
  static const Color accent = Color(0xFFC89B45);
  static const Color background = Color(0xFFF7F9F6);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color textPrimary = Color(0xFF17201E);
  static const Color textSecondary = Color(0xFF65716E);
  static const Color border = Color(0xFFE1E7E4);

  // Semantic
  static const Color success = Color(0xFF177A50);
  static const Color warning = Color(0xFFA76500);
  static const Color error = Color(0xFFB42318);
  static const Color info = Color(0xFF2457C5);

  // Diff highlighting
  static const Color diffAddedBackground = Color(0xFFFFF0DB);
  static const Color diffAddedForeground = Color(0xFF8F5200);
  static const Color diffRemovedBackground = Color(0xFFFFE4E2);
  static const Color diffRemovedForeground = Color(0xFF9B1C13);
  static const Color diffChangedBackground = Color(0xFFE7EDFF);
  static const Color diffChangedForeground = Color(0xFF2347A8);

  // Dark theme
  static const Color darkBackground = Color(0xFF101714);
  static const Color darkSurface = Color(0xFF17201D);
  static const Color darkPrimary = Color(0xFF79C9BD);
  static const Color darkAccent = Color(0xFFDDBB73);
  static const Color darkText = Color(0xFFEEF3F0);
}
