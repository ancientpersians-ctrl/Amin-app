abstract final class CompetitionConfig {
  static const String appName = 'امین';
  static const String appSubtitle = 'راستی‌آزمای هوشمند قرآن و عترت';
  static const String tagline = 'هر نقل‌قول؛ تا منبع اصلی';

  static const String packageName = 'ir.amin.thaqalayn';
  static const String versionName = '0.5.0';
  static const int versionCode = 5;

  static const String authorName = String.fromEnvironment(
    'AMIN_AUTHOR_NAME',
    defaultValue: 'نام صاحب اثر',
  );

  static const String authorAffiliation = String.fromEnvironment(
    'AMIN_AUTHOR_AFFILIATION',
    defaultValue: '',
  );

  static const String authorContact = String.fromEnvironment(
    'AMIN_AUTHOR_CONTACT',
    defaultValue: '',
  );

  static bool get hasReleaseAuthor =>
      authorName.trim().isNotEmpty && authorName != 'نام صاحب اثر';
}
