import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app.dart';
import 'features/history/data/history_repository.dart';
import 'features/history/data/memory_history_repository.dart';
import 'features/history/data/sqflite_history_repository.dart';
import 'features/verification/data/database_source_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations(<DeviceOrientation>[
    DeviceOrientation.portraitUp,
  ]);

  final DatabaseSourceRepository repository =
      await DatabaseSourceRepository.open();
  HistoryRepository historyRepository;
  try {
    historyRepository = await SqfliteHistoryRepository.open();
  } catch (_) {
    // The verification engine must remain usable even if the optional local
    // history store cannot be opened. This fallback is session-only.
    historyRepository = MemoryHistoryRepository();
  }

  runApp(
    AminApp(
      repository: repository,
      historyRepository: historyRepository,
    ),
  );
}
