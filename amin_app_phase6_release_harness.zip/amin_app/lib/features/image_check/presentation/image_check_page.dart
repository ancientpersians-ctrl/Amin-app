import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../history/data/history_repository.dart';
import '../../history/domain/history_entry.dart';
import '../../verification/domain/verification_engine.dart';
import '../../verification/presentation/text_check_page.dart';
import '../../verification/services/ocr_service.dart';

class ImageCheckPage extends StatefulWidget {
  const ImageCheckPage({
    super.key,
    required this.engine,
    required this.ocrService,
    required this.historyRepository,
  });

  final VerificationEngine engine;
  final OcrService ocrService;
  final HistoryRepository historyRepository;

  @override
  State<ImageCheckPage> createState() => _ImageCheckPageState();
}

class _ImageCheckPageState extends State<ImageCheckPage> {
  final ImagePicker _picker = ImagePicker();
  XFile? _image;
  String _extractedText = '';
  bool _busy = false;
  Object? _error;

  Future<void> _pick(ImageSource source) async {
    try {
      final XFile? image = await _picker.pickImage(
        source: source,
        imageQuality: 92,
        maxWidth: 2200,
      );
      if (image == null || !mounted) return;
      setState(() {
        _image = image;
        _busy = true;
        _error = null;
        _extractedText = '';
      });
      final String text = await widget.ocrService.extractText(image.path);
      if (!mounted) return;
      setState(() {
        _busy = false;
        _extractedText = text;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = error;
      });
    }
  }

  void _reviewText() {
    if (_extractedText.trim().isEmpty) return;
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => TextCheckPage(
          engine: widget.engine,
          initialText: _extractedText,
          historyRepository: widget.historyRepository,
          inputType: HistoryInputType.image,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('بررسی تصویر')),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.xl),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text('تصویر حاوی نقل‌قول را انتخاب کنید.', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: AppSpacing.xs),
                Text(
                  'OCR به‌صورت محلی اجرا می‌شود. امین ابتدا تصویر اصلی را می‌خواند و فقط در خروجی‌های کم‌کیفیت، پیش‌پردازش جایگزین را امتحان می‌کند؛ متن استخراج‌شده همیشه قبل از راستی‌آزمایی قابل ویرایش است.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: AppSpacing.lg),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _busy ? null : () => _pick(ImageSource.camera),
                        icon: const Icon(Icons.camera_alt_outlined),
                        label: const Text('گرفتن عکس'),
                      ),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _busy ? null : () => _pick(ImageSource.gallery),
                        icon: const Icon(Icons.photo_library_outlined),
                        label: const Text('گالری'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.lg),
                if (_image != null)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(AppRadius.lg),
                    child: Image.file(
                      File(_image!.path),
                      height: 240,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const SizedBox(height: 180, child: Center(child: Icon(Icons.broken_image_outlined))),
                    ),
                  ),
                if (_busy) ...<Widget>[
                  const SizedBox(height: AppSpacing.xl),
                  const Center(child: CircularProgressIndicator()),
                  const SizedBox(height: AppSpacing.sm),
                  Center(child: Text('در حال استخراج متن…', style: Theme.of(context).textTheme.bodyMedium)),
                ],
                if (_error != null) ...<Widget>[
                  const SizedBox(height: AppSpacing.lg),
                  Container(
                    padding: const EdgeInsets.all(AppSpacing.md),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.errorContainer,
                      borderRadius: BorderRadius.circular(AppRadius.md),
                    ),
                    child: Text('استخراج متن انجام نشد. تنظیمات OCR و فایل‌های زبان را بررسی کنید.\n$_error'),
                  ),
                ],
                if (_extractedText.isNotEmpty) ...<Widget>[
                  const SizedBox(height: AppSpacing.lg),
                  Text('متن استخراج‌شده', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: AppSpacing.sm),
                  Container(
                    padding: const EdgeInsets.all(AppSpacing.md),
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(AppRadius.md),
                      border: Border.all(color: Theme.of(context).dividerColor),
                    ),
                    child: Text(_extractedText, style: Theme.of(context).textTheme.bodyLarge),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  FilledButton.icon(
                    onPressed: _reviewText,
                    icon: const Icon(Icons.edit_note_rounded),
                    label: const Text('بازبینی متن و بررسی منبع'),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
