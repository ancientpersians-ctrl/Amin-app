import 'package:flutter/material.dart';

import '../../history/data/history_repository.dart';
import '../../history/presentation/history_page.dart';
import '../../home/presentation/home_page.dart';
import '../../more/presentation/more_page.dart';
import '../../sources/presentation/sources_page.dart';
import '../../verification/domain/source_models.dart';
import '../../verification/domain/verification_engine.dart';

class MainShell extends StatefulWidget {
  const MainShell({
    super.key,
    required this.repository,
    required this.historyRepository,
  });

  final SourceRepository repository;
  final HistoryRepository historyRepository;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _currentIndex = 0;
  late final VerificationEngine _engine;
  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _engine = VerificationEngine(repository: widget.repository);
    _pages = <Widget>[
      HomePage(
        engine: _engine,
        repository: widget.repository,
        historyRepository: widget.historyRepository,
      ),
      SourcesPage(repository: widget.repository),
      HistoryPage(
        historyRepository: widget.historyRepository,
        sourceRepository: widget.repository,
      ),
      const MorePage(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (int index) {
          setState(() => _currentIndex = index);
        },
        destinations: const <NavigationDestination>[
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'خانه',
          ),
          NavigationDestination(
            icon: Icon(Icons.menu_book_outlined),
            selectedIcon: Icon(Icons.menu_book_rounded),
            label: 'منابع',
          ),
          NavigationDestination(
            icon: Icon(Icons.history_outlined),
            selectedIcon: Icon(Icons.history_rounded),
            label: 'تاریخچه',
          ),
          NavigationDestination(
            icon: Icon(Icons.more_horiz),
            selectedIcon: Icon(Icons.more_rounded),
            label: 'بیشتر',
          ),
        ],
      ),
    );
  }
}
