import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/widgets/amin_logo_mark.dart';
import '../../../core/widgets/section_title.dart';
import '../../history/data/history_repository.dart';
import '../../history/domain/history_entry.dart';
import '../../image_check/presentation/image_check_page.dart';
import '../../verification/domain/source_models.dart';
import '../../verification/domain/verification_engine.dart';
import '../../verification/presentation/text_check_page.dart';
import '../../verification/services/ocr_service.dart';

class HomePage extends StatelessWidget {
  const HomePage({
    super.key,
    required this.engine,
    required this.repository,
    required this.historyRepository,
  });

  final VerificationEngine engine;
  final SourceRepository repository;
  final HistoryRepository historyRepository;

  static const OcrService _ocrService = TesseractOcrService();

  void _openTextCheck(BuildContext context, {String? initialText}) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => TextCheckPage(
          engine: engine,
          initialText: initialText,
          historyRepository: historyRepository,
          inputType: HistoryInputType.text,
        ),
      ),
    );
  }

  void _openImageCheck(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ImageCheckPage(
          engine: engine,
          ocrService: _ocrService,
          historyRepository: historyRepository,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;

    return SafeArea(
      child: CustomScrollView(
        slivers: <Widget>[
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(
              AppSpacing.lg,
              AppSpacing.lg,
              AppSpacing.lg,
              AppSpacing.xl,
            ),
            sliver: SliverList.list(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    const AminLogoMark(),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text('امین', style: Theme.of(context).textTheme.titleLarge),
                          Text('راستی‌آزمای هوشمند قرآن و عترت', style: Theme.of(context).textTheme.bodyMedium),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: 'تنظیمات',
                      onPressed: () {},
                      icon: const Icon(Icons.tune_rounded),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.xxl),
                _HeroCard(
                  onDemoPressed: () => _openTextCheck(
                    context,
                    initialText: 'ان الله الصابرین',
                  ),
                ),
                const SizedBox(height: AppSpacing.xl),
                const SectionTitle('بررسی جدید'),
                const SizedBox(height: AppSpacing.sm),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: _ActionCard(
                        icon: Icons.text_fields_rounded,
                        title: 'بررسی متن',
                        subtitle: 'یک آیه، روایت یا عبارت را وارد کنید.',
                        onTap: () => _openTextCheck(context),
                      ),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: _ActionCard(
                        icon: Icons.document_scanner_outlined,
                        title: 'بررسی تصویر',
                        subtitle: 'عکس یا اسکرین‌شات را با OCR تحلیل کنید.',
                        onTap: () => _openImageCheck(context),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.xl),
                SectionTitle(
                  'منابع فعال',
                  trailing: TextButton(
                    onPressed: () {},
                    child: const Text('مشاهده همه'),
                  ),
                ),
                const SizedBox(height: AppSpacing.sm),
                FutureBuilder<CorpusStats>(
                  future: repository.stats(),
                  builder: (BuildContext context, AsyncSnapshot<CorpusStats> snapshot) {
                    if (!snapshot.hasData) {
                      return const LinearProgressIndicator(minHeight: 3);
                    }
                    final CorpusStats stats = snapshot.data!;
                    return Wrap(
                      spacing: AppSpacing.xs,
                      runSpacing: AppSpacing.xs,
                      children: <Widget>[
                        _SourceChip(
                          label: 'قرآن • ${stats.countFor(SourceKind.quran)} آیه • کامل',
                          icon: Icons.auto_stories_outlined,
                          color: colors.primary,
                        ),
                        _SourceChip(
                          label: 'نهج‌البلاغه • ${stats.countFor(SourceKind.nahjAlBalagha)} گزیده مستند',
                          icon: Icons.menu_book_outlined,
                          color: AppColors.accent,
                        ),
                        _SourceChip(
                          label: 'صحیفه سجادیه • ${stats.countFor(SourceKind.sahifaSajjadiya)} گزیده مستند',
                          icon: Icons.volunteer_activism_outlined,
                          color: colors.secondary,
                        ),
                      ],
                    );
                  },
                ),
                const SizedBox(height: AppSpacing.xl),
                Container(
                  padding: const EdgeInsets.all(AppSpacing.md),
                  decoration: BoxDecoration(
                    color: colors.primaryContainer.withValues(alpha: 0.55),
                    borderRadius: BorderRadius.circular(AppRadius.md),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Icon(Icons.offline_bolt_outlined, color: colors.primary),
                      const SizedBox(width: AppSpacing.sm),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text('قابل استفاده بدون اینترنت', style: Theme.of(context).textTheme.labelLarge),
                            const SizedBox(height: AppSpacing.xxs),
                            Text(
                              'هسته تطبیق، پایگاه نسخه‌دار منابع و OCR عربی/فارسی روی خود دستگاه اجرا می‌شوند.',
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.onDemoPressed});

  final VoidCallback onDemoPressed;

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(AppSpacing.xl),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: <Color>[colors.primary, colors.primary.withValues(alpha: 0.82)],
        ),
        borderRadius: BorderRadius.circular(AppRadius.lg),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: colors.primary.withValues(alpha: 0.18),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            'هر نقل‌قول؛ تا منبع اصلی',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: Colors.white),
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            'متن یا تصویر را وارد کنید تا نزدیک‌ترین منبع و میزان تطابق آن بررسی شود.',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Colors.white.withValues(alpha: 0.88)),
          ),
          const SizedBox(height: AppSpacing.lg),
          FilledButton.icon(
            onPressed: onDemoPressed,
            style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: colors.primary),
            icon: const Icon(Icons.play_arrow_rounded),
            label: const Text('اجرای نمونه واقعی'),
          ),
        ],
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppRadius.lg),
      child: Ink(
        padding: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(AppRadius.lg),
          border: Border.all(color: Theme.of(context).dividerColor),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.75),
                borderRadius: BorderRadius.circular(AppRadius.sm),
              ),
              child: Icon(icon, color: Theme.of(context).colorScheme.primary),
            ),
            const SizedBox(height: AppSpacing.md),
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: AppSpacing.xxs),
            Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
      ),
    );
  }
}

class _SourceChip extends StatelessWidget {
  const _SourceChip({required this.label, required this.icon, required this.color});

  final String label;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: AppSpacing.xs),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(AppRadius.pill),
        border: Border.all(color: color.withValues(alpha: 0.18)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, size: 18, color: color),
          const SizedBox(width: AppSpacing.xs),
          Text(label, style: Theme.of(context).textTheme.labelLarge?.copyWith(color: color)),
        ],
      ),
    );
  }
}
