import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../verification/domain/source_models.dart';

class SourceDetailPage extends StatelessWidget {
  const SourceDetailPage({
    super.key,
    required this.repository,
    required this.passageId,
  });

  final SourceRepository repository;
  final String passageId;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('جزئیات منبع')),
        body: FutureBuilder<SourcePassageDetail?>(
          future: repository.detailForPassage(passageId),
          builder: (BuildContext context, AsyncSnapshot<SourcePassageDetail?> snapshot) {
            if (snapshot.hasError) {
              return _MessageState(
                icon: Icons.error_outline_rounded,
                title: 'نمایش منبع انجام نشد',
                message: snapshot.error.toString(),
              );
            }
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            final SourcePassageDetail? detail = snapshot.data;
            if (detail == null) {
              return const _MessageState(
                icon: Icons.search_off_rounded,
                title: 'مدخل پیدا نشد',
                message: 'این شناسه در نسخه فعلی پایگاه منابع وجود ندارد.',
              );
            }
            return _DetailBody(detail: detail, repository: repository);
          },
        ),
      ),
    );
  }
}

class _DetailBody extends StatelessWidget {
  const _DetailBody({required this.detail, required this.repository});

  final SourcePassageDetail detail;
  final SourceRepository repository;

  @override
  Widget build(BuildContext context) {
    final SourcePassage passage = detail.passage;
    final SourceMetadata source = detail.source;
    return ListView(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.lg,
        AppSpacing.sm,
        AppSpacing.lg,
        AppSpacing.xxxl,
      ),
      children: <Widget>[
        Wrap(
          spacing: AppSpacing.xs,
          runSpacing: AppSpacing.xs,
          children: <Widget>[
            Chip(
              avatar: Icon(_kindIcon(passage.kind), size: 18),
              label: Text(sourceKindLabel(passage.kind)),
            ),
            Chip(
              avatar: Icon(source.isComplete ? Icons.verified_rounded : Icons.fact_check_outlined, size: 18),
              label: Text(source.isComplete ? 'پوشش کامل' : 'گزیده مستند'),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.md),
        Text(passage.sourceTitle, style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: AppSpacing.xs),
        Text(
          passage.reference,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Theme.of(context).colorScheme.primary,
              ),
        ),
        if (passage.sectionTitle != null) ...<Widget>[
          const SizedBox(height: AppSpacing.xxs),
          Text(passage.sectionTitle!, style: Theme.of(context).textTheme.bodyMedium),
        ],
        const SizedBox(height: AppSpacing.xl),
        Container(
          padding: const EdgeInsets.all(AppSpacing.xl),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(AppRadius.lg),
            border: Border.all(color: Theme.of(context).dividerColor),
          ),
          child: SelectableText(
            passage.text,
            textAlign: TextAlign.right,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  height: 2.0,
                  fontWeight: FontWeight.w600,
                ),
          ),
        ),
        const SizedBox(height: AppSpacing.sm),
        OutlinedButton.icon(
          onPressed: () async {
            await Clipboard.setData(ClipboardData(text: passage.text));
            if (!context.mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('متن منبع کپی شد.')),
            );
          },
          icon: const Icon(Icons.copy_rounded),
          label: const Text('کپی متن'),
        ),
        const SizedBox(height: AppSpacing.xl),
        Text('شناسنامه منبع', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: AppSpacing.sm),
        _InfoCard(
          children: <Widget>[
            _InfoRow(label: 'نسخه', value: source.version),
            if (source.edition?.isNotEmpty == true)
              _InfoRow(label: 'ویرایش / مأخذ', value: source.edition!),
            if (source.attribution?.isNotEmpty == true)
              _InfoRow(label: 'نسبت منبع', value: source.attribution!),
            if (source.license?.isNotEmpty == true)
              _InfoRow(label: 'مجوز داده', value: source.license!),
            if (source.retrievedAt?.isNotEmpty == true)
              _InfoRow(label: 'تاریخ دریافت', value: source.retrievedAt!),
            if (passage.metadata['provenance_locator'] case final String locator)
              _InfoRow(label: 'نشانی منشأ', value: locator),
          ],
        ),
        if (source.notes?.isNotEmpty == true) ...<Widget>[
          const SizedBox(height: AppSpacing.md),
          Container(
            padding: const EdgeInsets.all(AppSpacing.md),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.45),
              borderRadius: BorderRadius.circular(AppRadius.md),
            ),
            child: Text(source.notes!),
          ),
        ],
        const SizedBox(height: AppSpacing.xl),
        Row(
          children: <Widget>[
            Expanded(
              child: OutlinedButton.icon(
                onPressed: detail.previousPassage == null
                    ? null
                    : () => _openNeighbor(context, detail.previousPassage!),
                icon: const Icon(Icons.arrow_forward_rounded),
                label: const Text('مدخل قبلی'),
              ),
            ),
            const SizedBox(width: AppSpacing.sm),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: detail.nextPassage == null
                    ? null
                    : () => _openNeighbor(context, detail.nextPassage!),
                icon: const Icon(Icons.arrow_back_rounded),
                label: const Text('مدخل بعدی'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _openNeighbor(BuildContext context, SourcePassage passage) {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(
        builder: (_) => SourceDetailPage(
          repository: repository,
          passageId: passage.id,
        ),
      ),
    );
  }

  IconData _kindIcon(SourceKind kind) {
    return switch (kind) {
      SourceKind.quran => Icons.auto_stories_outlined,
      SourceKind.nahjAlBalagha => Icons.menu_book_outlined,
      SourceKind.sahifaSajjadiya => Icons.volunteer_activism_outlined,
      SourceKind.hadith => Icons.library_books_outlined,
    };
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(children: children),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            width: 92,
            child: Text(label, style: Theme.of(context).textTheme.labelMedium),
          ),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: SelectableText(value, style: Theme.of(context).textTheme.bodyMedium),
          ),
        ],
      ),
    );
  }
}

class _MessageState extends StatelessWidget {
  const _MessageState({required this.icon, required this.title, required this.message});

  final IconData icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 52),
            const SizedBox(height: AppSpacing.md),
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: AppSpacing.xs),
            Text(message, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
