import 'dart:async';

import 'package:flutter/material.dart';

import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../verification/domain/source_models.dart';
import '../../verification/domain/text_normalizer.dart';
import 'source_detail_page.dart';

class SourcesPage extends StatefulWidget {
  const SourcesPage({
    super.key,
    required this.repository,
  });

  final SourceRepository repository;

  @override
  State<SourcesPage> createState() => _SourcesPageState();
}

class _SourcesPageState extends State<SourcesPage> {
  final TextEditingController _controller = TextEditingController();
  final TextNormalizer _normalizer = const TextNormalizer();
  Timer? _debounce;
  SourceKind? _filter;
  bool _loading = false;
  Object? _error;
  List<SourceSearchResult> _results = const <SourceSearchResult>[];

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _scheduleSearch(String value) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 280), _search);
  }

  Future<void> _search() async {
    final String raw = _controller.text.trim();
    if (raw.isEmpty) {
      if (mounted) setState(() => _results = const <SourceSearchResult>[]);
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final String normalized = _normalizer.normalize(raw);
      final List<SourceSearchResult> results = await widget.repository.searchPassages(
        normalized,
        _normalizer.tokens(raw),
        kind: _filter,
        limit: 50,
      );
      if (!mounted) return;
      setState(() => _results = results);
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = error);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: CustomScrollView(
        slivers: <Widget>[
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(
              AppSpacing.lg,
              AppSpacing.lg,
              AppSpacing.lg,
              AppSpacing.xxxl,
            ),
            sliver: SliverList.list(
              children: <Widget>[
                Text('منابع', style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: AppSpacing.xs),
                const Text('جست‌وجوی مستقیم در کل پایگاه نسخه‌دار امین؛ متن اصلی مدخل‌ها در نتیجه نمایش داده می‌شود.'),
                const SizedBox(height: AppSpacing.lg),
                SearchBar(
                  controller: _controller,
                  hintText: 'عبارت یا واژه‌ای را جست‌وجو کنید…',
                  leading: const Icon(Icons.search_rounded),
                  trailing: <Widget>[
                    if (_controller.text.isNotEmpty)
                      IconButton(
                        tooltip: 'پاک‌کردن',
                        onPressed: () {
                          _controller.clear();
                          setState(() => _results = const <SourceSearchResult>[]);
                        },
                        icon: const Icon(Icons.close_rounded),
                      ),
                  ],
                  onChanged: (String value) {
                    setState(() {});
                    _scheduleSearch(value);
                  },
                  onSubmitted: (_) => _search(),
                ),
                const SizedBox(height: AppSpacing.sm),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: <Widget>[
                      _FilterChip(
                        label: 'همه',
                        selected: _filter == null,
                        onSelected: () => _setFilter(null),
                      ),
                      _FilterChip(
                        label: 'قرآن',
                        selected: _filter == SourceKind.quran,
                        onSelected: () => _setFilter(SourceKind.quran),
                      ),
                      _FilterChip(
                        label: 'نهج‌البلاغه',
                        selected: _filter == SourceKind.nahjAlBalagha,
                        onSelected: () => _setFilter(SourceKind.nahjAlBalagha),
                      ),
                      _FilterChip(
                        label: 'صحیفه',
                        selected: _filter == SourceKind.sahifaSajjadiya,
                        onSelected: () => _setFilter(SourceKind.sahifaSajjadiya),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
                if (_loading) const LinearProgressIndicator(minHeight: 3),
                if (_error != null) ...<Widget>[
                  const SizedBox(height: AppSpacing.md),
                  Text('جست‌وجو انجام نشد: $_error'),
                ] else if (_controller.text.trim().isNotEmpty) ...<Widget>[
                  const SizedBox(height: AppSpacing.xs),
                  Text(
                    _results.isEmpty ? 'نتیجه‌ای پیدا نشد.' : '${_results.length} نتیجه برتر',
                    style: Theme.of(context).textTheme.labelLarge,
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  ..._results.map(
                    (SourceSearchResult result) => Padding(
                      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                      child: _SearchResultCard(
                        result: result,
                        onTap: () => _openDetail(result.passage.id),
                      ),
                    ),
                  ),
                ] else ...<Widget>[
                  FutureBuilder<CorpusStats>(
                    future: widget.repository.stats(),
                    builder: (BuildContext context, AsyncSnapshot<CorpusStats> snapshot) {
                      if (snapshot.hasError) {
                        return Text('خواندن آمار پایگاه انجام نشد: ${snapshot.error}');
                      }
                      if (!snapshot.hasData) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      return _CorpusOverview(stats: snapshot.data!);
                    },
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _setFilter(SourceKind? kind) {
    setState(() => _filter = kind);
    if (_controller.text.trim().isNotEmpty) _search();
  }

  void _openDetail(String passageId) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SourceDetailPage(
          repository: widget.repository,
          passageId: passageId,
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({required this.label, required this.selected, required this.onSelected});

  final String label;
  final bool selected;
  final VoidCallback onSelected;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: AppSpacing.xs),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => onSelected(),
      ),
    );
  }
}

class _CorpusOverview extends StatelessWidget {
  const _CorpusOverview({required this.stats});

  final CorpusStats stats;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        const SizedBox(height: AppSpacing.md),
        Text(
          'پایگاه نسخه‌دار امین ${stats.totalPassages} مدخل دارد. قرآن کامل است؛ نهج‌البلاغه و صحیفه سجادیه در این نسخه گزیده‌های مستند هستند.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: AppSpacing.sm),
        Text('نسخه پایگاه: ${stats.corpusVersion}', style: Theme.of(context).textTheme.labelMedium),
        const SizedBox(height: AppSpacing.xl),
        ...stats.sources.map(
          (CorpusSourceStats source) => Padding(
            padding: const EdgeInsets.only(bottom: AppSpacing.sm),
            child: _SourceCountCard(
              icon: _iconFor(source.kind),
              title: source.title,
              subtitle: '${source.count} مدخل • ${source.isComplete ? 'پوشش کامل' : 'گزیده مستند'} • ${source.version}',
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.md),
        Container(
          padding: const EdgeInsets.all(AppSpacing.md),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.45),
            borderRadius: BorderRadius.circular(AppRadius.md),
          ),
          child: const Text(
            'متن اصلی هر مدخل برای نمایش دست‌نخورده نگهداری می‌شود. نسخه نرمال‌شده فقط برای جست‌وجو و مقایسه است.',
          ),
        ),
      ],
    );
  }

  static IconData _iconFor(SourceKind kind) {
    return switch (kind) {
      SourceKind.quran => Icons.auto_stories_outlined,
      SourceKind.nahjAlBalagha => Icons.menu_book_outlined,
      SourceKind.sahifaSajjadiya => Icons.volunteer_activism_outlined,
      SourceKind.hadith => Icons.library_books_outlined,
    };
  }
}

class _SearchResultCard extends StatelessWidget {
  const _SearchResultCard({required this.result, required this.onTap});

  final SourceSearchResult result;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final SourcePassage passage = result.passage;
    return Card(
      margin: EdgeInsets.zero,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.md),
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.md),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      '${passage.sourceTitle} • ${passage.reference}',
                      style: Theme.of(context).textTheme.labelLarge,
                    ),
                  ),
                  if (result.phraseMatch)
                    const Tooltip(
                      message: 'عبارت پیوسته در متن نرمال‌شده یافت شد',
                      child: Icon(Icons.verified_rounded, size: 20),
                    ),
                  const SizedBox(width: AppSpacing.xs),
                  const Icon(Icons.chevron_left_rounded),
                ],
              ),
              const SizedBox(height: AppSpacing.sm),
              Text(
                passage.text,
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.8),
              ),
              const SizedBox(height: AppSpacing.xs),
              Text(
                result.phraseMatch ? 'تطابق عبارتی' : '${result.tokenHits} واژه مشترک',
                style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      color: Theme.of(context).colorScheme.primary,
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SourceCountCard extends StatelessWidget {
  const _SourceCountCard({required this.icon, required this.title, required this.subtitle});

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(
        children: <Widget>[
          Icon(icon, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title, style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: AppSpacing.xxs),
                Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
