import 'package:flutter/foundation.dart';

import '../../result/domain/verification_result.dart';
import '../domain/history_entry.dart';

abstract interface class HistoryRepository {
  ValueListenable<int> get revision;

  Future<HistoryEntry> add({
    required HistoryInputType inputType,
    required VerificationResult result,
  });

  Future<List<HistoryEntry>> list({int limit = 100, int offset = 0});

  Future<int> count();

  Future<void> delete(int id);

  Future<void> clear();

  Future<void> close();
}
