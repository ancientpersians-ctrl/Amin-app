import 'package:flutter/foundation.dart';

import '../../result/domain/verification_result.dart';
import '../domain/history_entry.dart';
import 'history_repository.dart';

class MemoryHistoryRepository implements HistoryRepository {
  final ValueNotifier<int> _revision = ValueNotifier<int>(0);
  final List<HistoryEntry> _entries = <HistoryEntry>[];
  int _nextId = 1;

  @override
  ValueListenable<int> get revision => _revision;

  @override
  Future<HistoryEntry> add({
    required HistoryInputType inputType,
    required VerificationResult result,
  }) async {
    final HistoryEntry entry = HistoryEntry(
      id: _nextId++,
      createdAt: DateTime.now(),
      inputType: inputType,
      result: result,
    );
    _entries.insert(0, entry);
    _bump();
    return entry;
  }

  @override
  Future<List<HistoryEntry>> list({int limit = 100, int offset = 0}) async {
    final int safeOffset = offset.clamp(0, _entries.length).toInt();
    final int safeLimit = limit.clamp(1, 500).toInt();
    final int end = (safeOffset + safeLimit).clamp(safeOffset, _entries.length).toInt();
    return List<HistoryEntry>.unmodifiable(_entries.sublist(safeOffset, end));
  }

  @override
  Future<int> count() async => _entries.length;

  @override
  Future<void> delete(int id) async {
    _entries.removeWhere((HistoryEntry entry) => entry.id == id);
    _bump();
  }

  @override
  Future<void> clear() async {
    _entries.clear();
    _bump();
  }

  @override
  Future<void> close() async {
    _revision.dispose();
  }

  void _bump() => _revision.value = _revision.value + 1;
}
