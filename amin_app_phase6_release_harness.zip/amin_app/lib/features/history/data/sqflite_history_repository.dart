import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../../result/domain/verification_result.dart';
import '../domain/history_entry.dart';
import 'history_repository.dart';

class SqfliteHistoryRepository implements HistoryRepository {
  SqfliteHistoryRepository._(this._database);

  static const String _fileName = 'amin_user_data.sqlite3';
  static const int _schemaVersion = 1;

  final Database _database;
  final ValueNotifier<int> _revision = ValueNotifier<int>(0);

  @override
  ValueListenable<int> get revision => _revision;

  static Future<SqfliteHistoryRepository> open() async {
    final String directory = await getDatabasesPath();
    await Directory(directory).create(recursive: true);
    final String path = p.join(directory, _fileName);

    final Database database = await openDatabase(
      path,
      version: _schemaVersion,
      onCreate: (Database db, int version) async {
        await db.execute('''
          CREATE TABLE verification_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            input_type TEXT NOT NULL,
            input_text TEXT NOT NULL,
            score INTEGER NOT NULL,
            match_level TEXT NOT NULL,
            source_id TEXT,
            source_title TEXT,
            source_reference TEXT,
            result_json TEXT NOT NULL
          )
        ''');
        await db.execute(
          'CREATE INDEX idx_history_created_at ON verification_history(created_at DESC)',
        );
        await db.execute(
          'CREATE INDEX idx_history_source_id ON verification_history(source_id)',
        );
      },
    );

    final List<Map<String, Object?>> check = await database.rawQuery('PRAGMA quick_check');
    final Object? quickCheck = check.isEmpty ? null : check.first.values.first;
    if (quickCheck?.toString().toLowerCase() != 'ok') {
      await database.close();
      throw StateError('History database quick_check failed: $quickCheck');
    }

    return SqfliteHistoryRepository._(database);
  }

  @override
  Future<HistoryEntry> add({
    required HistoryInputType inputType,
    required VerificationResult result,
  }) async {
    final DateTime now = DateTime.now().toUtc();
    final int id = await _database.insert(
      'verification_history',
      <String, Object?>{
        'created_at': now.toIso8601String(),
        'input_type': historyInputTypeToStorage(inputType),
        'input_text': result.userText,
        'score': result.score,
        'match_level': result.matchLevel.name,
        'source_id': result.sourceId,
        'source_title': result.sourceTitle,
        'source_reference': result.sourceReference,
        'result_json': jsonEncode(result.toJson()),
      },
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
    _bumpRevision();
    return HistoryEntry(
      id: id,
      createdAt: now.toLocal(),
      inputType: inputType,
      result: result,
    );
  }

  @override
  Future<List<HistoryEntry>> list({int limit = 100, int offset = 0}) async {
    final List<Map<String, Object?>> rows = await _database.query(
      'verification_history',
      orderBy: 'created_at DESC, id DESC',
      limit: limit.clamp(1, 500).toInt(),
      offset: offset < 0 ? 0 : offset,
    );

    return rows.map(_entryFromRow).toList(growable: false);
  }

  @override
  Future<int> count() async {
    final List<Map<String, Object?>> rows = await _database.rawQuery(
      'SELECT COUNT(*) AS total FROM verification_history',
    );
    return (rows.first['total'] as num?)?.toInt() ?? 0;
  }

  @override
  Future<void> delete(int id) async {
    await _database.delete(
      'verification_history',
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
    _bumpRevision();
  }

  @override
  Future<void> clear() async {
    await _database.delete('verification_history');
    _bumpRevision();
  }

  @override
  Future<void> close() async {
    _revision.dispose();
    await _database.close();
  }

  HistoryEntry _entryFromRow(Map<String, Object?> row) {
    final String rawJson = row['result_json']! as String;
    final Map<String, Object?> json = Map<String, Object?>.from(
      jsonDecode(rawJson) as Map<String, dynamic>,
    );
    return HistoryEntry(
      id: (row['id']! as num).toInt(),
      createdAt: DateTime.parse(row['created_at']! as String).toLocal(),
      inputType: historyInputTypeFromStorage(row['input_type']! as String),
      result: VerificationResult.fromJson(json),
    );
  }

  void _bumpRevision() {
    _revision.value = _revision.value + 1;
  }
}
