import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../result/domain/verification_result.dart';
import '../../result/presentation/result_page.dart';
import '../../verification/domain/source_models.dart';
import '../data/history_repository.dart';
import '../domain/history_entry.dart';

class HistoryPage extends StatelessWidget {
  const HistoryPage({
    super.key,
    required this.historyRepository,
    required this.sourceRepository,
  });

  final HistoryRepository historyRepository;
  final SourceRepository sourceRepository;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ValueListenableBuilder<int>(
        valueListenable: historyRepository.revision,
        builder: (BuildContext context, int revision, Widget? child) {
          return FutureBuilder<List<HistoryEntry>>(
            key: ValueKey<int>(revision),
            future: historyRepository.list(limit: 200),
            builder: (BuildContext context, AsyncSnapshot<List<HistoryEntry>> snapshot) {
              final List<HistoryEntry> entries = snapshot.data ?? const <HistoryEntry>[];
              return CustomScrollView(
                slivers: <Widget>[
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(
                      AppSpacing.lg,
                      AppSpacing.lg,
                      AppSpacing.lg,
                      AppSpacing.sm,
                    ),
                    sliver: SliverToBoxAdapter(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text('تاریخچه', style: Theme.of(context).textTheme.headlineMedium),
                                const SizedBox(height: AppSpacing.xs),
                                Text(
                                  'بررسی‌ها فقط روی همین دستگاه ذخیره می‌شوند.',
                                  style: Theme.of(context).textTheme.bodyMedium,
                                ),
                              ],
                            ),
                          ),
                          if (entries.isNotEmpty)
                            TextButton.icon(
                              onPressed: () => _confirmClear(context),
                              icon: const Icon(Icons.delete_sweep_outlined),
                              label: const Text('پاک‌کردن همه'),
                            ),
                        ],
                      ),
                    ),
                  ),
                  if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData)
                    const SliverFillRemaining(
                      hasScrollBody: false,
                      child: Center(child: CircularProgressIndicator()),
                    )
                  else if (snapshot.hasError)
                    SliverFillRemaining(
                      hasScrollBody: false,
                      child: _HistoryMessage(
                        icon: Icons.error_outline_rounded,
                        title: 'تاریخچه خوانده نشد',
                        body: 'دوباره وارد این بخش شوید. داده‌های اصلی منابع تحت تأثیر قرار نگرفته‌اند.',
                      ),
                    )
                  else if (entries.isEmpty)
                    const SliverFillRemaining(
                      hasScrollBody: false,
                      child: _HistoryMessage(
                        icon: Icons.history_toggle_off_rounded,
                        title: 'هنوز بررسی‌ای ذخیره نشده',
                        body: 'بعد از اولین بررسی متن یا تصویر، نتیجه در این بخش ظاهر می‌شود.',
                      ),
                    )
                  else ...<Widget>[
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(
                        AppSpacing.lg,
                        AppSpacing.sm,
                        AppSpacing.lg,
                        AppSpacing.sm,
                      ),
                      sliver: SliverToBoxAdapter(
                        child: Text(
                          '${_toPersianDigits(entries.length.toString())} بررسی اخیر',
                          style: Theme.of(context).textTheme.labelLarge,
                        ),
                      ),
                    ),
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(
                        AppSpacing.lg,
                        0,
                        AppSpacing.lg,
                        AppSpacing.xxl,
                      ),
                      sliver: SliverList.separated(
                        itemCount: entries.length,
                        separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.sm),
                        itemBuilder: (BuildContext context, int index) {
                          final HistoryEntry entry = entries[index];
                          return Dismissible(
                            key: ValueKey<int>(entry.id),
                            direction: DismissDirection.endToStart,
                            confirmDismiss: (_) => _confirmDelete(context),
                            onDismissed: (_) => historyRepository.delete(entry.id),
                            background: Container(
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.errorContainer,
                                borderRadius: BorderRadius.circular(AppRadius.md),
                              ),
                              child: Icon(
                                Icons.delete_outline_rounded,
                                color: Theme.of(context).colorScheme.onErrorContainer,
                              ),
                            ),
                            child: _HistoryCard(
                              entry: entry,
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute<void>(
                                  builder: (_) => ResultPage(
                                    result: entry.result,
                                    repository: sourceRepository,
                                  ),
                                ),
                              ),
                              onDelete: () async {
                                final bool confirmed = await _confirmDelete(context);
                                if (confirmed) await historyRepository.delete(entry.id);
                              },
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ],
              );
            },
          );
        },
      ),
    );
  }

  Future<bool> _confirmDelete(BuildContext context) async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('حذف این بررسی؟'),
        content: const Text('فقط سابقه محلی این بررسی حذف می‌شود و منابع برنامه تغییر نمی‌کنند.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
        ],
      ),
    );
    return confirmed ?? false;
  }

  Future<void> _confirmClear(BuildContext context) async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('پاک‌کردن تاریخچه؟'),
        content: const Text('همه بررسی‌های ذخیره‌شده روی این دستگاه حذف می‌شوند. این کار قابل بازگشت نیست.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('پاک‌کردن همه')),
        ],
      ),
    );
    if (confirmed == true) await historyRepository.clear();
  }
}

class _HistoryCard extends StatelessWidget {
  const _HistoryCard({
    required this.entry,
    required this.onTap,
    required this.onDelete,
  });

  final HistoryEntry entry;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final VerificationResult result = entry.result;
    final Color statusColor = switch (result.matchLevel) {
      MatchLevel.exact || MatchLevel.high => AppColors.success,
      MatchLevel.medium => AppColors.warning,
      MatchLevel.low => AppColors.info,
    };

    return Material(
      color: Theme.of(context).cardColor,
      borderRadius: BorderRadius.circular(AppRadius.md),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.md),
        child: Container(
          padding: const EdgeInsets.all(AppSpacing.md),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppRadius.md),
            border: Border.all(color: Theme.of(context).dividerColor),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Container(
                    width: 54,
                    height: 54,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(AppRadius.md),
                    ),
                    child: Text(
                      '${_toPersianDigits(result.score.toString())}٪',
                      style: TextStyle(color: statusColor, fontWeight: FontWeight.w900),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          result.statusTitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: AppSpacing.xxs),
                        Text(
                          result.sourceTitle == null
                              ? 'بدون منبع پذیرفته‌شده'
                              : '${result.sourceTitle} • ${result.sourceReference}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                  PopupMenuButton<String>(
                    tooltip: 'گزینه‌ها',
                    onSelected: (String value) {
                      if (value == 'delete') onDelete();
                    },
                    itemBuilder: (_) => const <PopupMenuEntry<String>>[
                      PopupMenuItem<String>(value: 'delete', child: Text('حذف از تاریخچه')),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.sm),
              Text(
                result.userText,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.7),
              ),
              const SizedBox(height: AppSpacing.sm),
              Row(
                children: <Widget>[
                  _MiniChip(
                    icon: entry.inputType == HistoryInputType.image
                        ? Icons.image_outlined
                        : Icons.text_fields_rounded,
                    label: historyInputTypeLabel(entry.inputType),
                  ),
                  const SizedBox(width: AppSpacing.xs),
                  Expanded(
                    child: Text(
                      _formatDateTime(entry.createdAt),
                      textAlign: TextAlign.end,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MiniChip extends StatelessWidget {
  const _MiniChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: AppSpacing.xxs),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.65),
        borderRadius: BorderRadius.circular(AppRadius.pill),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, size: 15),
          const SizedBox(width: AppSpacing.xxs),
          Text(label, style: Theme.of(context).textTheme.labelMedium),
        ],
      ),
    );
  }
}

class _HistoryMessage extends StatelessWidget {
  const _HistoryMessage({
    required this.icon,
    required this.title,
    required this.body,
  });

  final IconData icon;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 58, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: AppSpacing.md),
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: AppSpacing.xs),
            Text(body, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
      ),
    );
  }
}

String _formatDateTime(DateTime value) {
  final String date = '${value.year.toString().padLeft(4, '0')}/${value.month.toString().padLeft(2, '0')}/${value.day.toString().padLeft(2, '0')}';
  final String time = '${value.hour.toString().padLeft(2, '0')}:${value.minute.toString().padLeft(2, '0')}';
  return _toPersianDigits('$date • $time');
}

String _toPersianDigits(String input) {
  const String latin = '0123456789';
  const String persian = '۰۱۲۳۴۵۶۷۸۹';
  var output = input;
  for (var index = 0; index < latin.length; index++) {
    output = output.replaceAll(latin[index], persian[index]);
  }
  return output;
}
