import '../../result/domain/verification_result.dart';

enum HistoryInputType { text, image }

String historyInputTypeToStorage(HistoryInputType type) => switch (type) {
      HistoryInputType.text => 'text',
      HistoryInputType.image => 'image',
    };

HistoryInputType historyInputTypeFromStorage(String value) => switch (value) {
      'image' => HistoryInputType.image,
      _ => HistoryInputType.text,
    };

String historyInputTypeLabel(HistoryInputType type) => switch (type) {
      HistoryInputType.text => 'متن',
      HistoryInputType.image => 'تصویر',
    };

class HistoryEntry {
  const HistoryEntry({
    required this.id,
    required this.createdAt,
    required this.inputType,
    required this.result,
  });

  final int id;
  final DateTime createdAt;
  final HistoryInputType inputType;
  final VerificationResult result;
}
