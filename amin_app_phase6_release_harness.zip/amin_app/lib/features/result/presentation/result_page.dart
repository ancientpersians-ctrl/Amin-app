import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/widgets/section_title.dart';
import '../../sources/presentation/source_detail_page.dart';
import '../../verification/domain/source_models.dart';
import '../domain/verification_result.dart';

class ResultPage extends StatefulWidget {
  const ResultPage({
    super.key,
    required this.result,
    required this.repository,
  });

  final VerificationResult result;
  final SourceRepository repository;

  @override
  State<ResultPage> createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  bool _showDiff = true;
  bool _whyExpanded = false;

  @override
  Widget build(BuildContext context) {
    final VerificationResult result = widget.result;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('نتیجه بررسی')),
        body: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.xxxl),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _ScoreCard(result: result),
              const SizedBox(height: AppSpacing.xl),
              if (result.hasReliableMatch) ...<Widget>[
                _ComparisonCard(
                  result: result,
                  showDiff: _showDiff,
                  onShowDiffChanged: (bool value) => setState(() => _showDiff = value),
                ),
                const SizedBox(height: AppSpacing.xl),
                _SourceCard(result: result, repository: widget.repository),
                const SizedBox(height: AppSpacing.xl),
              ] else ...<Widget>[
                const _NoMatchCard(),
                const SizedBox(height: AppSpacing.xl),
              ],
              _WhyResultCard(
                result: result,
                expanded: _whyExpanded,
                onPressed: () => setState(() => _whyExpanded = !_whyExpanded),
              ),
              if (result.relatedMatches.isNotEmpty) ...<Widget>[
                const SizedBox(height: AppSpacing.xl),
                const SectionTitle('منابع نزدیک دیگر'),
                const SizedBox(height: AppSpacing.sm),
                ...result.relatedMatches.map(
                  (RelatedMatch match) => Padding(
                    padding: const EdgeInsets.only(bottom: AppSpacing.xs),
                    child: _RelatedResultCard(match: match, repository: widget.repository),
                  ),
                ),
              ],
              if (result.hasReliableMatch) ...<Widget>[
                const SizedBox(height: AppSpacing.xl),
                FilledButton.icon(
                  onPressed: () => _showCitationPreview(context, result),
                  icon: const Icon(Icons.ios_share_rounded),
                  label: const Text('ساخت کارت استناد'),
                ),
              ],
              const SizedBox(height: AppSpacing.sm),
              OutlinedButton.icon(
                onPressed: () => Navigator.of(context).popUntil((Route<dynamic> route) => route.isFirst),
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('بررسی جدید'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showCitationPreview(BuildContext context, VerificationResult result) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (BuildContext context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Padding(
            padding: EdgeInsets.fromLTRB(
              AppSpacing.lg,
              AppSpacing.sm,
              AppSpacing.lg,
              MediaQuery.viewInsetsOf(context).bottom + AppSpacing.xl,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text('پیش‌نمایش کارت استناد', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: AppSpacing.md),
                Container(
                  padding: const EdgeInsets.all(AppSpacing.xl),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary,
                    borderRadius: BorderRadius.circular(AppRadius.lg),
                  ),
                  child: Column(
                    children: <Widget>[
                      const Icon(Icons.verified_user_outlined, color: Colors.white, size: 32),
                      const SizedBox(height: AppSpacing.sm),
                      const Text('امین', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
                      const SizedBox(height: AppSpacing.lg),
                      Text(
                        result.matchedSourceText ?? result.sourceText ?? '',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white, fontSize: 20, height: 1.9, fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: AppSpacing.lg),
                      Text(
                        '${result.sourceTitle} — ${result.sourceReference}',
                        style: TextStyle(color: Colors.white.withValues(alpha: 0.84)),
                      ),
                      const SizedBox(height: AppSpacing.xs),
                      Text('منبع یافت‌شده توسط امین', style: TextStyle(color: Colors.white.withValues(alpha: 0.68), fontSize: 12)),
                    ],
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
                FilledButton(onPressed: () => Navigator.pop(context), child: const Text('بستن پیش‌نمایش')),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ScoreCard extends StatelessWidget {
  const _ScoreCard({required this.result});

  final VerificationResult result;

  Color _statusColor() {
    return switch (result.matchLevel) {
      MatchLevel.exact || MatchLevel.high => AppColors.success,
      MatchLevel.medium => AppColors.warning,
      MatchLevel.low => AppColors.info,
    };
  }

  @override
  Widget build(BuildContext context) {
    final Color statusColor = _statusColor();
    return Container(
      padding: const EdgeInsets.all(AppSpacing.xl),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        children: <Widget>[
          TweenAnimationBuilder<double>(
            duration: const Duration(milliseconds: 700),
            curve: Curves.easeOutCubic,
            tween: Tween<double>(begin: 0, end: result.score.toDouble()),
            builder: (BuildContext context, double value, Widget? child) {
              return Text(
                '${value.round()}٪',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontSize: 38, color: statusColor),
              );
            },
          ),
          const SizedBox(height: AppSpacing.xs),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: AppSpacing.xxs),
            decoration: BoxDecoration(
              color: statusColor.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(AppRadius.pill),
            ),
            child: Text(result.statusTitle, style: TextStyle(color: statusColor, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(height: AppSpacing.md),
          Text(result.summary, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
          if (result.hasReliableMatch) ...<Widget>[
            const SizedBox(height: AppSpacing.md),
            const Divider(),
            const SizedBox(height: AppSpacing.sm),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const Icon(Icons.menu_book_outlined, size: 18),
                const SizedBox(width: AppSpacing.xs),
                Flexible(
                  child: Text(
                    '${result.sourceTitle} • ${result.sourceReference}',
                    style: Theme.of(context).textTheme.labelLarge,
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _ComparisonCard extends StatelessWidget {
  const _ComparisonCard({required this.result, required this.showDiff, required this.onShowDiffChanged});

  final VerificationResult result;
  final bool showDiff;
  final ValueChanged<bool> onShowDiffChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Row(
          children: <Widget>[
            const Expanded(child: SectionTitle('مقایسه متن')),
            SegmentedButton<bool>(
              segments: const <ButtonSegment<bool>>[
                ButtonSegment<bool>(value: false, label: Text('ساده')),
                ButtonSegment<bool>(value: true, label: Text('اختلاف‌ها')),
              ],
              selected: <bool>{showDiff},
              showSelectedIcon: false,
              onSelectionChanged: (Set<bool> values) => onShowDiffChanged(values.first),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.sm),
        _TextPanel(
          title: 'متن شما',
          child: showDiff
              ? _DiffText(segments: result.userDiffSegments)
              : Text(result.userText, style: Theme.of(context).textTheme.bodyLarge),
        ),
        const SizedBox(height: AppSpacing.sm),
        _TextPanel(
          title: 'بخش متناظر در منبع',
          child: showDiff
              ? _DiffText(segments: result.sourceDiffSegments)
              : Text(
                  result.matchedSourceText ?? result.sourceText ?? '',
                  textDirection: TextDirection.rtl,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(height: 2),
                ),
        ),
        if (showDiff) ...<Widget>[
          const SizedBox(height: AppSpacing.sm),
          const Wrap(
            spacing: AppSpacing.xs,
            runSpacing: AppSpacing.xs,
            children: <Widget>[
              _LegendPill(symbol: '+', label: 'افزوده در ورودی', color: AppColors.warning),
              _LegendPill(symbol: '−', label: 'حذف‌شده از ورودی', color: AppColors.error),
              _LegendPill(symbol: '≈', label: 'تغییر یافته', color: AppColors.info),
            ],
          ),
        ],
      ],
    );
  }
}

class _TextPanel extends StatelessWidget {
  const _TextPanel({required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(title, style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: AppSpacing.sm),
          child,
        ],
      ),
    );
  }
}

class _DiffText extends StatelessWidget {
  const _DiffText({required this.segments});

  final List<DiffSegment> segments;

  @override
  Widget build(BuildContext context) {
    return Text.rich(
      TextSpan(
        children: segments.map((DiffSegment segment) {
          final String prefix = switch (segment.type) {
            DiffType.added => '+ ',
            DiffType.removed => '− ',
            DiffType.changed => '≈ ',
            DiffType.same => '',
          };
          return TextSpan(
            text: '$prefix${segment.text} ',
            style: TextStyle(
              height: 1.9,
              fontSize: 16,
              fontWeight: segment.type == DiffType.same ? FontWeight.w500 : FontWeight.w700,
              color: segment.foregroundColor(context),
              backgroundColor: segment.backgroundColor(context),
              decoration: segment.type == DiffType.changed ? TextDecoration.underline : null,
            ),
          );
        }).toList(),
      ),
      textDirection: TextDirection.rtl,
    );
  }
}

class _LegendPill extends StatelessWidget {
  const _LegendPill({required this.symbol, required this.label, required this.color});

  final String symbol;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: AppSpacing.xs),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppRadius.pill),
        border: Border.all(color: color.withValues(alpha: 0.32)),
      ),
      child: Text('$symbol $label', style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 12)),
    );
  }
}

class _SourceCard extends StatelessWidget {
  const _SourceCard({required this.result, required this.repository});

  final VerificationResult result;
  final SourceRepository repository;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        const SectionTitle('مشخصات منبع'),
        const SizedBox(height: AppSpacing.sm),
        Container(
          padding: const EdgeInsets.all(AppSpacing.md),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(AppRadius.md),
            border: Border.all(color: Theme.of(context).dividerColor),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.7),
                      borderRadius: BorderRadius.circular(AppRadius.sm),
                    ),
                    child: Icon(Icons.menu_book_rounded, color: Theme.of(context).colorScheme.primary),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(result.sourceTitle ?? '', style: Theme.of(context).textTheme.titleMedium),
                        Text(result.sourceReference ?? '', style: Theme.of(context).textTheme.bodyMedium),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.md),
              Text(
                result.sourceText ?? '',
                textDirection: TextDirection.rtl,
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 2),
              ),
              const SizedBox(height: AppSpacing.sm),
              Text(
                'شناسه مدخل: ${result.sourceId}',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: AppSpacing.md),
              OutlinedButton.icon(
                onPressed: result.sourceId == null
                    ? null
                    : () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => SourceDetailPage(
                              repository: repository,
                              passageId: result.sourceId!,
                            ),
                          ),
                        ),
                icon: const Icon(Icons.open_in_new_rounded),
                label: const Text('مشاهده متن کامل و شناسنامه منبع'),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _NoMatchCard extends StatelessWidget {
  const _NoMatchCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(AppRadius.lg),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(Icons.manage_search_rounded, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Text(
              'نبودِ تطابق کافی در پایگاه فعلی، دلیل بر نادرست بودن عبارت نیست. بهتر است نگارش دیگری را امتحان کنید یا پس از تکمیل بانک منابع دوباره بررسی شود.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }
}

class _WhyResultCard extends StatelessWidget {
  const _WhyResultCard({required this.result, required this.expanded, required this.onPressed});

  final VerificationResult result;
  final bool expanded;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        children: <Widget>[
          ListTile(
            onTap: onPressed,
            leading: const Icon(Icons.info_outline_rounded),
            title: const Text('چرا این نتیجه پیشنهاد شده؟'),
            trailing: AnimatedRotation(
              duration: const Duration(milliseconds: 180),
              turns: expanded ? 0.5 : 0,
              child: const Icon(Icons.keyboard_arrow_down_rounded),
            ),
          ),
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 180),
            crossFadeState: expanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
            firstChild: const SizedBox.shrink(),
            secondChild: Padding(
              padding: const EdgeInsets.fromLTRB(AppSpacing.md, 0, AppSpacing.md, AppSpacing.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(
                    result.hasReliableMatch
                        ? 'اعراب و تفاوت‌های نگارشی ابتدا یکسان‌سازی شدند. سپس نزدیک‌ترین پنجره واژگانی هر منبع با چهار معیار مستقل مقایسه و بهترین نتیجه انتخاب شد.'
                        : 'عبارت با منابع فعلی مقایسه شد، اما امتیاز بهترین گزینه از آستانه نمایش منبع معتبر پایین‌تر بود.',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  if (result.hasReliableMatch) ...<Widget>[
                    const SizedBox(height: AppSpacing.md),
                    _MetricRow(label: 'شباهت واژگانی', value: result.tokenSimilarity),
                    const SizedBox(height: AppSpacing.xs),
                    _MetricRow(label: 'شباهت نویسه‌ای', value: result.characterSimilarity),
                    const SizedBox(height: AppSpacing.xs),
                    _MetricRow(label: 'شباهت دوحرفی', value: result.ngramSimilarity),
                    const SizedBox(height: AppSpacing.xs),
                    _MetricRow(label: 'شباهت توالی واژه‌ها', value: result.sequenceSimilarity),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricRow extends StatelessWidget {
  const _MetricRow({required this.label, required this.value});

  final String label;
  final int value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(child: Text(label)),
        const SizedBox(width: AppSpacing.md),
        Text('$value٪', style: Theme.of(context).textTheme.labelLarge),
      ],
    );
  }
}

class _RelatedResultCard extends StatelessWidget {
  const _RelatedResultCard({required this.match, required this.repository});

  final RelatedMatch match;
  final SourceRepository repository;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Theme.of(context).cardColor,
      borderRadius: BorderRadius.circular(AppRadius.md),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadius.md),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => SourceDetailPage(
              repository: repository,
              passageId: match.sourceId,
            ),
          ),
        ),
        child: Container(
          padding: const EdgeInsets.all(AppSpacing.md),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppRadius.md),
            border: Border.all(color: Theme.of(context).dividerColor),
          ),
          child: Row(
            children: <Widget>[
              Container(
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: AppSpacing.xs),
                decoration: BoxDecoration(
                  color: AppColors.info.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                ),
                child: Text('${match.score}٪', style: const TextStyle(color: AppColors.info, fontWeight: FontWeight.w800)),
              ),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(match.title, style: Theme.of(context).textTheme.labelLarge),
                    Text(match.reference, style: Theme.of(context).textTheme.bodyMedium),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left_rounded),
            ],
          ),
        ),
      ),
    );
  }
}
