import 'package:flutter/material.dart';

enum MatchLevel { exact, high, medium, low }

class RelatedMatch {
  const RelatedMatch({
    required this.sourceId,
    required this.title,
    required this.reference,
    required this.score,
  });

  final String sourceId;
  final String title;
  final String reference;
  final int score;

  Map<String, Object?> toJson() => <String, Object?>{
        'sourceId': sourceId,
        'title': title,
        'reference': reference,
        'score': score,
      };

  factory RelatedMatch.fromJson(Map<String, Object?> json) => RelatedMatch(
        sourceId: json['sourceId']! as String,
        title: json['title']! as String,
        reference: json['reference']! as String,
        score: (json['score']! as num).toInt(),
      );
}

class VerificationResult {
  const VerificationResult({
    required this.score,
    required this.matchLevel,
    required this.statusTitle,
    required this.summary,
    required this.sourceId,
    required this.sourceTitle,
    required this.sourceReference,
    required this.userText,
    required this.sourceText,
    required this.matchedSourceText,
    required this.userDiffSegments,
    required this.sourceDiffSegments,
    required this.tokenSimilarity,
    required this.characterSimilarity,
    required this.ngramSimilarity,
    required this.sequenceSimilarity,
    this.relatedMatches = const <RelatedMatch>[],
  });

  final int score;
  final MatchLevel matchLevel;
  final String statusTitle;
  final String summary;
  final String? sourceId;
  final String? sourceTitle;
  final String? sourceReference;
  final String userText;
  final String? sourceText;
  final String? matchedSourceText;
  final List<DiffSegment> userDiffSegments;
  final List<DiffSegment> sourceDiffSegments;
  final int tokenSimilarity;
  final int characterSimilarity;
  final int ngramSimilarity;
  final int sequenceSimilarity;
  final List<RelatedMatch> relatedMatches;

  bool get hasReliableMatch => matchLevel != MatchLevel.low && sourceId != null;

  Map<String, Object?> toJson() => <String, Object?>{
        'score': score,
        'matchLevel': matchLevel.name,
        'statusTitle': statusTitle,
        'summary': summary,
        'sourceId': sourceId,
        'sourceTitle': sourceTitle,
        'sourceReference': sourceReference,
        'userText': userText,
        'sourceText': sourceText,
        'matchedSourceText': matchedSourceText,
        'userDiffSegments': userDiffSegments.map((DiffSegment item) => item.toJson()).toList(growable: false),
        'sourceDiffSegments': sourceDiffSegments.map((DiffSegment item) => item.toJson()).toList(growable: false),
        'tokenSimilarity': tokenSimilarity,
        'characterSimilarity': characterSimilarity,
        'ngramSimilarity': ngramSimilarity,
        'sequenceSimilarity': sequenceSimilarity,
        'relatedMatches': relatedMatches.map((RelatedMatch item) => item.toJson()).toList(growable: false),
      };

  factory VerificationResult.fromJson(Map<String, Object?> json) {
    final String levelName = json['matchLevel']?.toString() ?? MatchLevel.low.name;
    final MatchLevel level = MatchLevel.values.firstWhere(
      (MatchLevel value) => value.name == levelName,
      orElse: () => MatchLevel.low,
    );
    final List<Object?> userSegments = (json['userDiffSegments'] as List<Object?>?) ?? const <Object?>[];
    final List<Object?> sourceSegments = (json['sourceDiffSegments'] as List<Object?>?) ?? const <Object?>[];
    final List<Object?> related = (json['relatedMatches'] as List<Object?>?) ?? const <Object?>[];
    return VerificationResult(
      score: (json['score'] as num?)?.toInt() ?? 0,
      matchLevel: level,
      statusTitle: json['statusTitle']?.toString() ?? 'نتیجه ذخیره‌شده',
      summary: json['summary']?.toString() ?? '',
      sourceId: json['sourceId'] as String?,
      sourceTitle: json['sourceTitle'] as String?,
      sourceReference: json['sourceReference'] as String?,
      userText: json['userText']?.toString() ?? '',
      sourceText: json['sourceText'] as String?,
      matchedSourceText: json['matchedSourceText'] as String?,
      userDiffSegments: userSegments
          .whereType<Map>()
          .map((Map item) => DiffSegment.fromJson(Map<String, Object?>.from(item)))
          .toList(growable: false),
      sourceDiffSegments: sourceSegments
          .whereType<Map>()
          .map((Map item) => DiffSegment.fromJson(Map<String, Object?>.from(item)))
          .toList(growable: false),
      tokenSimilarity: (json['tokenSimilarity'] as num?)?.toInt() ?? 0,
      characterSimilarity: (json['characterSimilarity'] as num?)?.toInt() ?? 0,
      ngramSimilarity: (json['ngramSimilarity'] as num?)?.toInt() ?? 0,
      sequenceSimilarity: (json['sequenceSimilarity'] as num?)?.toInt() ?? 0,
      relatedMatches: related
          .whereType<Map>()
          .map((Map item) => RelatedMatch.fromJson(Map<String, Object?>.from(item)))
          .toList(growable: false),
    );
  }

  factory VerificationResult.noMatch({
    required String userText,
    int score = 0,
    List<RelatedMatch> relatedMatches = const <RelatedMatch>[],
  }) {
    return VerificationResult(
      score: score,
      matchLevel: MatchLevel.low,
      statusTitle: 'منبع قابل اتکایی پیدا نشد',
      summary: 'امین نتوانست برای این عبارت در منابع فعلی تطابق کافی پیدا کند. این نتیجه به‌تنهایی به معنای نادرست بودن عبارت نیست.',
      sourceId: null,
      sourceTitle: null,
      sourceReference: null,
      userText: userText,
      sourceText: null,
      matchedSourceText: null,
      userDiffSegments: const <DiffSegment>[],
      sourceDiffSegments: const <DiffSegment>[],
      tokenSimilarity: 0,
      characterSimilarity: 0,
      ngramSimilarity: 0,
      sequenceSimilarity: 0,
      relatedMatches: relatedMatches,
    );
  }
}

enum DiffType { same, added, removed, changed }

class DiffSegment {
  const DiffSegment({required this.text, required this.type});

  final String text;
  final DiffType type;

  Map<String, Object?> toJson() => <String, Object?>{
        'text': text,
        'type': type.name,
      };

  factory DiffSegment.fromJson(Map<String, Object?> json) {
    final String typeName = json['type']?.toString() ?? DiffType.same.name;
    return DiffSegment(
      text: json['text']?.toString() ?? '',
      type: DiffType.values.firstWhere(
        (DiffType value) => value.name == typeName,
        orElse: () => DiffType.same,
      ),
    );
  }

  Color backgroundColor(BuildContext context) {
    final bool dark = Theme.of(context).brightness == Brightness.dark;
    return switch (type) {
      DiffType.same => Colors.transparent,
      DiffType.added => dark ? const Color(0xFF4A3520) : const Color(0xFFFFF0DB),
      DiffType.removed => dark ? const Color(0xFF4D2725) : const Color(0xFFFFE4E2),
      DiffType.changed => dark ? const Color(0xFF263557) : const Color(0xFFE7EDFF),
    };
  }

  Color foregroundColor(BuildContext context) {
    final bool dark = Theme.of(context).brightness == Brightness.dark;
    return switch (type) {
      DiffType.same => Theme.of(context).colorScheme.onSurface,
      DiffType.added => dark ? const Color(0xFFFFC86F) : const Color(0xFF8F5200),
      DiffType.removed => dark ? const Color(0xFFFF928A) : const Color(0xFF9B1C13),
      DiffType.changed => dark ? const Color(0xFFA9BBFF) : const Color(0xFF2347A8),
    };
  }
}
