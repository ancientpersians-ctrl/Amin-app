import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../history/data/history_repository.dart';
import '../../history/domain/history_entry.dart';
import '../domain/verification_engine.dart';
import 'analysis_page.dart';

class TextCheckPage extends StatefulWidget {
  const TextCheckPage({
    super.key,
    required this.engine,
    required this.historyRepository,
    this.inputType = HistoryInputType.text,
    this.initialText,
  });

  final VerificationEngine engine;
  final HistoryRepository historyRepository;
  final HistoryInputType inputType;
  final String? initialText;

  @override
  State<TextCheckPage> createState() => _TextCheckPageState();
}

class _TextCheckPageState extends State<TextCheckPage> {
  late final TextEditingController _controller;
  final FocusNode _focusNode = FocusNode();
  static const int _maxLength = 2000;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialText ?? '');
    _controller.addListener(_refresh);
  }

  @override
  void dispose() {
    _controller.removeListener(_refresh);
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _refresh() => setState(() {});

  Future<void> _paste() async {
    final ClipboardData? data = await Clipboard.getData(Clipboard.kTextPlain);
    if (!mounted || data?.text == null) return;
    _controller.text = data!.text!.substring(0, data.text!.length.clamp(0, _maxLength).toInt());
    _controller.selection = TextSelection.collapsed(offset: _controller.text.length);
  }

  void _useExample() {
    _controller.text = 'ان الله الصابرین';
    _controller.selection = TextSelection.collapsed(offset: _controller.text.length);
  }

  void _submit() {
    final String value = _controller.text.trim();
    if (value.length < 3) return;
    _focusNode.unfocus();
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => AnalysisPage(
          inputText: value,
          engine: widget.engine,
          historyRepository: widget.historyRepository,
          inputType: widget.inputType,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool canSubmit = _controller.text.trim().length >= 3;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('بررسی متن')),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.xl),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text('آیه، روایت یا عبارت موردنظر را وارد کنید.', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: AppSpacing.xs),
                Text(
                  'لازم نیست اعراب یا شکل نگارشی حروف دقیق باشد؛ امین آن‌ها را پیش از مقایسه یکسان‌سازی می‌کند.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: AppSpacing.lg),
                TextField(
                  controller: _controller,
                  focusNode: _focusNode,
                  minLines: 7,
                  maxLines: 10,
                  maxLength: _maxLength,
                  textDirection: TextDirection.rtl,
                  textAlignVertical: TextAlignVertical.top,
                  decoration: const InputDecoration(
                    hintText: 'متن را اینجا بنویسید یا جای‌گذاری کنید…',
                    alignLabelWithHint: true,
                  ),
                ),
                const SizedBox(height: AppSpacing.sm),
                Wrap(
                  spacing: AppSpacing.xs,
                  runSpacing: AppSpacing.xs,
                  children: <Widget>[
                    OutlinedButton.icon(onPressed: _paste, icon: const Icon(Icons.content_paste_rounded), label: const Text('چسباندن')),
                    OutlinedButton.icon(onPressed: _controller.text.isEmpty ? null : _controller.clear, icon: const Icon(Icons.delete_outline_rounded), label: const Text('پاک‌کردن')),
                    OutlinedButton.icon(onPressed: _useExample, icon: const Icon(Icons.auto_awesome_outlined), label: const Text('نمونه واقعی')),
                  ],
                ),
                const SizedBox(height: AppSpacing.lg),
                Container(
                  padding: const EdgeInsets.all(AppSpacing.md),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.45),
                    borderRadius: BorderRadius.circular(AppRadius.md),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Icon(Icons.info_outline_rounded, color: Theme.of(context).colorScheme.primary),
                      const SizedBox(width: AppSpacing.sm),
                      Expanded(
                        child: Text(
                          'پایگاه نسخه‌دار امین شامل قرآن کامل و مجموعه‌های منتخبِ مستند از نهج‌البلاغه و صحیفه سجادیه است. نتیجه فقط درباره منابع موجود در همین پایگاه گزارش می‌شود.',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: AppSpacing.xl),
                FilledButton.icon(
                  onPressed: canSubmit ? _submit : null,
                  icon: const Icon(Icons.verified_outlined),
                  label: const Text('بررسی منبع'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
