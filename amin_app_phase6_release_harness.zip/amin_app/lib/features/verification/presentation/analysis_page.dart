import 'package:flutter/material.dart';

import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../history/data/history_repository.dart';
import '../../history/domain/history_entry.dart';
import '../../result/domain/verification_result.dart';
import '../../result/presentation/result_page.dart';
import '../domain/verification_engine.dart';

class AnalysisPage extends StatefulWidget {
  const AnalysisPage({
    super.key,
    required this.inputText,
    required this.engine,
    required this.historyRepository,
    required this.inputType,
  });

  final String inputText;
  final VerificationEngine engine;
  final HistoryRepository historyRepository;
  final HistoryInputType inputType;

  @override
  State<AnalysisPage> createState() => _AnalysisPageState();
}

class _AnalysisPageState extends State<AnalysisPage> {
  int _step = 0;
  Object? _error;

  static const List<String> _steps = <String>[
    'آماده‌سازی متن',
    'یکسان‌سازی نگارش',
    'جست‌وجو در منابع',
    'مقایسه عبارت‌ها',
    'آماده‌سازی نتیجه',
  ];

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    try {
      for (var index = 0; index < 3; index++) {
        await Future<void>.delayed(const Duration(milliseconds: 120));
        if (!mounted) return;
        setState(() => _step = index + 1);
      }

      final VerificationResult result = await widget.engine.verify(widget.inputText);
      try {
        await widget.historyRepository.add(
          inputType: widget.inputType,
          result: result,
        );
      } catch (_) {
        // History is a convenience feature; a local storage failure must never
        // block the primary verification result.
      }
      if (!mounted) return;
      setState(() => _step = 5);
      await Future<void>.delayed(const Duration(milliseconds: 160));
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => ResultPage(result: result, repository: widget.engine.repository),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = error);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تحلیل عبارت')),
        body: Padding(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: _error == null ? _buildProgress(context) : _buildError(context),
        ),
      ),
    );
  }

  Widget _buildProgress(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        const SizedBox(height: AppSpacing.xl),
        Text('در حال بررسی منابع…', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: AppSpacing.xs),
        Text(
          'این مرحله روی داده‌های محلی برنامه انجام می‌شود.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: AppSpacing.xxl),
        Container(
          padding: const EdgeInsets.all(AppSpacing.lg),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(AppRadius.lg),
            border: Border.all(color: Theme.of(context).dividerColor),
          ),
          child: Column(
            children: List<Widget>.generate(_steps.length, (int index) {
              final bool done = index < _step;
              final bool active = index == _step && _step < _steps.length;
              return Padding(
                padding: EdgeInsets.only(bottom: index == _steps.length - 1 ? 0 : AppSpacing.md),
                child: Row(
                  children: <Widget>[
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 150),
                      child: done
                          ? Icon(Icons.check_circle_rounded, key: ValueKey('done-$index'), color: Theme.of(context).colorScheme.primary)
                          : active
                              ? SizedBox(
                                  key: ValueKey('active-$index'),
                                  width: 24,
                                  height: 24,
                                  child: CircularProgressIndicator(strokeWidth: 2.5, color: Theme.of(context).colorScheme.primary),
                                )
                              : Icon(Icons.radio_button_unchecked_rounded, key: ValueKey('idle-$index'), color: Theme.of(context).disabledColor),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: Text(
                        _steps[index],
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                              fontWeight: done || active ? FontWeight.w700 : FontWeight.w500,
                            ),
                      ),
                    ),
                  ],
                ),
              );
            }),
          ),
        ),
        const Spacer(),
        Align(
          alignment: Alignment.center,
          child: Chip(
            avatar: const Icon(Icons.offline_bolt_rounded, size: 18),
            label: const Text('تحلیل آفلاین'),
            side: BorderSide(color: Theme.of(context).dividerColor),
          ),
        ),
        const SizedBox(height: AppSpacing.xl),
      ],
    );
  }

  Widget _buildError(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          const Icon(Icons.error_outline_rounded, size: 54),
          const SizedBox(height: AppSpacing.md),
          Text('بررسی انجام نشد', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: AppSpacing.xs),
          Text(_error.toString(), textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: AppSpacing.lg),
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('بازگشت و اصلاح متن')),
        ],
      ),
    );
  }
}
