import 'dart:math' as math;

import '../../result/domain/verification_result.dart';
import 'diff_engine.dart';
import 'similarity_metrics.dart';
import 'source_models.dart';
import 'text_normalizer.dart';
import 'verification_policy.dart';

class VerificationEngine {
  const VerificationEngine({
    required this.repository,
    this.normalizer = const TextNormalizer(),
    this.diffEngine = const DiffEngine(),
  });

  final SourceRepository repository;
  final TextNormalizer normalizer;
  final DiffEngine diffEngine;

  Future<VerificationResult> verify(String rawInput) async {
    final String normalizedInput = normalizer.normalize(rawInput);
    if (normalizedInput.length < 3) {
      throw const VerificationException('عبارت برای بررسی بیش از حد کوتاه است.');
    }

    final List<String> queryTokens = normalizer.tokens(rawInput);
    final List<SourcePassage> candidates = await repository.findCandidates(
      normalizedInput,
      queryTokens,
      limit: VerificationPolicy.candidateLimit,
    );
    final List<_CandidateScore> scored = candidates
        .map((SourcePassage passage) => _scorePassage(rawInput, normalizedInput, queryTokens, passage))
        .toList()
      ..sort((_CandidateScore a, _CandidateScore b) => b.finalScore.compareTo(a.finalScore));

    if (scored.isEmpty) {
      return VerificationResult.noMatch(userText: rawInput);
    }

    final _CandidateScore best = scored.first;
    final int score = (best.finalScore * 100).round().clamp(0, 100).toInt();
    final MatchLevel level = _levelFor(best.finalScore);

    if (level == MatchLevel.low) {
      return VerificationResult.noMatch(
        userText: rawInput,
        score: score,
        relatedMatches: _related(scored.skip(1).take(3)),
      );
    }

    final DiffPair diff = diffEngine.compare(rawInput, best.matchedText);
    return VerificationResult(
      score: score,
      matchLevel: level,
      statusTitle: _statusTitle(level),
      summary: _summary(level, best.passage),
      sourceId: best.passage.id,
      sourceTitle: best.passage.sourceTitle,
      sourceReference: best.passage.reference,
      userText: rawInput.trim(),
      sourceText: best.passage.text,
      matchedSourceText: best.matchedText,
      userDiffSegments: diff.userSegments,
      sourceDiffSegments: diff.sourceSegments,
      tokenSimilarity: (best.tokenSimilarity * 100).round(),
      characterSimilarity: (best.characterSimilarity * 100).round(),
      ngramSimilarity: (best.ngramSimilarity * 100).round(),
      sequenceSimilarity: (best.sequenceSimilarity * 100).round(),
      relatedMatches: _related(scored.skip(1).take(3)),
    );
  }

  _CandidateScore _scorePassage(
    String rawInput,
    String normalizedInput,
    List<String> queryTokens,
    SourcePassage passage,
  ) {
    final String normalizedSource = passage.normalizedText ?? normalizer.normalize(passage.text);
    final List<String> sourceTokens = normalizedSource.isEmpty
        ? const <String>[]
        : normalizedSource.split(' ');

    final _Window bestWindow = _bestWindow(
      queryTokens: queryTokens,
      sourceTokens: sourceTokens,
      sourceOriginalTokens: passage.text.trim().split(RegExp(r'\s+')),
      normalizedInput: normalizedInput,
    );

    final String normalizedWindow = bestWindow.normalizedText;
    final List<String> windowTokens = normalizedWindow.isEmpty
        ? const <String>[]
        : normalizedWindow.split(' ');
    final bool contained = normalizedSource.contains(normalizedInput);

    final double coverage = SimilarityMetrics.queryCoverage(queryTokens, windowTokens);
    final double token = SimilarityMetrics.tokenJaccard(queryTokens, windowTokens);
    final double character = SimilarityMetrics.characterSimilarity(normalizedInput, normalizedWindow);
    final double ngram = SimilarityMetrics.bigramDice(normalizedInput, normalizedWindow);
    final double sequence = SimilarityMetrics.tokenSequenceSimilarity(queryTokens, windowTokens);

    var finalScore =
        (0.30 * coverage) +
        (0.20 * token) +
        (0.25 * character) +
        (0.15 * ngram) +
        (0.10 * sequence);

    if (contained) {
      if (finalScore < 0.98) finalScore = 0.98;
      if (normalizedInput == normalizedSource) finalScore = 1;
    }

    // Uthmani and ordinary Arabic/Persian typing sometimes differ in alef/hamza
    // conventions. This relaxed skeleton is used only as an equivalence check;
    // source text is never rewritten or displayed from it.
    final String querySkeleton = _orthographicSkeleton(rawInput);
    final String windowSkeleton = _orthographicSkeleton(normalizedWindow);
    if (querySkeleton.length >= 8 &&
        querySkeleton == windowSkeleton &&
        character >= 0.70 &&
        finalScore < 0.985) {
      finalScore = 0.985;
    }

    return _CandidateScore(
      passage: passage,
      matchedText: contained ? _containedExcerpt(rawInput, passage.text) : bestWindow.text,
      finalScore: finalScore.clamp(0.0, 1.0).toDouble(),
      tokenSimilarity: token,
      characterSimilarity: character,
      ngramSimilarity: ngram,
      sequenceSimilarity: sequence,
    );
  }

  _Window _bestWindow({
    required List<String> queryTokens,
    required List<String> sourceTokens,
    required List<String> sourceOriginalTokens,
    required String normalizedInput,
  }) {
    if (sourceTokens.isEmpty || queryTokens.isEmpty) {
      return _Window(
        text: sourceOriginalTokens.join(' '),
        normalizedText: sourceTokens.join(' '),
        score: 0,
      );
    }

    final int target = queryTokens.length;
    _Window? best;
    for (final int delta in <int>[-2, -1, 0, 1, 2, 3]) {
      final int size = (target + delta).clamp(1, sourceTokens.length).toInt();
      for (var start = 0; start + size <= sourceTokens.length; start++) {
        final List<String> normalizedWindow = sourceTokens.sublist(start, start + size);
        final String normalizedWindowText = normalizedWindow.join(' ');
        final String originalWindow;
        if (sourceOriginalTokens.length == sourceTokens.length) {
          final int originalEnd = math.min(start + size, sourceOriginalTokens.length);
          originalWindow = sourceOriginalTokens.sublist(start, originalEnd).join(' ');
        } else {
          // Source typography may contain standalone pause marks or clitics that
          // do not map 1:1 to search tokens. In that case prefer a correct
          // normalized excerpt over a misaligned original-token slice.
          originalWindow = normalizedWindowText;
        }
        final double score =
            0.55 * SimilarityMetrics.characterSimilarity(normalizedInput, normalizedWindowText) +
            0.45 * SimilarityMetrics.queryCoverage(queryTokens, normalizedWindow);
        if (best == null || score > best.score) {
          best = _Window(
            text: originalWindow,
            normalizedText: normalizedWindowText,
            score: score,
          );
        }
      }
    }
    return best ?? _Window(
      text: sourceOriginalTokens.join(' '),
      normalizedText: sourceTokens.join(' '),
      score: 0,
    );
  }

  String _containedExcerpt(String rawInput, String sourceText) {
    // Token-window extraction keeps the displayed comparison compact even when
    // the verified phrase is only part of a long source passage.
    final List<String> query = normalizer.tokens(rawInput);
    final List<String> sourceNormalized = normalizer.tokens(sourceText);
    final List<String> sourceOriginal = sourceText.trim().split(RegExp(r'\s+'));
    if (query.isEmpty || sourceNormalized.isEmpty) return sourceText;
    if (sourceOriginal.length != sourceNormalized.length) {
      // Uthmani pause marks and separated clitics can change token counts after
      // normalization. Returning the full original source is safer than slicing
      // it with normalized-token offsets and potentially showing the wrong text.
      return sourceText;
    }

    for (var start = 0; start <= sourceNormalized.length - query.length; start++) {
      var matches = true;
      for (var offset = 0; offset < query.length; offset++) {
        if (sourceNormalized[start + offset] != query[offset]) {
          matches = false;
          break;
        }
      }
      if (matches) {
        return sourceOriginal.sublist(start, start + query.length).join(' ');
      }
    }
    return sourceText;
  }

  List<RelatedMatch> _related(Iterable<_CandidateScore> scores) {
    return scores
        .where((_CandidateScore item) => item.finalScore >= 0.35)
        .map(
          (_CandidateScore item) => RelatedMatch(
            sourceId: item.passage.id,
            title: item.passage.sourceTitle,
            reference: item.passage.reference,
            score: (item.finalScore * 100).round(),
          ),
        )
        .toList();
  }

  MatchLevel _levelFor(double normalizedScore) {
    if (normalizedScore >= VerificationPolicy.exactThreshold) return MatchLevel.exact;
    if (normalizedScore >= VerificationPolicy.highThreshold) return MatchLevel.high;
    if (normalizedScore >= VerificationPolicy.acceptanceThreshold) return MatchLevel.medium;
    return MatchLevel.low;
  }

  String _orthographicSkeleton(String input) {
    return normalizer
        .normalize(input)
        .replaceAll('ا', '')
        .replaceAll('ء', '')
        .replaceAll(' ', '');
  }

  String _statusTitle(MatchLevel level) {
    return switch (level) {
      MatchLevel.exact => 'تطابق مستقیم',
      MatchLevel.high => 'تطابق بسیار بالا',
      MatchLevel.medium => 'متن مشابه یافت شد',
      MatchLevel.low => 'منبع قابل اتکایی پیدا نشد',
    };
  }

  String _summary(MatchLevel level, SourcePassage passage) {
    return switch (level) {
      MatchLevel.exact => 'این عبارت با متنی در ${passage.sourceTitle} تطابق مستقیم دارد.',
      MatchLevel.high => 'این عبارت با متنی در ${passage.sourceTitle} شباهت بسیار بالایی دارد.',
      MatchLevel.medium => 'متنی نزدیک در ${passage.sourceTitle} پیدا شد؛ تفاوت‌ها را بررسی کنید.',
      MatchLevel.low => 'برای این عبارت در منابع فعلی تطابق کافی پیدا نشد.',
    };
  }
}

class VerificationException implements Exception {
  const VerificationException(this.message);

  final String message;

  @override
  String toString() => message;
}

class _Window {
  const _Window({
    required this.text,
    required this.normalizedText,
    required this.score,
  });

  final String text;
  final String normalizedText;
  final double score;
}

class _CandidateScore {
  const _CandidateScore({
    required this.passage,
    required this.matchedText,
    required this.finalScore,
    required this.tokenSimilarity,
    required this.characterSimilarity,
    required this.ngramSimilarity,
    required this.sequenceSimilarity,
  });

  final SourcePassage passage;
  final String matchedText;
  final double finalScore;
  final double tokenSimilarity;
  final double characterSimilarity;
  final double ngramSimilarity;
  final double sequenceSimilarity;
}
