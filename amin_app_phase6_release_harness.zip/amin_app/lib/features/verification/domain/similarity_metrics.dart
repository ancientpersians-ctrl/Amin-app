import 'dart:math' as math;

class SimilarityMetrics {
  const SimilarityMetrics._();

  static double characterSimilarity(String a, String b) {
    if (a == b) return 1;
    if (a.isEmpty || b.isEmpty) return 0;
    final int distance = _levenshtein(a, b);
    final int maxLength = math.max(a.length, b.length);
    return (1 - (distance / maxLength)).clamp(0.0, 1.0).toDouble();
  }

  static double tokenJaccard(List<String> a, List<String> b) {
    if (a.isEmpty || b.isEmpty) return 0;
    final Set<String> setA = a.toSet();
    final Set<String> setB = b.toSet();
    final int intersection = setA.intersection(setB).length;
    final int union = setA.union(setB).length;
    return union == 0 ? 0 : intersection / union;
  }

  static double queryCoverage(List<String> query, List<String> candidate) {
    if (query.isEmpty || candidate.isEmpty) return 0;
    final List<String> remaining = List<String>.from(candidate);
    var matched = 0;
    for (final String token in query) {
      final int index = remaining.indexOf(token);
      if (index >= 0) {
        matched++;
        remaining.removeAt(index);
      }
    }
    return matched / query.length;
  }

  static double bigramDice(String a, String b) {
    if (a == b) return 1;
    if (a.length < 2 || b.length < 2) return 0;
    final List<String> gramsA = _ngrams(a, 2);
    final List<String> gramsB = _ngrams(b, 2);
    final List<String> remaining = List<String>.from(gramsB);
    var intersection = 0;
    for (final String gram in gramsA) {
      final int index = remaining.indexOf(gram);
      if (index >= 0) {
        intersection++;
        remaining.removeAt(index);
      }
    }
    return (2 * intersection) / (gramsA.length + gramsB.length);
  }

  static double tokenSequenceSimilarity(List<String> a, List<String> b) {
    if (a.isEmpty || b.isEmpty) return 0;
    final int lcs = _lcsLength(a, b);
    return (2 * lcs) / (a.length + b.length);
  }

  static int _levenshtein(String a, String b) {
    final List<int> previous = List<int>.generate(b.length + 1, (int i) => i);
    final List<int> current = List<int>.filled(b.length + 1, 0);

    for (var i = 1; i <= a.length; i++) {
      current[0] = i;
      for (var j = 1; j <= b.length; j++) {
        final int substitution = previous[j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1);
        final int insertion = current[j - 1] + 1;
        final int deletion = previous[j] + 1;
        current[j] = math.min(substitution, math.min(insertion, deletion));
      }
      for (var j = 0; j <= b.length; j++) {
        previous[j] = current[j];
      }
    }
    return previous[b.length];
  }

  static int _lcsLength(List<String> a, List<String> b) {
    final List<List<int>> dp = List<List<int>>.generate(
      a.length + 1,
      (_) => List<int>.filled(b.length + 1, 0),
    );
    for (var i = 1; i <= a.length; i++) {
      for (var j = 1; j <= b.length; j++) {
        if (a[i - 1] == b[j - 1]) {
          dp[i][j] = dp[i - 1][j - 1] + 1;
        } else {
          dp[i][j] = math.max(dp[i - 1][j], dp[i][j - 1]);
        }
      }
    }
    return dp[a.length][b.length];
  }

  static List<String> _ngrams(String input, int n) {
    final String compact = input.replaceAll(' ', '');
    if (compact.length < n) return <String>[compact];
    return List<String>.generate(
      compact.length - n + 1,
      (int index) => compact.substring(index, index + n),
    );
  }
}
