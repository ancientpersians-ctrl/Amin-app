enum SourceKind {
  quran,
  nahjAlBalagha,
  sahifaSajjadiya,
  hadith,
}

SourceKind sourceKindFromStorage(String value) {
  return switch (value) {
    'quran' => SourceKind.quran,
    'nahjAlBalagha' => SourceKind.nahjAlBalagha,
    'sahifaSajjadiya' => SourceKind.sahifaSajjadiya,
    'hadith' => SourceKind.hadith,
    _ => throw ArgumentError.value(value, 'value', 'Unknown source kind'),
  };
}

String sourceKindLabel(SourceKind kind) {
  return switch (kind) {
    SourceKind.quran => 'قرآن',
    SourceKind.nahjAlBalagha => 'نهج‌البلاغه',
    SourceKind.sahifaSajjadiya => 'صحیفه سجادیه',
    SourceKind.hadith => 'روایات',
  };
}

class SourcePassage {
  const SourcePassage({
    required this.id,
    required this.sourceId,
    required this.kind,
    required this.sourceTitle,
    required this.reference,
    required this.text,
    this.normalizedText,
    this.sectionTitle,
    this.metadata = const <String, String>{},
  });

  final String id;
  final String sourceId;
  final SourceKind kind;
  final String sourceTitle;
  final String reference;
  final String text;
  final String? normalizedText;
  final String? sectionTitle;
  final Map<String, String> metadata;
}

class SourceMetadata {
  const SourceMetadata({
    required this.id,
    required this.kind,
    required this.title,
    required this.scope,
    required this.version,
    this.titleArabic,
    this.edition,
    this.language,
    this.sourceUrl,
    this.license,
    this.attribution,
    this.retrievedAt,
    this.sha256,
    this.notes,
  });

  final String id;
  final SourceKind kind;
  final String title;
  final String scope;
  final String version;
  final String? titleArabic;
  final String? edition;
  final String? language;
  final String? sourceUrl;
  final String? license;
  final String? attribution;
  final String? retrievedAt;
  final String? sha256;
  final String? notes;

  bool get isComplete => scope == 'complete';
}

class SourcePassageDetail {
  const SourcePassageDetail({
    required this.passage,
    required this.source,
    this.previousPassage,
    this.nextPassage,
  });

  final SourcePassage passage;
  final SourceMetadata source;
  final SourcePassage? previousPassage;
  final SourcePassage? nextPassage;
}

class SourceSearchResult {
  const SourceSearchResult({
    required this.passage,
    required this.tokenHits,
    required this.phraseMatch,
  });

  final SourcePassage passage;
  final int tokenHits;
  final bool phraseMatch;
}

class CorpusSourceStats {
  const CorpusSourceStats({
    required this.sourceId,
    required this.kind,
    required this.title,
    required this.count,
    required this.scope,
    required this.version,
  });

  final String sourceId;
  final SourceKind kind;
  final String title;
  final int count;
  final String scope;
  final String version;

  bool get isComplete => scope == 'complete';
}

class CorpusStats {
  const CorpusStats({
    required this.corpusVersion,
    required this.totalPassages,
    required this.sources,
  });

  final String corpusVersion;
  final int totalPassages;
  final List<CorpusSourceStats> sources;

  int countFor(SourceKind kind) => sources
      .where((CorpusSourceStats source) => source.kind == kind)
      .fold<int>(0, (int total, CorpusSourceStats source) => total + source.count);
}

abstract interface class SourceRepository {
  Future<List<SourcePassage>> findCandidates(
    String normalizedQuery,
    List<String> queryTokens, {
    int limit = 8,
  });

  Future<SourcePassage?> findById(String id);

  Future<List<SourceSearchResult>> searchPassages(
    String normalizedQuery,
    List<String> queryTokens, {
    SourceKind? kind,
    int limit = 50,
  });

  Future<SourcePassageDetail?> detailForPassage(String passageId);

  Future<CorpusStats> stats();

  Future<void> close();
}
