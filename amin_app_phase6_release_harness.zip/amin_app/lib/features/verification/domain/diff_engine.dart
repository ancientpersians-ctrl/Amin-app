import '../../result/domain/verification_result.dart';
import 'text_normalizer.dart';

class DiffPair {
  const DiffPair({
    required this.userSegments,
    required this.sourceSegments,
  });

  final List<DiffSegment> userSegments;
  final List<DiffSegment> sourceSegments;
}

class DiffEngine {
  const DiffEngine({this.normalizer = const TextNormalizer()});

  final TextNormalizer normalizer;

  DiffPair compare(String userText, String sourceText) {
    final List<_Token> user = _tokenize(userText);
    final List<_Token> source = _tokenize(sourceText);
    final int n = user.length;
    final int m = source.length;

    final List<List<int>> dp = List<List<int>>.generate(
      n + 1,
      (_) => List<int>.filled(m + 1, 0),
    );

    for (var i = 0; i <= n; i++) dp[i][0] = i;
    for (var j = 0; j <= m; j++) dp[0][j] = j;

    for (var i = 1; i <= n; i++) {
      for (var j = 1; j <= m; j++) {
        final int cost = user[i - 1].normalized == source[j - 1].normalized ? 0 : 1;
        final int substitute = dp[i - 1][j - 1] + cost;
        final int insert = dp[i - 1][j] + 1;
        final int delete = dp[i][j - 1] + 1;
        dp[i][j] = _min3(substitute, insert, delete);
      }
    }

    final List<DiffSegment> userSegments = <DiffSegment>[];
    final List<DiffSegment> sourceSegments = <DiffSegment>[];
    var i = n;
    var j = m;

    while (i > 0 || j > 0) {
      if (i > 0 && j > 0) {
        final bool same = user[i - 1].normalized == source[j - 1].normalized;
        final int diagonalCost = dp[i - 1][j - 1] + (same ? 0 : 1);
        if (dp[i][j] == diagonalCost) {
          final DiffType type = same ? DiffType.same : DiffType.changed;
          userSegments.add(DiffSegment(text: user[i - 1].original, type: type));
          sourceSegments.add(DiffSegment(text: source[j - 1].original, type: type));
          i--;
          j--;
          continue;
        }
      }

      if (i > 0 && dp[i][j] == dp[i - 1][j] + 1) {
        userSegments.add(DiffSegment(text: user[i - 1].original, type: DiffType.added));
        i--;
        continue;
      }

      if (j > 0) {
        sourceSegments.add(DiffSegment(text: source[j - 1].original, type: DiffType.removed));
        j--;
      }
    }

    return DiffPair(
      userSegments: _mergeAndReverse(userSegments),
      sourceSegments: _mergeAndReverse(sourceSegments),
    );
  }

  List<_Token> _tokenize(String text) {
    return text
        .trim()
        .split(RegExp(r'\s+'))
        .where((String token) => token.isNotEmpty)
        .map((String token) => _Token(token, normalizer.normalizeToken(token)))
        .where((_Token token) => token.normalized.isNotEmpty)
        .toList();
  }

  List<DiffSegment> _mergeAndReverse(List<DiffSegment> reversed) {
    final List<DiffSegment> ordered = reversed.reversed.toList();
    if (ordered.isEmpty) return const <DiffSegment>[];

    final List<DiffSegment> merged = <DiffSegment>[];
    for (final DiffSegment segment in ordered) {
      if (merged.isNotEmpty && merged.last.type == segment.type) {
        final DiffSegment previous = merged.removeLast();
        merged.add(
          DiffSegment(
            text: '${previous.text} ${segment.text}',
            type: segment.type,
          ),
        );
      } else {
        merged.add(segment);
      }
    }
    return merged;
  }

  int _min3(int a, int b, int c) {
    var min = a;
    if (b < min) min = b;
    if (c < min) min = c;
    return min;
  }
}

class _Token {
  const _Token(this.original, this.normalized);

  final String original;
  final String normalized;
}
