class VerificationPolicy {
  const VerificationPolicy._();

  /// Frozen after calibration on Amin Benchmark v1 dev split.
  /// See benchmark/BENCHMARK_REPORT.md.
  static const double acceptanceThreshold = 0.63;
  static const int candidateLimit = 8;
  static const String benchmarkVersion = '1.0.0';

  static const double exactThreshold = 0.985;
  static const double highThreshold = 0.85;
}
