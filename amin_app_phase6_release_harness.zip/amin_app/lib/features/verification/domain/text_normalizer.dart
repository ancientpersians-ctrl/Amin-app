class TextNormalizer {
  const TextNormalizer();

  static final RegExp _arabicDiacritics = RegExp(
    r'[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]',
  );
  static final RegExp _tatweel = RegExp(r'\u0640');
  static final RegExp _punctuation = RegExp(
    r'''[\.,،؛;:!؟?\(\)\[\]\{\}"'«»…ـ\-_/\\|﴿﴾]+''',
  );
  static final RegExp _whitespace = RegExp(r'\s+');
  static final RegExp _standaloneArabicClitic = RegExp(r'(^|\s)([وفبكل])\s+(?=[\u0621-\u06FF])', multiLine: true);

  String normalize(String input) {
    var value = input.trim().toLowerCase();
    value = value.replaceAll(_arabicDiacritics, '');
    value = value.replaceAll(_tatweel, '');

    const Map<String, String> replacements = <String, String>{
      'أ': 'ا',
      'إ': 'ا',
      'آ': 'ا',
      'ٱ': 'ا',
      'ى': 'ی',
      'ي': 'ی',
      'ئ': 'ی',
      'ك': 'ک',
      'ؤ': 'و',
      'ۀ': 'ه',
      'ة': 'ه',
    };

    replacements.forEach((String from, String to) {
      value = value.replaceAll(from, to);
    });

    value = _toAsciiDigits(value);
    value = value.replaceAll(_punctuation, ' ');
    value = value.replaceAll(_whitespace, ' ').trim();

    // Some classical transcriptions separate one-letter Arabic clitics
    // (for example: «وَ مِنْكَ») while normal typing joins them («ومنك»).
    // This only changes the derived search key, never the displayed source.
    String previous;
    do {
      previous = value;
      value = value.replaceAllMapped(
        _standaloneArabicClitic,
        (Match match) => '${match.group(1) ?? ''}${match.group(2)!}',
      );
    } while (previous != value);

    return value;
  }

  List<String> tokens(String input) {
    final String normalized = normalize(input);
    if (normalized.isEmpty) return const <String>[];
    return normalized.split(' ').where((String token) => token.isNotEmpty).toList();
  }

  String normalizeToken(String input) => normalize(input);

  /// Compact character n-grams used only for candidate retrieval.
  /// Spaces are removed after ordinary Arabic/Persian normalization.
  List<String> compactNgrams(String input, int n) {
    final String compact = normalize(input).replaceAll(' ', '');
    if (n <= 0 || compact.isEmpty) return const <String>[];
    if (compact.length < n) return <String>[compact];
    final List<String> grams = <String>[];
    for (var i = 0; i <= compact.length - n; i++) {
      grams.add(compact.substring(i, i + n));
    }
    return grams;
  }

  String _toAsciiDigits(String input) {
    const String persian = '۰۱۲۳۴۵۶۷۸۹';
    const String arabic = '٠١٢٣٤٥٦٧٨٩';
    var result = input;
    for (var i = 0; i < 10; i++) {
      result = result.replaceAll(persian[i], '$i');
      result = result.replaceAll(arabic[i], '$i');
    }
    return result;
  }
}
