import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../domain/source_models.dart';

class DatabaseSourceRepository implements SourceRepository {
  DatabaseSourceRepository._(this._database);

  static const String assetPath = 'assets/data/amin_corpus.sqlite3';
  static const String installedFileName = 'amin_corpus_2026_09_25_corpus1.sqlite3';

  final Database _database;
  CorpusStats? _cachedStats;

  static Future<DatabaseSourceRepository> open() async {
    final String databasesDirectory = await getDatabasesPath();
    await Directory(databasesDirectory).create(recursive: true);
    final String databasePath = p.join(databasesDirectory, installedFileName);
    final File databaseFile = File(databasePath);

    if (!await databaseFile.exists()) {
      await _copyAsset(databaseFile);
    }

    Database? database;
    try {
      database = await openDatabase(databasePath, readOnly: true);
      final List<Map<String, Object?>> quickCheck =
          await database.rawQuery('PRAGMA quick_check');
      final Object? result = quickCheck.isEmpty ? null : quickCheck.first.values.first;
      if (result?.toString().toLowerCase() != 'ok') {
        throw StateError('Corpus database quick_check failed: $result');
      }
    } catch (_) {
      await database?.close();
      database = null;
      if (await databaseFile.exists()) await databaseFile.delete();
      await _copyAsset(databaseFile);
      database = await openDatabase(databasePath, readOnly: true);
      final List<Map<String, Object?>> secondCheck =
          await database.rawQuery('PRAGMA quick_check');
      final Object? result = secondCheck.isEmpty ? null : secondCheck.first.values.first;
      if (result?.toString().toLowerCase() != 'ok') {
        await database.close();
        throw StateError('Corpus database is not valid after recovery: $result');
      }
    }

    return DatabaseSourceRepository._(database!);
  }

  static Future<void> _copyAsset(File target) async {
    final ByteData data = await rootBundle.load(assetPath);
    final Uint8List bytes = data.buffer.asUint8List(
      data.offsetInBytes,
      data.lengthInBytes,
    );
    await target.writeAsBytes(bytes, flush: true);
  }

  @override
  Future<List<SourcePassage>> findCandidates(
    String normalizedQuery,
    List<String> queryTokens, {
    int limit = 8,
  }) async {
    if (normalizedQuery.isEmpty) return const <SourcePassage>[];

    final List<String> selectedTokens = _sampleUnique(queryTokens, 48);
    final List<String> selectedGrams = _sampleUnique(_trigrams(normalizedQuery), 180);
    final Map<String, double> retrievalScores = <String, double>{};

    if (selectedTokens.isNotEmpty) {
      final String placeholders = List<String>.filled(selectedTokens.length, '?').join(',');
      final List<Map<String, Object?>> rows = await _database.rawQuery(
        '''SELECT passage_id, COUNT(*) AS hits
           FROM token_index
           WHERE token IN ($placeholders)
           GROUP BY passage_id
           ORDER BY hits DESC
           LIMIT 100''',
        selectedTokens,
      );
      for (final Map<String, Object?> row in rows) {
        final String id = row['passage_id']! as String;
        final int hits = (row['hits']! as num).toInt();
        retrievalScores[id] = (retrievalScores[id] ?? 0) + (3.0 * hits);
      }
    }

    if (selectedGrams.isNotEmpty) {
      final String placeholders = List<String>.filled(selectedGrams.length, '?').join(',');
      final List<Map<String, Object?>> rows = await _database.rawQuery(
        '''SELECT passage_id, COUNT(*) AS hits
           FROM gram_index
           WHERE gram IN ($placeholders)
           GROUP BY passage_id
           ORDER BY hits DESC
           LIMIT 100''',
        selectedGrams,
      );
      for (final Map<String, Object?> row in rows) {
        final String id = row['passage_id']! as String;
        final int hits = (row['hits']! as num).toInt();
        retrievalScores[id] = (retrievalScores[id] ?? 0) + hits;
      }
    }

    if (retrievalScores.isEmpty) return const <SourcePassage>[];

    final List<MapEntry<String, double>> ranked = retrievalScores.entries.toList()
      ..sort((MapEntry<String, double> a, MapEntry<String, double> b) {
        final int scoreOrder = b.value.compareTo(a.value);
        return scoreOrder != 0 ? scoreOrder : a.key.compareTo(b.key);
      });

    final List<String> ids = ranked
        .take(math.max(1, limit))
        .map((MapEntry<String, double> entry) => entry.key)
        .toList(growable: false);
    return _loadPassages(ids);
  }

  @override
  Future<SourcePassage?> findById(String id) async {
    final List<SourcePassage> results = await _loadPassages(<String>[id]);
    return results.isEmpty ? null : results.first;
  }

  @override
  Future<List<SourceSearchResult>> searchPassages(
    String normalizedQuery,
    List<String> queryTokens, {
    SourceKind? kind,
    int limit = 50,
  }) async {
    final String query = normalizedQuery.trim();
    if (query.isEmpty) return const <SourceSearchResult>[];

    final List<String> tokens = _sampleUnique(queryTokens, 24);
    final List<Object?> args = <Object?>[query];
    final List<String> conditions = <String>[];

    String tokenJoin = 'LEFT JOIN token_index t ON 1 = 0';
    if (tokens.isNotEmpty) {
      final String placeholders = List<String>.filled(tokens.length, '?').join(',');
      tokenJoin = 'LEFT JOIN token_index t ON t.passage_id = p.id AND t.token IN ($placeholders)';
      args.addAll(tokens);
      conditions.add('(instr(p.normalized_text, ?) > 0 OR t.token IS NOT NULL)');
      args.add(query);
    } else {
      conditions.add('instr(p.normalized_text, ?) > 0');
      args.add(query);
    }

    if (kind != null) {
      conditions.add('p.kind = ?');
      args.add(_kindToStorage(kind));
    }
    args.add(limit.clamp(1, 100));

    final List<Map<String, Object?>> rows = await _database.rawQuery(
      '''SELECT p.id, p.source_id, p.kind, p.reference, p.section_title,
                p.original_text, p.normalized_text, p.passage_number,
                p.provenance_locator, s.title_fa AS source_title,
                CASE WHEN instr(p.normalized_text, ?) > 0 THEN 1 ELSE 0 END AS phrase_match,
                COUNT(DISTINCT t.token) AS token_hits
         FROM passages p
         JOIN sources s ON s.id = p.source_id
         $tokenJoin
         WHERE ${conditions.join(' AND ')}
         GROUP BY p.id
         ORDER BY phrase_match DESC, token_hits DESC, p.display_order ASC
         LIMIT ?''',
      args,
    );

    return rows
        .map(
          (Map<String, Object?> row) => SourceSearchResult(
            passage: _passageFromRow(row),
            tokenHits: (row['token_hits'] as num?)?.toInt() ?? 0,
            phraseMatch: ((row['phrase_match'] as num?)?.toInt() ?? 0) == 1,
          ),
        )
        .toList(growable: false);
  }

  @override
  Future<SourcePassageDetail?> detailForPassage(String passageId) async {
    final List<Map<String, Object?>> rows = await _database.rawQuery(
      '''SELECT p.id, p.source_id, p.kind, p.reference, p.section_title,
                p.original_text, p.normalized_text, p.passage_number,
                p.provenance_locator, p.display_order,
                s.title_fa AS source_title, s.title_ar, s.edition, s.scope,
                s.language, s.source_url, s.license, s.attribution, s.version,
                s.retrieved_at, s.sha256 AS source_sha256, s.notes
         FROM passages p
         JOIN sources s ON s.id = p.source_id
         WHERE p.id = ?
         LIMIT 1''',
      <Object?>[passageId],
    );
    if (rows.isEmpty) return null;

    final Map<String, Object?> row = rows.first;
    final SourcePassage passage = _passageFromRow(row);
    final int displayOrder = (row['display_order']! as num).toInt();

    final List<Map<String, Object?>> neighborRows = await _database.rawQuery(
      '''SELECT p.id, p.source_id, p.kind, p.reference, p.section_title,
                p.original_text, p.normalized_text, p.passage_number,
                p.provenance_locator, p.display_order, s.title_fa AS source_title
         FROM passages p
         JOIN sources s ON s.id = p.source_id
         WHERE p.source_id = ? AND p.display_order IN (?, ?)
         ORDER BY p.display_order''',
      <Object?>[passage.sourceId, displayOrder - 1, displayOrder + 1],
    );

    SourcePassage? previous;
    SourcePassage? next;
    for (final Map<String, Object?> neighbor in neighborRows) {
      final int order = (neighbor['display_order']! as num).toInt();
      if (order < displayOrder) previous = _passageFromRow(neighbor);
      if (order > displayOrder) next = _passageFromRow(neighbor);
    }

    return SourcePassageDetail(
      passage: passage,
      source: SourceMetadata(
        id: passage.sourceId,
        kind: passage.kind,
        title: passage.sourceTitle,
        titleArabic: row['title_ar'] as String?,
        edition: row['edition'] as String?,
        scope: row['scope']! as String,
        language: row['language'] as String?,
        sourceUrl: row['source_url'] as String?,
        license: row['license'] as String?,
        attribution: row['attribution'] as String?,
        version: row['version']?.toString() ?? 'unknown',
        retrievedAt: row['retrieved_at'] as String?,
        sha256: row['source_sha256'] as String?,
        notes: row['notes'] as String?,
      ),
      previousPassage: previous,
      nextPassage: next,
    );
  }

  Future<List<SourcePassage>> _loadPassages(List<String> ids) async {
    if (ids.isEmpty) return const <SourcePassage>[];
    final String placeholders = List<String>.filled(ids.length, '?').join(',');
    final List<Map<String, Object?>> rows = await _database.rawQuery(
      '''SELECT p.id, p.source_id, p.kind, p.reference, p.section_title,
                p.original_text, p.normalized_text, p.passage_number,
                p.provenance_locator, s.title_fa AS source_title
         FROM passages p
         JOIN sources s ON s.id = p.source_id
         WHERE p.id IN ($placeholders)''',
      ids,
    );
    final Map<String, SourcePassage> byId = <String, SourcePassage>{
      for (final Map<String, Object?> row in rows)
        row['id']! as String: _passageFromRow(row),
    };
    return ids
        .where(byId.containsKey)
        .map((String id) => byId[id]!)
        .toList(growable: false);
  }

  SourcePassage _passageFromRow(Map<String, Object?> row) {
    return SourcePassage(
      id: row['id']! as String,
      sourceId: row['source_id']! as String,
      kind: sourceKindFromStorage(row['kind']! as String),
      sourceTitle: row['source_title']! as String,
      reference: row['reference']! as String,
      text: row['original_text']! as String,
      normalizedText: row['normalized_text']! as String,
      sectionTitle: row['section_title'] as String?,
      metadata: <String, String>{
        if (row['passage_number'] != null)
          'passage_number': row['passage_number'].toString(),
        if (row['provenance_locator'] != null)
          'provenance_locator': row['provenance_locator'].toString(),
      },
    );
  }

  @override
  Future<CorpusStats> stats() async {
    if (_cachedStats case final CorpusStats stats) return stats;

    final List<Map<String, Object?>> metaRows = await _database.query('meta');
    final Map<String, String> meta = <String, String>{
      for (final Map<String, Object?> row in metaRows)
        row['key']! as String: row['value']! as String,
    };
    final List<Map<String, Object?>> sourceRows = await _database.rawQuery(
      '''SELECT s.id, s.kind, s.title_fa, s.scope, s.version, COUNT(p.id) AS passage_count
         FROM sources s
         LEFT JOIN passages p ON p.source_id = s.id
         GROUP BY s.id, s.kind, s.title_fa, s.scope, s.version
         ORDER BY MIN(p.display_order)''',
    );
    final List<CorpusSourceStats> sources = sourceRows
        .map(
          (Map<String, Object?> row) => CorpusSourceStats(
            sourceId: row['id']! as String,
            kind: sourceKindFromStorage(row['kind']! as String),
            title: row['title_fa']! as String,
            count: (row['passage_count']! as num).toInt(),
            scope: row['scope']! as String,
            version: row['version']! as String,
          ),
        )
        .toList(growable: false);

    final CorpusStats value = CorpusStats(
      corpusVersion: meta['corpus_version'] ?? 'unknown',
      totalPassages: int.tryParse(meta['passage_count'] ?? '') ??
          sources.fold<int>(0, (int sum, CorpusSourceStats item) => sum + item.count),
      sources: sources,
    );
    _cachedStats = value;
    return value;
  }

  List<String> _trigrams(String normalized) {
    final String compact = normalized.replaceAll(' ', '');
    if (compact.isEmpty) return const <String>[];
    if (compact.length < 3) return <String>[compact];
    return List<String>.generate(
      compact.length - 2,
      (int index) => compact.substring(index, index + 3),
    );
  }

  List<String> _sampleUnique(List<String> values, int limit) {
    final List<String> unique = <String>[];
    final Set<String> seen = <String>{};
    for (final String value in values) {
      if (value.isNotEmpty && seen.add(value)) unique.add(value);
    }
    if (unique.length <= limit) return unique;
    if (limit <= 1) return <String>[unique.first];
    final double step = (unique.length - 1) / (limit - 1);
    return List<String>.generate(
      limit,
      (int index) => unique[(index * step).round()],
    );
  }

  String _kindToStorage(SourceKind kind) {
    return switch (kind) {
      SourceKind.quran => 'quran',
      SourceKind.nahjAlBalagha => 'nahjAlBalagha',
      SourceKind.sahifaSajjadiya => 'sahifaSajjadiya',
      SourceKind.hadith => 'hadith',
    };
  }

  @override
  Future<void> close() => _database.close();
}
