import '../domain/source_models.dart';

/// Tiny in-memory corpus retained only for fast unit tests.
/// Production runtime uses DatabaseSourceRepository.
class SeedSourceRepository implements SourceRepository {
  const SeedSourceRepository();

  static const List<SourcePassage> _passages = <SourcePassage>[
    SourcePassage(
      id: 'quran-2-153',
      sourceId: 'test-quran',
      kind: SourceKind.quran,
      sourceTitle: 'قرآن کریم',
      reference: 'سوره بقره، آیه ۱۵۳',
      sectionTitle: 'البقرة',
      text: 'يَا أَيُّهَا الَّذِينَ آمَنُوا اسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ إِنَّ اللَّهَ مَعَ الصَّابِرِينَ',
    ),
    SourcePassage(
      id: 'quran-13-28',
      sourceId: 'test-quran',
      kind: SourceKind.quran,
      sourceTitle: 'قرآن کریم',
      reference: 'سوره رعد، آیه ۲۸',
      sectionTitle: 'الرعد',
      text: 'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ',
    ),
    SourcePassage(
      id: 'nahj-hikmah-172',
      sourceId: 'test-nahj',
      kind: SourceKind.nahjAlBalagha,
      sourceTitle: 'نهج‌البلاغه',
      reference: 'حکمت ۱۷۲',
      text: 'النّاس أعداء ما جهلوا.',
    ),
  ];

  @override
  Future<List<SourcePassage>> findCandidates(
    String normalizedQuery,
    List<String> queryTokens, {
    int limit = 8,
  }) async => _passages.take(limit).toList(growable: false);

  @override
  Future<SourcePassage?> findById(String id) async {
    for (final SourcePassage passage in _passages) {
      if (passage.id == id) return passage;
    }
    return null;
  }

  @override
  Future<List<SourceSearchResult>> searchPassages(
    String normalizedQuery,
    List<String> queryTokens, {
    SourceKind? kind,
    int limit = 50,
  }) async {
    final List<SourceSearchResult> results = <SourceSearchResult>[];
    for (final SourcePassage passage in _passages) {
      if (kind != null && passage.kind != kind) continue;
      final String normalized = (passage.normalizedText ?? passage.text).toLowerCase();
      final bool phrase = normalized.contains(normalizedQuery.toLowerCase());
      final int hits = queryTokens.where((String token) => normalized.contains(token.toLowerCase())).length;
      if (phrase || hits > 0) {
        results.add(SourceSearchResult(passage: passage, tokenHits: hits, phraseMatch: phrase));
      }
    }
    results.sort((SourceSearchResult a, SourceSearchResult b) {
      if (a.phraseMatch != b.phraseMatch) return a.phraseMatch ? -1 : 1;
      return b.tokenHits.compareTo(a.tokenHits);
    });
    return results.take(limit).toList(growable: false);
  }

  @override
  Future<SourcePassageDetail?> detailForPassage(String passageId) async {
    final int index = _passages.indexWhere((SourcePassage p) => p.id == passageId);
    if (index < 0) return null;
    final SourcePassage passage = _passages[index];
    return SourcePassageDetail(
      passage: passage,
      source: SourceMetadata(
        id: passage.sourceId,
        kind: passage.kind,
        title: passage.sourceTitle,
        scope: 'test_subset',
        version: 'test',
        edition: 'Unit test corpus',
        attribution: 'Amin tests',
      ),
      previousPassage: index > 0 && _passages[index - 1].sourceId == passage.sourceId ? _passages[index - 1] : null,
      nextPassage: index + 1 < _passages.length && _passages[index + 1].sourceId == passage.sourceId ? _passages[index + 1] : null,
    );
  }

  @override
  Future<CorpusStats> stats() async => const CorpusStats(
        corpusVersion: 'unit-test',
        totalPassages: 3,
        sources: <CorpusSourceStats>[
          CorpusSourceStats(
            sourceId: 'test-quran',
            kind: SourceKind.quran,
            title: 'قرآن کریم',
            count: 2,
            scope: 'test_subset',
            version: 'test',
          ),
          CorpusSourceStats(
            sourceId: 'test-nahj',
            kind: SourceKind.nahjAlBalagha,
            title: 'نهج‌البلاغه',
            count: 1,
            scope: 'test_subset',
            version: 'test',
          ),
        ],
      );

  @override
  Future<void> close() async {}
}
