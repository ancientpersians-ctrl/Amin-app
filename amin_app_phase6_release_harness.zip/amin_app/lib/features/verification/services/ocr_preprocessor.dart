import 'dart:io';
import 'dart:math' as math;

import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class OcrPreprocessor {
  const OcrPreprocessor();

  Future<String> grayContrastUpscale(String inputPath) async {
    final img.Image source = await _decode(inputPath);
    img.Image working = img.bakeOrientation(source);
    working = img.grayscale(working);

    if (working.width < 1600) {
      final double ratio = math.min(2.2, 1600 / working.width);
      working = img.copyResize(
        working,
        width: (working.width * ratio).round(),
        height: (working.height * ratio).round(),
        interpolation: img.Interpolation.cubic,
      );
    }

    working = img.adjustColor(working, contrast: 1.22);
    return _writeTemp(working, suffix: 'gray');
  }

  Future<String> binaryThreshold(String inputPath) async {
    final img.Image source = await _decode(inputPath);
    img.Image working = img.bakeOrientation(source);
    working = img.grayscale(working);

    if (working.width < 1600) {
      final double ratio = math.min(2.2, 1600 / working.width);
      working = img.copyResize(
        working,
        width: (working.width * ratio).round(),
        height: (working.height * ratio).round(),
        interpolation: img.Interpolation.cubic,
      );
    }

    working = img.adjustColor(working, contrast: 1.22);
    working = img.luminanceThreshold(working, threshold: 0.5);
    return _writeTemp(working, suffix: 'binary');
  }

  Future<img.Image> _decode(String inputPath) async {
    final List<int> bytes = await File(inputPath).readAsBytes();
    final img.Image? decoded = img.decodeImage(bytes);
    if (decoded == null) {
      throw const FormatException('فرمت تصویر برای پیش‌پردازش قابل خواندن نیست.');
    }
    return decoded;
  }

  Future<String> _writeTemp(img.Image image, {required String suffix}) async {
    final Directory directory = await getTemporaryDirectory();
    final String fileName = 'amin_ocr_${DateTime.now().microsecondsSinceEpoch}_$suffix.png';
    final File file = File(p.join(directory.path, fileName));
    await file.writeAsBytes(img.encodePng(image), flush: true);
    return file.path;
  }
}
