import 'dart:io';
import 'dart:math' as math;

import 'package:tesseract_ocr/ocr_engine_config.dart';
import 'package:tesseract_ocr/tesseract_ocr.dart';

import 'ocr_preprocessor.dart';

abstract interface class OcrService {
  Future<String> extractText(String imagePath);
}

/// Two-stage OCR policy derived from Amin's controlled OCR benchmark:
/// 1) always try the original cropped image first;
/// 2) only when the text-quality heuristic is low, run two enhanced variants
///    and keep the most Arabic-like output.
///
/// This avoids globally applying preprocessing that degraded clean images in
/// the benchmark, while retaining a fallback for difficult inputs.
class TesseractOcrService implements OcrService {
  const TesseractOcrService({
    this.preprocessor = const OcrPreprocessor(),
  });

  final OcrPreprocessor preprocessor;

  static const double fallbackQualityThreshold = 0.85;

  @override
  Future<String> extractText(String imagePath) async {
    final String raw = await _recognize(imagePath);
    if (_quality(raw) >= fallbackQualityThreshold) return raw.trim();

    String? grayPath;
    String? binaryPath;
    try {
      grayPath = await preprocessor.grayContrastUpscale(imagePath);
      binaryPath = await preprocessor.binaryThreshold(imagePath);
      final List<String> candidates = <String>[
        raw,
        await _recognize(grayPath),
        await _recognize(binaryPath),
      ];
      candidates.sort((String a, String b) => _quality(b).compareTo(_quality(a)));
      return candidates.first.trim();
    } finally {
      for (final String? path in <String?>[grayPath, binaryPath]) {
        if (path == null) continue;
        try {
          final File file = File(path);
          if (await file.exists()) await file.delete();
        } catch (_) {
          // Temporary-file cleanup must never fail the OCR result.
        }
      }
    }
  }

  Future<String> _recognize(String imagePath) async {
    final OCRConfig config = OCRConfig(
      language: 'ara+fas',
      engine: OCREngine.tesseract,
      options: const <String, dynamic>{
        'preserve_interword_spaces': '1',
        'tessedit_pageseg_mode': '6',
      },
    );
    final String text = await TesseractOcr.extractText(imagePath, config: config);
    return text.trim();
  }

  double _quality(String text) {
    final String compact = text.replaceAll(RegExp(r'\s+', unicode: true), '');
    if (compact.isEmpty) return 0;

    final RegExp arabic = RegExp(r'[\u0600-\u06FF]', unicode: true);
    var arabicCount = 0;
    var weirdCount = 0;
    for (final int rune in compact.runes) {
      final String char = String.fromCharCode(rune);
      if (arabic.hasMatch(char)) {
        arabicCount++;
      } else if (!RegExp(r'[0-9۰-۹٠-٩]', unicode: true).hasMatch(char)) {
        weirdCount++;
      }
    }
    final int length = math.max(1, compact.runes.length);
    final int tokenCount = text.trim().isEmpty
        ? 0
        : text.trim().split(RegExp(r'\s+', unicode: true)).length;
    return (arabicCount / length) +
        (math.min(tokenCount, 8) * 0.03) -
        ((weirdCount / length) * 0.5);
  }
}
