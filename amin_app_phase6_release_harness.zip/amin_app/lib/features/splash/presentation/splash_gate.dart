import 'dart:async';

import 'package:flutter/material.dart';

import '../../../core/config/competition_config.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/widgets/amin_logo_mark.dart';

class SplashGate extends StatefulWidget {
  const SplashGate({
    super.key,
    required this.child,
    this.duration = const Duration(milliseconds: 650),
  });

  final Widget child;
  final Duration duration;

  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> {
  bool _showApp = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer(widget.duration, () {
      if (mounted) setState(() => _showApp = true);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 260),
      child: _showApp
          ? KeyedSubtree(key: const ValueKey<String>('app'), child: widget.child)
          : const _BrandedSplash(key: ValueKey<String>('splash')),
    );
  }
}

class _BrandedSplash extends StatelessWidget {
  const _BrandedSplash({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.xl),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const AminLogoMark(size: 104),
                const SizedBox(height: AppSpacing.xl),
                Text(
                  CompetitionConfig.appName,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontSize: 34),
                ),
                const SizedBox(height: AppSpacing.xs),
                Text(
                  CompetitionConfig.appSubtitle,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: AppSpacing.sm),
                Text(
                  CompetitionConfig.tagline,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
