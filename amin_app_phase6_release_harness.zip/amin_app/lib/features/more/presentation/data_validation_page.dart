import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../data/quality_report_service.dart';

class DataValidationPage extends StatelessWidget {
  const DataValidationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('داده‌ها و اعتبارسنجی')),
        body: FutureBuilder<QualityReportBundle>(
          future: const QualityReportService().load(),
          builder: (BuildContext context, AsyncSnapshot<QualityReportBundle> snapshot) {
            if (snapshot.hasError) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(AppSpacing.xl),
                  child: Text('خواندن گزارش‌های اعتبارسنجی انجام نشد: ${snapshot.error}'),
                ),
              );
            }
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            return _ReportBody(bundle: snapshot.data!);
          },
        ),
      ),
    );
  }
}

class _ReportBody extends StatelessWidget {
  const _ReportBody({required this.bundle});

  final QualityReportBundle bundle;

  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic> release = bundle.releaseValidation;
    final Map<String, dynamic> benchmark = bundle.benchmark;
    final Map<String, dynamic> challenge = bundle.challenge;
    final Map<String, dynamic> testMetrics = benchmark['test_metrics'] as Map<String, dynamic>? ?? <String, dynamic>{};
    final Map<String, dynamic> counts = release['counts'] as Map<String, dynamic>? ?? <String, dynamic>{};
    final String hash = release['database_sha256']?.toString() ?? 'نامشخص';

    return ListView(
      padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.sm, AppSpacing.lg, AppSpacing.xxxl),
      children: <Widget>[
        _HeroStatus(passed: release['passed'] == true),
        const SizedBox(height: AppSpacing.xl),
        Text('پوشش پایگاه', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: AppSpacing.sm),
        Row(
          children: <Widget>[
            Expanded(child: _MetricTile(value: '${release['total_passages'] ?? 6317}', label: 'کل مدخل‌ها')),
            const SizedBox(width: AppSpacing.sm),
            Expanded(child: _MetricTile(value: '${counts['quran'] ?? 6236}', label: 'آیات قرآن')),
          ],
        ),
        const SizedBox(height: AppSpacing.sm),
        Row(
          children: <Widget>[
            Expanded(child: _MetricTile(value: '${counts['nahjAlBalagha'] ?? 55}', label: 'گزیده نهج')),
            const SizedBox(width: AppSpacing.sm),
            Expanded(child: _MetricTile(value: '${counts['sahifaSajjadiya'] ?? 26}', label: 'گزیده صحیفه')),
          ],
        ),
        const SizedBox(height: AppSpacing.xl),
        Text('آزمون موتور منبع‌یابی', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: AppSpacing.sm),
        _InfoCard(
          children: <Widget>[
            _InfoRow(label: 'Test frozen', value: '${testMetrics['cases'] ?? '-'} مورد'),
            _InfoRow(label: 'Strict precision', value: _pct(testMetrics['strict_precision_pct'])),
            _InfoRow(label: 'Strict recall', value: _pct(testMetrics['strict_recall_pct'])),
            _InfoRow(label: 'Strict F1', value: _pct(testMetrics['strict_f1_pct'])),
            _InfoRow(label: 'False positive rate', value: _pct(testMetrics['false_positive_rate_pct'])),
            _InfoRow(label: 'Top-1 passage', value: _pct(testMetrics['top1_passage_accuracy_pct'])),
            _InfoRow(label: 'آستانه پذیرش', value: '${testMetrics['acceptance_threshold'] ?? '-'}'),
          ],
        ),
        const SizedBox(height: AppSpacing.md),
        _InfoCard(
          children: <Widget>[
            _InfoRow(label: 'Challenge set', value: '${challenge['cases'] ?? '-'} مورد'),
            _InfoRow(label: 'دقت', value: _pct(challenge['accuracy_pct'])),
            const Padding(
              padding: EdgeInsets.only(top: AppSpacing.xs),
              child: Text('Challenge set بعد از تعیین آستانه ساخته و فریز شده و در کالیبراسیون استفاده نشده است.'),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.xl),
        Text('کنترل تمامیت انتشار', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: AppSpacing.sm),
        _CheckList(checks: release['checks'] as Map<String, dynamic>? ?? <String, dynamic>{}),
        const SizedBox(height: AppSpacing.md),
        _HashCard(hash: hash),
        const SizedBox(height: AppSpacing.xl),
        Text('OCR', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: AppSpacing.sm),
        if (bundle.ocrBenchmark == null)
          const _InfoCard(
            children: <Widget>[
              Text('گزارش Benchmark OCR هنوز داخل این Build بسته‌بندی نشده است.'),
            ],
          )
        else
          _OcrCard(report: bundle.ocrBenchmark!),
        const SizedBox(height: AppSpacing.xl),
        Container(
          padding: const EdgeInsets.all(AppSpacing.md),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.45),
            borderRadius: BorderRadius.circular(AppRadius.md),
          ),
          child: const Text(
            'محدودیت علمی: اعداد Benchmark کیفیت بازیابی متن و رد/پذیرش را روی مجموعه آزمون تعریف‌شده می‌سنجند؛ این اعداد به معنای ارزیابی سند حدیث یا تضمین عملکرد روی همه تصاویر و نقل‌قول‌های دنیای واقعی نیستند.',
          ),
        ),
      ],
    );
  }

  static String _pct(Object? value) {
    if (value == null) return '-';
    return '$value٪';
  }
}

class _HeroStatus extends StatelessWidget {
  const _HeroStatus({required this.passed});

  final bool passed;

  @override
  Widget build(BuildContext context) {
    final Color color = passed ? Colors.green.shade700 : Theme.of(context).colorScheme.error;
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: color.withValues(alpha: 0.25)),
      ),
      child: Row(
        children: <Widget>[
          Icon(passed ? Icons.verified_rounded : Icons.error_outline_rounded, color: color, size: 34),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(passed ? 'اعتبارسنجی انتشار: موفق' : 'اعتبارسنجی انتشار: نیازمند بررسی', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: AppSpacing.xxs),
                Text('کنترل ساختار SQLite، شمارش قرآن، شناسه‌ها، متن نرمال‌شده و Hash پایگاه.', style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricTile extends StatelessWidget {
  const _MetricTile({required this.value, required this.label});

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        children: <Widget>[
          Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Theme.of(context).colorScheme.primary)),
          const SizedBox(height: AppSpacing.xxs),
          Text(label, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(children: children),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(label)),
          const SizedBox(width: AppSpacing.sm),
          Text(value, style: Theme.of(context).textTheme.labelLarge),
        ],
      ),
    );
  }
}

class _CheckList extends StatelessWidget {
  const _CheckList({required this.checks});

  final Map<String, dynamic> checks;

  @override
  Widget build(BuildContext context) {
    final List<MapEntry<String, dynamic>> entries = checks.entries.toList();
    return _InfoCard(
      children: entries.map((MapEntry<String, dynamic> item) {
        final bool passed = item.value == true;
        return ListTile(
          dense: true,
          contentPadding: EdgeInsets.zero,
          leading: Icon(passed ? Icons.check_circle_rounded : Icons.cancel_outlined, color: passed ? Colors.green.shade700 : Theme.of(context).colorScheme.error),
          title: Text(_humanizeCheck(item.key)),
        );
      }).toList(growable: false),
    );
  }

  static String _humanizeCheck(String key) {
    const Map<String, String> labels = <String, String>{
      'sqlite_quick_check': 'سلامت ساختار SQLite',
      'database_sha256_matches_manifest': 'تطابق Hash پایگاه با Manifest',
      'total_passages_matches_manifest': 'تطابق تعداد مدخل‌ها',
      'quran_6236': 'وجود ۶۲۳۶ آیه قرآن',
      'quran_114_surahs': 'وجود ۱۱۴ سوره',
      'unique_passage_ids': 'یکتا بودن شناسه مدخل‌ها',
      'nonempty_normalized_text': 'نبود متن نرمال‌شده خالی',
    };
    return labels[key] ?? key;
  }
}

class _HashCard extends StatelessWidget {
  const _HashCard({required this.hash});

  final String hash;

  @override
  Widget build(BuildContext context) {
    return _InfoCard(
      children: <Widget>[
        Align(alignment: Alignment.centerRight, child: Text('SHA-256 پایگاه', style: Theme.of(context).textTheme.labelLarge)),
        const SizedBox(height: AppSpacing.xs),
        SelectableText(hash, textDirection: TextDirection.ltr),
        const SizedBox(height: AppSpacing.sm),
        OutlinedButton.icon(
          onPressed: () async {
            await Clipboard.setData(ClipboardData(text: hash));
            if (!context.mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Hash کپی شد.')));
          },
          icon: const Icon(Icons.copy_rounded),
          label: const Text('کپی Hash'),
        ),
      ],
    );
  }
}

class _OcrCard extends StatelessWidget {
  const _OcrCard({required this.report});

  final Map<String, dynamic> report;

  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic> selected = report['selected_profile'] as Map<String, dynamic>? ?? <String, dynamic>{};
    final Map<String, dynamic> metrics = report['overall_metrics'] as Map<String, dynamic>? ?? <String, dynamic>{};
    return _InfoCard(
      children: <Widget>[
        _InfoRow(label: 'پروفایل انتخابی', value: selected['name'] == 'adaptive_multipass' ? 'چندمرحله‌ای تطبیقی' : (selected['name']?.toString() ?? '-')),
        _InfoRow(label: 'تعداد تصاویر آزمون', value: report['image_count']?.toString() ?? '-'),
        _InfoRow(label: 'CER نرمال‌شده', value: '${metrics['normalized_cer_pct'] ?? '-'}٪'),
        _InfoRow(label: 'WER نرمال‌شده', value: '${metrics['normalized_wer_pct'] ?? '-'}٪'),
        _InfoRow(label: 'Top-1 منبع‌یابی پس از OCR', value: '${metrics['verification_top1_pct'] ?? '-'}٪'),
        _InfoRow(label: 'پذیرش صحیح پس از OCR', value: '${metrics['verification_accepted_correct_pct'] ?? '-'}٪'),
      ],
    );
  }
}
