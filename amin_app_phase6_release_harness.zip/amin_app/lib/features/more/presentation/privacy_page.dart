import 'package:flutter/material.dart';

import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';

class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('حریم خصوصی و داده‌ها')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.xxl),
          children: const <Widget>[
            _PrivacySection(
              icon: Icons.offline_bolt_outlined,
              title: 'پردازش محلی',
              body: 'هسته تطبیق، جست‌وجوی منابع و OCR عربی/فارسی در نسخه مسابقه‌ای روی خود دستگاه اجرا می‌شوند. برای این وظایف حساب کاربری یا ارسال متن به سرور لازم نیست.',
            ),
            _PrivacySection(
              icon: Icons.history_rounded,
              title: 'تاریخچه بررسی‌ها',
              body: 'متن ورودی، نوع ورودی، امتیاز و snapshot نتیجه در SQLite محلی ذخیره می‌شود تا کاربر بتواند نتیجه را دوباره ببیند. تاریخچه از داخل برنامه قابل حذف کامل یا موردی است.',
            ),
            _PrivacySection(
              icon: Icons.image_not_supported_outlined,
              title: 'تصاویر',
              body: 'امین تصویر انتخاب‌شده را برای تاریخچه کپی یا بایگانی نمی‌کند. پس از OCR فقط متن استخراج‌شده وارد مسیر راستی‌آزمایی و تاریخچه می‌شود.',
            ),
            _PrivacySection(
              icon: Icons.camera_alt_outlined,
              title: 'مجوزها',
              body: 'دسترسی دوربین فقط هنگام انتخاب «گرفتن عکس» درخواست می‌شود. انتخاب تصویر از گالری نیز فقط با اقدام مستقیم کاربر انجام می‌شود.',
            ),
            _PrivacySection(
              icon: Icons.delete_forever_outlined,
              title: 'حذف داده محلی',
              body: 'کاربر می‌تواند تمام تاریخچه را از صفحه «تاریخچه» پاک کند. حذف برنامه نیز داده‌های محلی کاربر را از فضای اختصاصی برنامه حذف می‌کند؛ فایل پایگاه منابع جزو خود برنامه است.',
            ),
            _PrivacySection(
              icon: Icons.shield_outlined,
              title: 'اصل کمینه‌سازی داده',
              body: 'نسخه مسابقه‌ای ثبت‌نام، پروفایل، تبلیغات، ردیابی کاربر، شناسه تبلیغاتی یا همگام‌سازی ابری ندارد.',
            ),
          ],
        ),
      ),
    );
  }
}

class _PrivacySection extends StatelessWidget {
  const _PrivacySection({required this.icon, required this.title, required this.body});

  final IconData icon;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(icon, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title, style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: AppSpacing.xs),
                Text(body, style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.85)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
