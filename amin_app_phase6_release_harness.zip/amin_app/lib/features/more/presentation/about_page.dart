import 'package:flutter/material.dart';

import '../../../core/config/competition_config.dart';
import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/widgets/amin_logo_mark.dart';
import 'data_validation_page.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    final bool authorConfigured = CompetitionConfig.hasReleaseAuthor;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('درباره امین')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.xxl),
          children: <Widget>[
            const SizedBox(height: AppSpacing.sm),
            const Center(child: AminLogoMark(size: 78)),
            const SizedBox(height: AppSpacing.md),
            Text(
              CompetitionConfig.appName,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: AppSpacing.xxs),
            Text(
              CompetitionConfig.appSubtitle,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: AppSpacing.xs),
            Text(
              CompetitionConfig.tagline,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: AppSpacing.xl),
            const _InfoCard(
              title: 'هدف محصول',
              icon: Icons.track_changes_rounded,
              children: <Widget>[
                Text(
                  'امین برای جست‌وجو، منبع‌یابی و مقایسه متنیِ نقل‌قول‌های منتسب به قرآن و عترت طراحی شده است. برنامه متن یا خروجی OCR را با پایگاه نسخه‌دار منابع مقایسه می‌کند و نزدیک‌ترین مدخل را همراه با میزان تطابق و اختلاف‌های واژگانی نشان می‌دهد.',
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            _InfoCard(
              title: 'پدیدآورنده',
              icon: Icons.person_outline_rounded,
              children: <Widget>[
                _KeyValue(label: 'صاحب اثر', value: CompetitionConfig.authorName),
                if (CompetitionConfig.authorAffiliation.isNotEmpty)
                  _KeyValue(label: 'دانشگاه/واحد', value: CompetitionConfig.authorAffiliation),
                if (CompetitionConfig.authorContact.isNotEmpty)
                  _KeyValue(label: 'راه ارتباطی', value: CompetitionConfig.authorContact),
                if (!authorConfigured)
                  Container(
                    margin: const EdgeInsets.only(top: AppSpacing.sm),
                    padding: const EdgeInsets.all(AppSpacing.sm),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.errorContainer,
                      borderRadius: BorderRadius.circular(AppRadius.sm),
                    ),
                    child: const Text(
                      'نسخه توسعه است. Build مسابقه‌ای فقط وقتی ساخته می‌شود که نام صاحب اثر با AMIN_AUTHOR_NAME مشخص شده باشد.',
                    ),
                  ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            const _InfoCard(
              title: 'محدودیت علمی',
              icon: Icons.science_outlined,
              children: <Widget>[
                Text(
                  'یافتن یک متن در منبع به معنای ارزیابی سند حدیث یا صدور حکم درباره صحت حدیث نیست. امین در نسخه فعلی تطابق متنی و منبع‌یابی انجام می‌دهد. همچنین نبودِ نتیجه کافی در پایگاه فعلی، به‌تنهایی دلیل بر نادرست بودن عبارت نیست.',
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            _InfoCard(
              title: 'مشخصات نسخه',
              icon: Icons.info_outline_rounded,
              children: <Widget>[
                const _KeyValue(label: 'نسخه', value: '${CompetitionConfig.versionName} (${CompetitionConfig.versionCode})'),
                const _KeyValue(label: 'شناسه بسته', value: CompetitionConfig.packageName),
                const _KeyValue(label: 'حالت پردازش', value: 'آفلاین و روی دستگاه'),
                const SizedBox(height: AppSpacing.sm),
                OutlinedButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => const DataValidationPage()),
                  ),
                  icon: const Icon(Icons.fact_check_outlined),
                  label: const Text('مشاهده داده‌ها و اعتبارسنجی'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.title, required this.icon, required this.children});

  final String title;
  final IconData icon;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: DefaultTextStyle.merge(
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.85),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                Icon(icon, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: AppSpacing.sm),
                Text(title, style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            ...children,
          ],
        ),
      ),
    );
  }
}

class _KeyValue extends StatelessWidget {
  const _KeyValue({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.xs),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(width: 92, child: Text(label, style: Theme.of(context).textTheme.labelLarge)),
          Expanded(child: SelectableText(value)),
        ],
      ),
    );
  }
}
