import 'package:flutter/material.dart';

import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';

class GuidePage extends StatelessWidget {
  const GuidePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('راهنمای استفاده')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.xxl),
          children: <Widget>[
            Text('شروع سریع', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: AppSpacing.sm),
            const _StepCard(
              number: '۱',
              title: 'نوع ورودی را انتخاب کنید',
              body: 'از خانه «بررسی متن» یا «بررسی تصویر» را باز کنید. برای دمو بدون وابستگی به دوربین، گزینه نمونه آماده نیز در دسترس است.',
            ),
            const _StepCard(
              number: '۲',
              title: 'متن را تأیید کنید',
              body: 'در مسیر تصویر، خروجی OCR قبل از منبع‌یابی قابل ویرایش است. این مرحله برای جلوگیری از تبدیل خطای OCR به نتیجه نادرست طراحی شده است.',
            ),
            const _StepCard(
              number: '۳',
              title: 'نتیجه را بخوانید',
              body: 'درصد تطابق، سطح نتیجه، نزدیک‌ترین منبع و اختلاف‌های واژگانی نمایش داده می‌شوند. از «مشاهده متن کامل» می‌توانید وارد شناسنامه مدخل شوید.',
            ),
            const _StepCard(
              number: '۴',
              title: 'نتیجه‌های قبلی را مرور کنید',
              body: 'هر بررسی به‌صورت محلی در تاریخچه ذخیره می‌شود. با لمس هر مورد، snapshot همان نتیجه دوباره باز می‌شود.',
            ),
            const SizedBox(height: AppSpacing.xl),
            Text('معنای سطح نتیجه', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: AppSpacing.sm),
            const _MeaningCard(
              icon: Icons.verified_rounded,
              title: 'تطابق مستقیم / بسیار بالا',
              body: 'متن ورودی با یک مدخل در پایگاه شباهت بسیار بالایی دارد. جزئیات منبع و اختلاف‌ها را همچنان بررسی کنید.',
            ),
            const _MeaningCard(
              icon: Icons.compare_arrows_rounded,
              title: 'متن مشابه یافت شد',
              body: 'منبعی نزدیک پیدا شده، اما اختلاف قابل توجه وجود دارد. نمای «اختلاف‌ها» برای همین وضعیت اهمیت دارد.',
            ),
            const _MeaningCard(
              icon: Icons.manage_search_rounded,
              title: 'منبع قابل اتکایی پیدا نشد',
              body: 'بهترین گزینه زیر آستانه پذیرش بوده است. این پیام به‌تنهایی به معنای جعلی یا نادرست بودن عبارت نیست.',
            ),
            const SizedBox(height: AppSpacing.xl),
            Container(
              padding: const EdgeInsets.all(AppSpacing.md),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.45),
                borderRadius: BorderRadius.circular(AppRadius.md),
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Icon(Icons.tips_and_updates_outlined),
                  SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: Text(
                      'برای داوری: از «اجرای نمونه» شروع کنید، سپس اختلاف متن را نمایش دهید، شناسنامه منبع را باز کنید و در پایان صفحه «داده‌ها و اعتبارسنجی» را نشان دهید.',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StepCard extends StatelessWidget {
  const _StepCard({required this.number, required this.title, required this.body});

  final String number;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(AppRadius.md),
          border: Border.all(color: Theme.of(context).dividerColor),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            CircleAvatar(
              radius: 18,
              backgroundColor: Theme.of(context).colorScheme.primaryContainer,
              child: Text(number, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w900)),
            ),
            const SizedBox(width: AppSpacing.sm),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: AppSpacing.xs),
                  Text(body, style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.8)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MeaningCard extends StatelessWidget {
  const _MeaningCard({required this.icon, required this.title, required this.body});

  final IconData icon;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: AppSpacing.xs),
      leading: Icon(icon, color: Theme.of(context).colorScheme.primary),
      title: Text(title),
      subtitle: Text(body),
    );
  }
}
