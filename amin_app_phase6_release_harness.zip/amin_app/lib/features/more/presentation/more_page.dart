import 'package:flutter/material.dart';

import '../../../core/config/competition_config.dart';
import '../../../core/theme/app_spacing.dart';
import 'about_page.dart';
import 'data_validation_page.dart';
import 'guide_page.dart';
import 'privacy_page.dart';

class MorePage extends StatelessWidget {
  const MorePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        children: <Widget>[
          Text('بیشتر', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: AppSpacing.xs),
          Text(
            '${CompetitionConfig.appName} • نسخه ${CompetitionConfig.versionName}',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: AppSpacing.md),
          _MoreTile(
            icon: Icons.info_outline_rounded,
            title: 'درباره امین',
            subtitle: 'معرفی محصول، پدیدآورنده و محدودیت علمی',
            onTap: () => _push(context, const AboutPage()),
          ),
          _MoreTile(
            icon: Icons.help_outline_rounded,
            title: 'راهنمای استفاده',
            subtitle: 'مسیر متن، تصویر، نتیجه و معنی سطح تطابق',
            onTap: () => _push(context, const GuidePage()),
          ),
          const _MoreTile(
            icon: Icons.palette_outlined,
            title: 'تنظیمات نمایش',
            subtitle: 'در نسخه بعدی: اندازه متن و حالت نمایش',
            enabled: false,
          ),
          _MoreTile(
            icon: Icons.shield_outlined,
            title: 'حریم خصوصی و داده‌ها',
            subtitle: 'پردازش محلی، تاریخچه و مجوزها',
            onTap: () => _push(context, const PrivacyPage()),
          ),
          _MoreTile(
            icon: Icons.fact_check_outlined,
            title: 'داده‌ها و اعتبارسنجی',
            subtitle: 'پوشش منابع، Hash، Benchmark و محدودیت‌های علمی',
            onTap: () => _push(context, const DataValidationPage()),
          ),
          const SizedBox(height: AppSpacing.lg),
          Center(
            child: Text(
              CompetitionConfig.packageName,
              style: Theme.of(context).textTheme.bodySmall,
              textDirection: TextDirection.ltr,
            ),
          ),
        ],
      ),
    );
  }

  void _push(BuildContext context, Widget page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }
}

class _MoreTile extends StatelessWidget {
  const _MoreTile({
    required this.icon,
    required this.title,
    this.subtitle,
    this.onTap,
    this.enabled = true,
  });

  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback? onTap;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      enabled: enabled,
      leading: Icon(icon),
      title: Text(title),
      subtitle: subtitle == null ? null : Text(subtitle!),
      trailing: enabled ? const Icon(Icons.chevron_left_rounded) : null,
      onTap: enabled ? onTap : null,
    );
  }
}
