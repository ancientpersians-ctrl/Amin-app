import 'dart:convert';

import 'package:flutter/services.dart';

class QualityReportBundle {
  const QualityReportBundle({
    required this.releaseValidation,
    required this.corpusValidation,
    required this.benchmark,
    required this.challenge,
    this.ocrBenchmark,
  });

  final Map<String, dynamic> releaseValidation;
  final Map<String, dynamic> corpusValidation;
  final Map<String, dynamic> benchmark;
  final Map<String, dynamic> challenge;
  final Map<String, dynamic>? ocrBenchmark;
}

class QualityReportService {
  const QualityReportService();

  Future<QualityReportBundle> load() async {
    final List<Map<String, dynamic>?> values = await Future.wait<Map<String, dynamic>?>(<Future<Map<String, dynamic>?>>[
      _readJson('assets/data/quality/release_validation.json'),
      _readJson('assets/data/quality/corpus_validation.json'),
      _readJson('assets/data/quality/benchmark_results.json'),
      _readJson('assets/data/quality/challenge_results.json'),
      _readOptionalJson('assets/data/quality/ocr_benchmark_results.json'),
    ]);
    return QualityReportBundle(
      releaseValidation: values[0]!,
      corpusValidation: values[1]!,
      benchmark: values[2]!,
      challenge: values[3]!,
      ocrBenchmark: values[4],
    );
  }

  Future<Map<String, dynamic>> _readJson(String path) async {
    final String raw = await rootBundle.loadString(path);
    return jsonDecode(raw) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>?> _readOptionalJson(String path) async {
    try {
      return await _readJson(path);
    } on FlutterError {
      return null;
    }
  }
}
