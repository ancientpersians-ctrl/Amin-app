import 'dart:math' as math;

import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'package:amin_app/features/verification/data/database_source_repository.dart';
import 'package:amin_app/features/verification/domain/verification_engine.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('text verification performance probe on Android runtime',
      (WidgetTester tester) async {
    final DatabaseSourceRepository repository = await DatabaseSourceRepository.open();
    final VerificationEngine engine = VerificationEngine(repository: repository);

    const List<String> queries = <String>[
      'ان الله مع الصابرین',
      'لا اکراه فی الدین',
      'فان مع العسر یسرا',
      'و قل رب زدنی علما',
      'ان اكرمكم عند الله اتقاكم',
    ];

    // Warm the SQLite page cache and Dart JIT/runtime paths on the device.
    for (final String query in queries) {
      await engine.verify(query);
    }

    final List<int> samplesMs = <int>[];
    for (var round = 0; round < 8; round++) {
      for (final String query in queries) {
        final Stopwatch stopwatch = Stopwatch()..start();
        final result = await engine.verify(query);
        stopwatch.stop();
        expect(result.score, greaterThanOrEqualTo(0));
        samplesMs.add(stopwatch.elapsedMilliseconds);
      }
    }

    samplesMs.sort();
    final int median = samplesMs[samplesMs.length ~/ 2];
    final int p95Index = math.min(samplesMs.length - 1, (samplesMs.length * 0.95).ceil() - 1);
    final int p95 = samplesMs[p95Index];
    final int maxMs = samplesMs.last;

    // Logged values are evidence for the release report; they intentionally do
    // not hard-fail CI because hosted-emulator load is variable.
    // ignore: avoid_print
    print('AMIN_PERF text_verify samples=${samplesMs.length} median_ms=$median p95_ms=$p95 max_ms=$maxMs');
  });
}
