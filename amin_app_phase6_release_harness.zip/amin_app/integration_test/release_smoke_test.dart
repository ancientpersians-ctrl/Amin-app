import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'package:amin_app/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('release smoke: launch, text verification, result, source detail',
      (WidgetTester tester) async {
    await app.main();
    await tester.pumpAndSettle(const Duration(seconds: 3));

    expect(find.text('امین'), findsWidgets);
    expect(find.text('بررسی متن'), findsOneWidget);

    await tester.tap(find.text('بررسی متن'));
    await tester.pumpAndSettle();

    final Finder input = find.byType(EditableText);
    expect(input, findsOneWidget);
    await tester.enterText(input, 'ان الله مع الصابرین');
    await tester.pump();

    await tester.tap(find.text('بررسی منبع'));
    await tester.pumpAndSettle(const Duration(seconds: 5));

    expect(find.textContaining('تطابق'), findsWidgets);
    expect(find.textContaining('البقرة'), findsWidgets);
    expect(find.textContaining('153'), findsWidgets);

    final Finder sourceButton = find.text('مشاهده متن کامل و شناسنامه منبع');
    expect(sourceButton, findsOneWidget);
    await tester.ensureVisible(sourceButton);
    await tester.tap(sourceButton);
    await tester.pumpAndSettle();

    expect(find.textContaining('قرآن'), findsWidgets);
  });
}
