# Amin Source Verification Benchmark v1

## هدف

اندازه‌گیری سه توانایی موتور «امین»:

1. بازیابی منبع برای نقل‌قول صحیح؛
2. بازیابی منبع پایه برای نقل‌قول دارای حذف/تغییر واژه؛
3. رد کردن متن نامرتبط به corpus به جای ساختن یک منبع کاذب.

## پروتکل اصلی

Benchmark اصلی **720 مورد** دارد و با seed ثابت `14050329` قابل بازتولید است:

- Dev: 240 مورد — فقط برای تعیین آستانه پذیرش
- Test: 480 مورد — فقط برای گزارش نهایی
- شش دسته: exact، orthographic، one-token-deleted، one-token-replaced، short-snippet، unrelated
- در هر دسته مثبت، ترکیب منبع تقریباً 70٪ قرآن، 15٪ نهج منتخب و 15٪ صحیفه منتخب است.
- passageهای Dev و Test از هم جدا می‌شوند تا آستانه روی همان متن‌های Test تنظیم نشود.
- برای quoteهای واقعاً تکراری، `acceptable_passage_ids` می‌تواند بیش از یک منبع معتبر داشته باشد.

### آستانه

آستانه روی Dev انتخاب شده است:

- شرط: False Positive Rate حداکثر 5٪
- هدف: بیشینه‌کردن strict end-to-end F1
- آستانه فریز شده: **0.63 (63٪)**
- Candidate retrieval: **Top 8**

## نتیجه Test فریز شده (480 مورد)

| معیار | نتیجه |
|---|---:|
| Strict precision | **99.50٪** |
| Strict recall | **100.00٪** |
| Strict F1 | **99.75٪** |
| False-positive rate روی unrelated | **2.50٪** |
| Top-1 passage accuracy روی موارد مثبت | **100.00٪** |
| Top-3 passage accuracy | **100.00٪** |

### بر حسب دسته

- Exact: 100٪ Top-1
- Orthographic: 100٪ Top-1
- حذف یک واژه: 100٪ Top-1
- تغییر یک واژه: 100٪ Top-1
- snippet کوتاه: 100٪ Top-1
- unrelated: 2.5٪ از موارد از آستانه عبور کرده‌اند (یعنی 97.5٪ درست رد شده‌اند).

> اعداد بالا مربوط به benchmark مصنوعی/کنترل‌شده و reproducible هستند؛ برای جلوگیری از بزرگ‌نمایی، آن‌ها را «دقت دنیای واقعی» نمی‌نامیم.

## Challenge Set دستی — خارج از calibration

برای کاهش وابستگی به perturbation مصنوعی، یک مجموعه جداگانه **55 مورد دستی** پس از فریز آستانه اجرا شد:

- 19 نقل‌قول صحیح/رایج با نگارش ساده: **19/19 = 100٪**
- 18 نقل‌قول تحریف‌شده دستی و plausible: **17/18 = 94.44٪**
- 18 متن نامرتبط/مذهبی‌نما: **18/18 = 100٪ رد صحیح**
- کل: **54/55 = 98.18٪**

یک failure عمداً در گزارش نگه داشته شده است: عبارت تغییر‌یافته `الناس اعداء ما لا يعرفون` منبع درست نهج‌البلاغه را در رتبه اول پیدا می‌کند، اما score آن **60.76٪** است و از آستانه 63٪ عبور نمی‌کند. این مورد نشان می‌دهد آستانه برای کاهش مثبت کاذب، محافظه‌کارانه است.

## زمان اجرا

Reference engine پایتون در container فعلی روی Test:

- median: حدود **23.5 ms**
- p95: حدود **52.85 ms**

این اعداد **Benchmark Android نیستند**. زمان Android باید بعداً روی گوشی هدف اندازه‌گیری و جداگانه گزارش شود.

## محدودیت علمی

این benchmark «اعتبار حدیث» یا سندشناسی را اندازه نمی‌گیرد. تنها می‌سنجد که موتور:

- متن را به passage موجود در corpus برساند؛
- اختلاف نوشتاری/واژگانی محدود را تحمل کند؛
- و در برابر متن نامرتبط منبع نسازد.

در نتیجه عبارت درست برای ارائه به داور این است: **«دقت بازیابی/راستی‌آزمایی منبع در مجموعه آزمون فریز‌شده»**، نه «درصد صحت دینی هوش مصنوعی».

## بازتولید

```bash
python tool/build_corpus.py
python tool/validate_corpus.py
python tool/generate_benchmark.py
python tool/run_benchmark.py
python tool/build_challenge_set.py
python tool/run_challenge_set.py
```

خروجی‌های machine-readable:

- `benchmark/benchmark_manifest.json`
- `benchmark/benchmark_cases.jsonl`
- `benchmark/benchmark_results.json`
- `benchmark/benchmark_predictions.jsonl`
- `benchmark/challenge_set.jsonl`
- `benchmark/challenge_results.json`
- `benchmark/challenge_predictions.jsonl`
