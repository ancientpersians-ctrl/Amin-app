from __future__ import annotations

import argparse
import hashlib
import json
import re
import sqlite3
from pathlib import Path
from typing import Iterable

from text_normalizer import compact_ngrams, normalize, tokens

DEFAULT_QURAN_TEXT = Path('/usr/share/texlive/texmf-dist/tex/latex/quran/qurantext-uthmani.def')
DEFAULT_QURAN_STY = Path('/usr/share/texlive/texmf-dist/tex/latex/quran/quran.sty')

VERSE_COUNTS = [7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6]
SURAH_NAMES_AR = ['الفاتحة','البقرة','آل عمران','النساء','المائدة','الأنعام','الأعراف','الأنفال','التوبة','يونس','هود','يوسف','الرعد','إبراهيم','الحجر','النحل','الإسراء','الكهف','مريم','طه','الأنبياء','الحج','المؤمنون','النور','الفرقان','الشعراء','النمل','القصص','العنكبوت','الروم','لقمان','السجدة','الأحزاب','سبأ','فاطر','يس','الصافات','ص','الزمر','غافر','فصلت','الشورى','الزخرف','الدخان','الجاثية','الأحقاف','محمد','الفتح','الحجرات','ق','الذاريات','الطور','النجم','القمر','الرحمن','الواقعة','الحديد','المجادلة','الحشر','الممتحنة','الصف','الجمعة','المنافقون','التغابن','الطلاق','التحريم','الملك','القلم','الحاقة','المعارج','نوح','الجن','المزمل','المدثر','القيامة','الإنسان','المرسلات','النبأ','النازعات','عبس','التكوير','الإنفطار','المطففين','الانشقاق','البروج','الطارق','الأعلى','الغاشية','الفجر','البلد','الشمس','الليل','الضحى','الشرح','التين','العلق','القدر','البينة','الزلزلة','العاديات','القارعة','التكاثر','العصر','الهمزة','الفيل','قريش','الماعون','الكوثر','الكافرون','النصر','المسد','الإخلاص','الفلق','الناس']


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode('utf-8'))


def parse_quran_version(sty_path: Path) -> tuple[str, str]:
    text = sty_path.read_text(encoding='utf-8')
    version = re.search(r'\\def\\quranversion\{([^}]+)\}', text)
    date = re.search(r'\\def\\qurandate\{([^}]+)\}', text)
    return (version.group(1) if version else 'unknown', date.group(1) if date else 'unknown')


def parse_quran(text_path: Path) -> list[dict]:
    raw = text_path.read_text(encoding='utf-8')
    bodies = re.findall(r'\\qt@newcmd\\qurantext@[^{]+\{(.*?)\}\s*$', raw, re.M)
    if len(bodies) != 6236:
        raise ValueError(f'Expected 6236 Quran entries, got {len(bodies)}')
    if sum(VERSE_COUNTS) != 6236 or len(VERSE_COUNTS) != 114:
        raise ValueError('Internal Quran structure constants are invalid')

    passages: list[dict] = []
    global_index = 0
    for surah_no, count in enumerate(VERSE_COUNTS, start=1):
        surah_name = SURAH_NAMES_AR[surah_no - 1]
        for ayah_no in range(1, count + 1):
            body = bodies[global_index]
            global_index += 1
            # quran.sty inserts basmala before the first verse of most surahs as
            # presentation markup. It is not part of that ayah in the 6236-ayah
            # canonical structure (except Al-Fatiha, whose verse 1 is already text).
            body = body.replace('\\basmalah', '').strip()
            body = re.sub(r'\\qt@no\{[^}]*\}', '', body).strip()
            if '\\' in body:
                raise ValueError(f'Unexpected TeX macro in Quran {surah_no}:{ayah_no}: {body}')
            passages.append({
                'id': f'quran-{surah_no}-{ayah_no}',
                'kind': 'quran',
                'source_title': 'قرآن کریم',
                'section_title': surah_name,
                'section_number': surah_no,
                'passage_number': str(ayah_no),
                'reference': f'سوره {surah_name}، آیه {ayah_no}',
                'text': body,
                'provenance_locator': f'quran package uthmani text, global={global_index}, verse={surah_no}:{ayah_no}',
            })
    return passages


def load_curated(path: Path) -> list[dict]:
    return json.loads(path.read_text(encoding='utf-8'))


def unique_preserving_order(items: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        if item and item not in seen:
            seen.add(item)
            out.append(item)
    return out


def schema(conn: sqlite3.Connection) -> None:
    conn.executescript('''
    PRAGMA journal_mode=OFF;
    PRAGMA synchronous=OFF;
    PRAGMA temp_store=MEMORY;
    CREATE TABLE meta(
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    CREATE TABLE sources(
      id TEXT PRIMARY KEY,
      kind TEXT NOT NULL,
      title_fa TEXT NOT NULL,
      title_ar TEXT,
      edition TEXT,
      scope TEXT NOT NULL,
      language TEXT NOT NULL,
      source_url TEXT,
      license TEXT,
      attribution TEXT,
      version TEXT,
      retrieved_at TEXT,
      sha256 TEXT,
      notes TEXT
    );
    CREATE TABLE passages(
      id TEXT PRIMARY KEY,
      source_id TEXT NOT NULL REFERENCES sources(id),
      kind TEXT NOT NULL,
      reference TEXT NOT NULL,
      section_title TEXT,
      section_number INTEGER,
      passage_number TEXT,
      original_text TEXT NOT NULL,
      normalized_text TEXT NOT NULL,
      token_count INTEGER NOT NULL,
      display_order INTEGER NOT NULL,
      provenance_locator TEXT,
      sha256 TEXT NOT NULL
    );
    CREATE TABLE token_index(
      token TEXT NOT NULL,
      passage_id TEXT NOT NULL REFERENCES passages(id),
      PRIMARY KEY(token, passage_id)
    ) WITHOUT ROWID;
    CREATE TABLE gram_index(
      gram TEXT NOT NULL,
      passage_id TEXT NOT NULL REFERENCES passages(id),
      PRIMARY KEY(gram, passage_id)
    ) WITHOUT ROWID;
    CREATE INDEX idx_passages_source ON passages(source_id);
    CREATE INDEX idx_passages_kind ON passages(kind);
    CREATE INDEX idx_token_index_token ON token_index(token);
    CREATE INDEX idx_gram_index_gram ON gram_index(gram);
    ''')


def build(args: argparse.Namespace) -> dict:
    out_db = Path(args.output)
    out_db.parent.mkdir(parents=True, exist_ok=True)
    if out_db.exists():
        out_db.unlink()

    quran_text = Path(args.quran_text)
    quran_sty = Path(args.quran_sty)
    curated_dir = Path(args.curated_dir)
    quran_version, quran_date = parse_quran_version(quran_sty)
    quran = parse_quran(quran_text)
    nahj = load_curated(curated_dir / 'nahj_selected.json')
    sahifa = load_curated(curated_dir / 'sahifa_selected.json')

    sources = [
      {
        'id': f'quran-texlive-quran-v{quran_version}', 'kind':'quran', 'title_fa':'قرآن کریم', 'title_ar':'القرآن الكريم',
        'edition':'Uthmani text from LaTeX quran package', 'scope':'complete', 'language':'ar',
        'source_url':'https://ctan.org/pkg/quran', 'license':'LPPL 1.3c+ (package text file); Quran text redistribution attribution also documented against Tanzil',
        'attribution':'Seiied-Mohammad-Javad Razavian, quran package; external canonical cross-check target: Tanzil Project',
        'version':quran_version, 'retrieved_at':quran_date, 'sha256':sha256_bytes(quran_text.read_bytes()),
        'notes':'Complete canonical structure: 114 surahs / 6236 ayahs. Original Uthmani display text is stored unchanged except removal of TeX presentation macros and verse-number markup. Basmala presentation macro is removed where it precedes verse 1; Al-Fatiha 1:1 remains in the source text.'
      },
      {
        'id':'nahj-abduh-selected-v1', 'kind':'nahjAlBalagha', 'title_fa':'نهج‌البلاغه', 'title_ar':'نهج البلاغة',
        'edition':'محمد عبده — حکمت‌های منتخب، شماره‌گذاری نسخه', 'scope':'verified_subset', 'language':'ar',
        'source_url':'https://huggingface.co/datasets/aliahabeeb/nahj-al-balagha', 'license':'MIT for referenced structured dataset; classical text is historical/public-domain material',
        'attribution':'Selected maxims manually curated and cross-checked against the Muhammad Abduh edition; external structured dataset: aliahabeeb/nahj-al-balagha',
        'version':'1.0.0-curated', 'retrieved_at':'2026-09-25', 'sha256':sha256_bytes((curated_dir/'nahj_selected.json').read_bytes()),
        'notes':'Verified selected subset only, not a claim of complete Nahj al-Balagha coverage. Wisdom numbering is edition-specific and explicitly labeled.'
      },
      {
        'id':'sahifa-wikisource-r591900-selected-v1', 'kind':'sahifaSajjadiya', 'title_fa':'صحیفه سجادیه', 'title_ar':'الصحيفة السجادية',
        'edition':'Arabic Wikisource revision oldid=591900 — selected excerpts', 'scope':'verified_subset', 'language':'ar',
        'source_url':'https://ar.wikisource.org/w/index.php?title=الصحيفة_السجادية&oldid=591900', 'license':'CC BY-SA 4.0 for Wikisource transcription',
        'attribution':'Wikisource contributors, الصحيفة السجادية, revision oldid=591900',
        'version':'oldid-591900-selected-v1', 'retrieved_at':'2026-09-25', 'sha256':sha256_bytes((curated_dir/'sahifa_selected.json').read_bytes()),
        'notes':'Verified selected excerpts only, not a claim of complete Sahifa coverage. Excerpts retain Arabic source text; reference identifies dua and selected fragment.'
      },
    ]

    source_id_by_kind = {s['kind']:s['id'] for s in sources}
    all_passages = quran + nahj + sahifa
    ids = [p['id'] for p in all_passages]
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate passage IDs detected')

    conn = sqlite3.connect(out_db)
    schema(conn)
    conn.executemany('''INSERT INTO sources(id,kind,title_fa,title_ar,edition,scope,language,source_url,license,attribution,version,retrieved_at,sha256,notes)
      VALUES(:id,:kind,:title_fa,:title_ar,:edition,:scope,:language,:source_url,:license,:attribution,:version,:retrieved_at,:sha256,:notes)''', sources)

    token_rows = []
    gram_rows = []
    kind_counts: dict[str,int] = {}
    for display_order, p in enumerate(all_passages, start=1):
        n = normalize(p['text'])
        if not n:
            raise ValueError(f'Empty normalized passage: {p["id"]}')
        ptokens = tokens(p['text'])
        kind_counts[p['kind']] = kind_counts.get(p['kind'],0) + 1
        conn.execute('''INSERT INTO passages(id,source_id,kind,reference,section_title,section_number,passage_number,original_text,normalized_text,token_count,display_order,provenance_locator,sha256)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',(
            p['id'],source_id_by_kind[p['kind']],p['kind'],p['reference'],p.get('section_title'),p.get('section_number'),p.get('passage_number'),p['text'],n,len(ptokens),display_order,p.get('provenance_locator'),sha256_text(p['text'])
        ))
        token_rows.extend((t,p['id']) for t in unique_preserving_order(ptokens))
        # Character 3-grams make typo/OCR candidate retrieval possible without
        # scoring every passage. Store unique grams per passage to bound size.
        gram_rows.extend((g,p['id']) for g in unique_preserving_order(compact_ngrams(p['text'],3)))
        if len(token_rows) > 25000:
            conn.executemany('INSERT OR IGNORE INTO token_index(token,passage_id) VALUES(?,?)', token_rows)
            token_rows.clear()
        if len(gram_rows) > 50000:
            conn.executemany('INSERT OR IGNORE INTO gram_index(gram,passage_id) VALUES(?,?)', gram_rows)
            gram_rows.clear()
    if token_rows:
        conn.executemany('INSERT OR IGNORE INTO token_index(token,passage_id) VALUES(?,?)', token_rows)
    if gram_rows:
        conn.executemany('INSERT OR IGNORE INTO gram_index(gram,passage_id) VALUES(?,?)', gram_rows)

    corpus_version='2026.09.25-corpus1'
    meta = {
      'corpus_version':corpus_version,
      'schema_version':'1',
      'passage_count':str(len(all_passages)),
      'quran_count':str(kind_counts.get('quran',0)),
      'nahj_count':str(kind_counts.get('nahjAlBalagha',0)),
      'sahifa_count':str(kind_counts.get('sahifaSajjadiya',0)),
      'quran_scope':'complete',
      'nahj_scope':'verified_subset',
      'sahifa_scope':'verified_subset',
      'normalizer_version':'1',
    }
    conn.executemany('INSERT INTO meta(key,value) VALUES(?,?)', meta.items())
    conn.commit()
    conn.execute('VACUUM')
    conn.close()

    db_sha=sha256_bytes(out_db.read_bytes())
    manifest={
      'corpus_version':corpus_version,
      'schema_version':1,
      'database_file':out_db.name,
      'database_sha256':db_sha,
      'counts':{'total_passages':len(all_passages),'quran':len(quran),'nahj_selected':len(nahj),'sahifa_selected':len(sahifa)},
      'coverage':{'quran':'complete: 114 surahs / 6236 ayahs','nahjAlBalagha':'verified selected subset','sahifaSajjadiya':'verified selected subset'},
      'sources':sources,
      'normalization_note':'Original source text is preserved in original_text; normalized_text is a derived search-only field. Search normalization never overwrites the source text.',
      'validation':{
        'quran_expected_ayahs':6236,'quran_actual_ayahs':len(quran),'quran_expected_surahs':114,
        'unique_ids':len(ids)==len(set(ids)),'nonempty_normalized':True
      }
    }
    manifest_path=out_db.with_name('corpus_manifest.json')
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
    return manifest


def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument('--quran-text',default=str(DEFAULT_QURAN_TEXT))
    parser.add_argument('--quran-sty',default=str(DEFAULT_QURAN_STY))
    parser.add_argument('--curated-dir',default=str(Path(__file__).resolve().parents[1]/'data'/'curated'))
    parser.add_argument('--output',default=str(Path(__file__).resolve().parents[1]/'assets'/'data'/'amin_corpus.sqlite3'))
    args=parser.parse_args()
    manifest=build(args)
    print(json.dumps(manifest['counts'],ensure_ascii=False))
    print('sha256',manifest['database_sha256'])

if __name__=='__main__':
    main()
