#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import sqlite3
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def require(condition: bool, name: str, detail: str, checks: list[dict]) -> None:
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})
    if not condition:
        raise AssertionError(f'{name}: {detail}')


def main() -> None:
    checks: list[dict] = []

    pubspec = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
    require('version: 0.5.0+5' in pubspec, 'version', 'pubspec must be 0.5.0+5', checks)

    config = (ROOT / 'lib/core/config/competition_config.dart').read_text(encoding='utf-8')
    require("packageName = 'ir.amin.thaqalayn'" in config, 'package_id', 'competition package id frozen', checks)
    require('AMIN_AUTHOR_NAME' in config, 'author_build_define', 'author injected via dart-define', checks)

    history = (ROOT / 'lib/features/history/data/sqflite_history_repository.dart').read_text(encoding='utf-8')
    require('CREATE TABLE verification_history' in history, 'history_schema', 'writable SQLite history table exists', checks)
    require("'result_json'" in history, 'history_snapshot', 'complete result snapshot stored', checks)
    require('PRAGMA quick_check' in history, 'history_integrity', 'history quick_check enabled', checks)

    analysis = (ROOT / 'lib/features/verification/presentation/analysis_page.dart').read_text(encoding='utf-8')
    require('historyRepository.add' in analysis, 'history_pipeline', 'verification result saved from AnalysisPage', checks)

    image = (ROOT / 'lib/features/image_check/presentation/image_check_page.dart').read_text(encoding='utf-8')
    require('HistoryInputType.image' in image, 'history_input_type', 'OCR review flow marks image-origin history', checks)

    more_pages = [
        ROOT / 'lib/features/more/presentation/about_page.dart',
        ROOT / 'lib/features/more/presentation/privacy_page.dart',
        ROOT / 'lib/features/more/presentation/guide_page.dart',
    ]
    for path in more_pages:
        require(path.exists() and path.stat().st_size > 500, f'page_{path.stem}', f'{path.name} exists', checks)

    docs = [
        ROOT / 'docs/INSTALLATION_GUIDE_FA.md',
        ROOT / 'docs/JUDGING_60_SECOND_SCRIPT_FA.md',
        ROOT / 'docs/COMPETITION_RELEASE_CHECKLIST_FA.md',
    ]
    for path in docs:
        require(path.exists() and path.stat().st_size > 800, f'doc_{path.stem}', f'{path.name} exists', checks)

    build_script = ROOT / 'tool/build_competition_android.sh'
    build_text = build_script.read_text(encoding='utf-8')
    require('flutter analyze' in build_text and 'flutter test' in build_text, 'build_quality_gate', 'analyze and tests required before APK build', checks)
    require('AMIN_AUTHOR_NAME:?' in build_text, 'build_author_guard', 'release refuses missing author name', checks)
    require('flutter build apk --release' in build_text, 'release_apk', 'release APK command configured', checks)

    brand = ROOT / 'assets/branding/app_icon_1024.png'
    with Image.open(brand) as im:
        require(im.size == (1024, 1024), 'master_icon', f'master icon size={im.size}', checks)
    splash = ROOT / 'assets/branding/splash_logo_512.png'
    with Image.open(splash) as im:
        require(im.size == (512, 512), 'splash_logo', f'splash logo size={im.size}', checks)

    res = ROOT / 'build_support/android_branding/res'
    required_res = [
        res / 'mipmap-mdpi/ic_launcher.png',
        res / 'mipmap-xxxhdpi/ic_launcher.png',
        res / 'mipmap-anydpi-v26/ic_launcher.xml',
        res / 'values-v31/styles.xml',
        res / 'drawable/launch_background.xml',
    ]
    require(all(p.exists() for p in required_res), 'android_branding_bundle', 'pre-generated Android icon/splash bundle complete', checks)

    db = ROOT / 'assets/data/amin_corpus.sqlite3'
    conn = sqlite3.connect(db)
    try:
        quick = conn.execute('PRAGMA quick_check').fetchone()[0]
        total = conn.execute('SELECT COUNT(*) FROM passages').fetchone()[0]
        quran = conn.execute("SELECT COUNT(*) FROM passages WHERE kind='quran'").fetchone()[0]
    finally:
        conn.close()
    require(quick == 'ok', 'corpus_quick_check', f'PRAGMA quick_check={quick}', checks)
    require(total == 6317, 'corpus_count', f'total passages={total}', checks)
    require(quran == 6236, 'quran_count', f'Quran passages={quran}', checks)

    test = ROOT / 'test/history_serialization_test.dart'
    require(test.exists(), 'history_serialization_test', 'history snapshot round-trip test added', checks)

    report = {
        'phase': 5,
        'status': 'PASS',
        'package_id': 'ir.amin.thaqalayn',
        'version': '0.5.0+5',
        'checks_passed': sum(1 for c in checks if c['passed']),
        'checks_total': len(checks),
        'checks': checks,
        'artifacts': {
            'corpus_sha256': sha256(db),
            'app_icon_sha256': sha256(brand),
            'build_script_sha256': sha256(build_script),
        },
        'build_limitation': 'Flutter SDK is not installed in this execution environment; release APK compilation remains a mandatory external quality gate.',
    }
    out = ROOT / 'benchmark/phase5_validation.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
