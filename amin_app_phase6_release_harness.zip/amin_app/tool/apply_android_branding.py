#!/usr/bin/env python3
from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path

PACKAGE_NAME = 'ir.amin.thaqalayn'
APP_LABEL = 'امین'


def patch_build_file(android: Path) -> None:
    candidates = [
        android / 'app' / 'build.gradle.kts',
        android / 'app' / 'build.gradle',
    ]
    for path in candidates:
        if not path.exists():
            continue
        text = path.read_text(encoding='utf-8')
        text = re.sub(r'namespace\s*=\s*["\'][^"\']+["\']', f'namespace = "{PACKAGE_NAME}"', text)
        text = re.sub(r'applicationId\s*=\s*["\'][^"\']+["\']', f'applicationId = "{PACKAGE_NAME}"', text)
        text = re.sub(r'applicationId\s+["\'][^"\']+["\']', f'applicationId "{PACKAGE_NAME}"', text)
        path.write_text(text, encoding='utf-8')
        return
    raise FileNotFoundError('android/app/build.gradle(.kts) not found')


def patch_activity(android: Path) -> None:
    roots = [
        android / 'app' / 'src' / 'main' / 'kotlin',
        android / 'app' / 'src' / 'main' / 'java',
    ]
    for root in roots:
        if root.exists():
            for path in root.rglob('MainActivity.*'):
                path.unlink()
    target = android / 'app' / 'src' / 'main' / 'kotlin' / 'ir' / 'amin' / 'thaqalayn' / 'MainActivity.kt'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        'package ir.amin.thaqalayn\n\n'
        'import io.flutter.embedding.android.FlutterActivity\n\n'
        'class MainActivity : FlutterActivity()\n',
        encoding='utf-8',
    )


def patch_manifest(android: Path) -> None:
    manifest = android / 'app' / 'src' / 'main' / 'AndroidManifest.xml'
    text = manifest.read_text(encoding='utf-8')
    text = re.sub(r'android:label="[^"]*"', f'android:label="{APP_LABEL}"', text, count=1)
    if 'android:roundIcon=' not in text:
        text = text.replace(
            'android:icon="@mipmap/ic_launcher"',
            'android:icon="@mipmap/ic_launcher"\n        android:roundIcon="@mipmap/ic_launcher_round"',
        )
    if 'android.permission.CAMERA' not in text:
        text = text.replace(
            '<manifest xmlns:android="http://schemas.android.com/apk/res/android">',
            '<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n    <uses-permission android:name="android.permission.CAMERA" />',
        )
    manifest.write_text(text, encoding='utf-8')


def copy_branding_resources(project: Path, android: Path) -> None:
    source = project / 'build_support' / 'android_branding' / 'res'
    target = android / 'app' / 'src' / 'main' / 'res'
    if not source.exists():
        raise FileNotFoundError(f'Branding resource bundle not found: {source}')
    target.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        destination = target / item.name
        if item.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
            for child in item.iterdir():
                if child.is_file():
                    shutil.copy2(child, destination / child.name)
        else:
            shutil.copy2(item, destination)


def main() -> int:
    project = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
    android = project / 'android'
    if not android.exists():
        print('ERROR: android/ scaffold is missing. Run the competition build script first.', file=sys.stderr)
        return 2
    patch_build_file(android)
    patch_activity(android)
    patch_manifest(android)
    copy_branding_resources(project, android)
    print(f'Android branding applied: {PACKAGE_NAME} / {APP_LABEL}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
