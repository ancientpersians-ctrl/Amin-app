from __future__ import annotations
import hashlib, json, sqlite3
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    db = root / 'assets/data/amin_corpus.sqlite3'
    manifest_path = root / 'assets/data/corpus_manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf8'))

    con = sqlite3.connect(db)
    quick = con.execute('PRAGMA quick_check').fetchone()[0]
    total = con.execute('SELECT COUNT(*) FROM passages').fetchone()[0]
    counts = dict(con.execute('SELECT kind, COUNT(*) FROM passages GROUP BY kind').fetchall())
    duplicate_ids = con.execute(
        'SELECT COUNT(*) FROM (SELECT id FROM passages GROUP BY id HAVING COUNT(*) > 1)'
    ).fetchone()[0]
    empty_norm = con.execute(
        "SELECT COUNT(*) FROM passages WHERE TRIM(normalized_text) = ''"
    ).fetchone()[0]
    quran_surahs = con.execute(
        "SELECT COUNT(DISTINCT section_number) FROM passages WHERE kind='quran'"
    ).fetchone()[0]
    token_rows = con.execute('SELECT COUNT(*) FROM token_index').fetchone()[0]
    gram_rows = con.execute('SELECT COUNT(*) FROM gram_index').fetchone()[0]
    con.close()

    checks = {
        'sqlite_quick_check': quick == 'ok',
        'database_sha256_matches_manifest': sha256(db) == manifest['database_sha256'],
        'total_passages_matches_manifest': total == manifest['counts']['total_passages'],
        'quran_6236': counts.get('quran') == 6236,
        'quran_114_surahs': quran_surahs == 114,
        'unique_passage_ids': duplicate_ids == 0,
        'nonempty_normalized_text': empty_norm == 0,
    }
    report = {
        'release': manifest['corpus_version'],
        'checks': checks,
        'passed': all(checks.values()),
        'counts': counts,
        'total_passages': total,
        'quran_surahs': quran_surahs,
        'token_index_rows': token_rows,
        'gram_index_rows': gram_rows,
        'database_sha256': sha256(db),
        'benchmark_sha256': {
            'benchmark_cases.jsonl': sha256(root/'benchmark/benchmark_cases.jsonl'),
            'challenge_set.jsonl': sha256(root/'benchmark/challenge_set.jsonl'),
        },
    }
    out = root / 'benchmark/release_validation.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not report['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
