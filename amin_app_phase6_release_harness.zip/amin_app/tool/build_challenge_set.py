from __future__ import annotations
import json
from pathlib import Path

EXACT=[
('c-ex-01','ان الله مع الصابرين',['quran-2-153','quran-8-46'],'quran'),
('c-ex-02','الا بذكر الله تطمئن القلوب',['quran-13-28'],'quran'),
('c-ex-03','لا يكلف الله نفسا الا وسعها',['quran-2-286'],'quran'),
('c-ex-04','فان مع العسر يسرا',['quran-94-5'],'quran'),
('c-ex-05','ان مع العسر يسرا',['quran-94-6'],'quran'),
('c-ex-06','ان اكرمكم عند الله اتقاكم',['quran-49-13'],'quran'),
('c-ex-07','لا تقنطوا من رحمة الله',['quran-39-53'],'quran'),
('c-ex-08','وقل رب زدني علما',['quran-20-114'],'quran'),
('c-ex-09','ان الله لا يغير ما بقوم حتى يغيروا ما بانفسهم',['quran-13-11'],'quran'),
('c-ex-10','واعتصموا بحبل الله جميعا ولا تفرقوا',['quran-3-103'],'quran'),
('c-ex-11','ومن يتوكل على الله فهو حسبه',['quran-65-3'],'quran'),
('c-ex-12','لا اكراه في الدين',['quran-2-256'],'quran'),
('c-ex-13','الناس اعداء ما جهلوا',['nahj-abduh-hikmah-172'],'nahjAlBalagha'),
('c-ex-14','لا طاعة لمخلوق في معصية الخالق',['nahj-abduh-hikmah-165'],'nahjAlBalagha'),
('c-ex-15','الة الرياسة سعة الصدر',['nahj-abduh-hikmah-176'],'nahjAlBalagha'),
('c-ex-16','من استبد برايه هلك ومن شاور الرجال شاركها في عقولها',['nahj-abduh-hikmah-161'],'nahjAlBalagha'),
('c-ex-17','اللهم صل على محمد واله وبلغ بايماني اكمل الايمان',['sahifa-wikisource-dua-20-frag-1'],'sahifaSajjadiya'),
('c-ex-18','يا فارج الهم وكاشف الغم',['sahifa-wikisource-dua-54-frag-1'],'sahifaSajjadiya'),
('c-ex-19','فاليك افر ومنك اخاف وبك استغيث',['sahifa-wikisource-dua-52-frag-3'],'sahifaSajjadiya'),
]
ALTERED=[
('c-alt-01','ان الله مع الصابرين دائما',['quran-2-153','quran-8-46'],'quran'),
('c-alt-02','الا بذكر الرحمن تطمئن القلوب',['quran-13-28'],'quran'),
('c-alt-03','لا يكلف الله نفسا فوق وسعها',['quran-2-286'],'quran'),
('c-alt-04','فان بعد العسر يسرا',['quran-94-5'],'quran'),
('c-alt-05','ان اكرمكم عند الله اعلمكم',['quran-49-13'],'quran'),
('c-alt-06','لا تياسوا من رحمة الله',['quran-39-53'],'quran'),
('c-alt-07','وقل رب زدني معرفة',['quran-20-114'],'quran'),
('c-alt-08','ان الله لا يغير حال قوم حتى يغيروا ما بانفسهم',['quran-13-11'],'quran'),
('c-alt-09','واعتصموا بحبل الله ولا تختلفوا',['quran-3-103'],'quran'),
('c-alt-10','ومن يتوكل على الله فهو كافيه',['quran-65-3'],'quran'),
('c-alt-11','لا اجبار في الدين',['quran-2-256'],'quran'),
('c-alt-12','الناس اعداء ما لا يعرفون',['nahj-abduh-hikmah-172'],'nahjAlBalagha'),
('c-alt-13','لا طاعة لبشر في معصية الخالق',['nahj-abduh-hikmah-165'],'nahjAlBalagha'),
('c-alt-14','الة القيادة سعة الصدر',['nahj-abduh-hikmah-176'],'nahjAlBalagha'),
('c-alt-15','من استبد برايه خسر ومن شاور الرجال شاركها في عقولها',['nahj-abduh-hikmah-161'],'nahjAlBalagha'),
('c-alt-16','اللهم صل على محمد واله وبلغ بايماني تمام الايمان',['sahifa-wikisource-dua-20-frag-1'],'sahifaSajjadiya'),
('c-alt-17','يا كاشف الهم وفارج الغم',['sahifa-wikisource-dua-54-frag-1'],'sahifaSajjadiya'),
('c-alt-18','فاليك افر ومنك اخشى وبك استعين',['sahifa-wikisource-dua-52-frag-3'],'sahifaSajjadiya'),
]
UNRELATED=[
('c-neg-01','العلم نور في القلب والجهل ظلمة في الطريق'),
('c-neg-02','من احب الخير للناس زاد الخير في ايامه'),
('c-neg-03','الصبر مفتاح كل باب مغلق والامل طريق النجاح'),
('c-neg-04','من صدق في وعده احبه الناس واطمانوا اليه'),
('c-neg-05','القلب الهادئ يرى الامور اوضح من القلب المضطرب'),
('c-neg-06','من طلب المعرفة بجد وجد في كل يوم فائدة جديدة'),
('c-neg-07','الانسان الحكيم يراجع قراره قبل ان يلوم غيره'),
('c-neg-08','خير العمل ما نفع المجتمع وحفظ كرامة الانسان'),
('c-neg-09','الرحمة بين الناس تبني الثقة وتقلل الخصومة'),
('c-neg-10','من نظم وقته استطاع ان ينجز اعماله بهدوء'),
('c-neg-11','این عبارت مذهبی‌نما عمدا برای آزمون رد منبع ساخته شده است'),
('c-neg-12','هر کس دانایی را دوست بدارد در تصمیم‌هایش شتاب نمی‌کند'),
('c-neg-13','آرامش دل با تمرین صبر و گفت‌وگوی درست بیشتر می‌شود'),
('c-neg-14','کمک به دیگران می‌تواند اعتماد و همکاری را در جامعه افزایش دهد'),
('c-neg-15','انسان پیش از نقل یک جمله باید منبع آن را بررسی کند'),
('c-neg-16','این متن به صورت آزمایشی نوشته شده و نقل قول از کتاب خاصی نیست'),
('c-neg-17','درستی یک ادعا فقط با تکرار زیاد آن در شبکه‌های اجتماعی ثابت نمی‌شود'),
('c-neg-18','پژوهش دقیق میان متن اصلی و برداشت شخصی تفاوت می‌گذارد'),
]

def main():
 root=Path(__file__).resolve().parents[1]
 out=[]
 for id,q,g,k in EXACT:
  out.append({'id':id,'category':'correct_manual','label':'match','query':q,'acceptable_passage_ids':g,'source_kind':k,'note':'Manually curated common/plain-script quotation; not used for threshold calibration.'})
 for id,q,g,k in ALTERED:
  out.append({'id':id,'category':'altered_manual','label':'match','query':q,'acceptable_passage_ids':g,'source_kind':k,'note':'Manually authored plausible one-phrase alteration; expected to retrieve the underlying indexed source.'})
 for id,q in UNRELATED:
  out.append({'id':id,'category':'unrelated_manual','label':'no_match','query':q,'acceptable_passage_ids':[],'source_kind':'none','note':'Manually authored non-source/hard-negative phrase; no claim is made about all literature outside the indexed corpus.'})
 (root/'benchmark'/'challenge_set.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf8')
 print(len(out))
if __name__=='__main__': main()
