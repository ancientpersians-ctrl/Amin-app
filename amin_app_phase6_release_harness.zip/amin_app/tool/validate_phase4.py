from __future__ import annotations
import json, sqlite3
from pathlib import Path
from text_normalizer import normalize, tokens

ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/'assets/data/amin_corpus.sqlite3'

def main():
    checks={}
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    q=normalize('ان الله مع الصابرین'); ts=tokens('ان الله مع الصابرین')
    ph=','.join('?'*len(ts))
    sql=f'''SELECT p.id, COUNT(DISTINCT t.token) hits FROM passages p
            LEFT JOIN token_index t ON t.passage_id=p.id AND t.token IN ({ph})
            WHERE instr(p.normalized_text, ?) > 0 OR t.token IS NOT NULL
            GROUP BY p.id ORDER BY (instr(p.normalized_text, ?) > 0) DESC, hits DESC, p.display_order LIMIT 5'''
    rows=con.execute(sql,(*ts,q,q)).fetchall()
    checks['full_corpus_search_returns_quran_2_153_top5']=any(r['id']=='quran-2-153' for r in rows)
    row=con.execute('''SELECT p.id,s.title_fa,s.version,s.scope,p.provenance_locator
                       FROM passages p JOIN sources s ON s.id=p.source_id WHERE p.id=?''',('quran-2-153',)).fetchone()
    checks['source_detail_metadata_available']=bool(row and row['title_fa'] and row['version'] and row['provenance_locator'])
    con.close()
    quality=ROOT/'assets/data/quality'
    for name in ['release_validation.json','corpus_validation.json','benchmark_results.json','challenge_results.json','ocr_benchmark_results.json']:
        try:
            json.loads((quality/name).read_text(encoding='utf8')); checks[f'asset_json_{name}']=True
        except Exception:
            checks[f'asset_json_{name}']=False
    ocr=json.loads((quality/'ocr_benchmark_results.json').read_text(encoding='utf8'))
    checks['ocr_benchmark_executed']=ocr.get('executed') is True
    checks['ocr_adaptive_profile_selected']=ocr.get('selected_profile',{}).get('name')=='adaptive_multipass'
    result={'phase':'4','passed':all(checks.values()),'checks':checks}
    (ROOT/'benchmark/phase4_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
