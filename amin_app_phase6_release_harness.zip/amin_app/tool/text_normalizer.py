from __future__ import annotations

import re

ARABIC_DIACRITICS = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]")
TATWEEL = re.compile(r"\u0640")
PUNCTUATION = re.compile(r'''[\.,،؛;:!؟?\(\)\[\]\{\}"'«»…ـ\-_/\\|﴿﴾]+''')
WHITESPACE = re.compile(r"\s+")
ARABIC_STANDALONE_CLITIC = re.compile(r"(?<!\S)([وفبكل])\s+(?=[\u0621-\u06FF])")

REPLACEMENTS = {
    "أ": "ا",
    "إ": "ا",
    "آ": "ا",
    "ٱ": "ا",
    "ى": "ی",
    "ي": "ی",
    "ئ": "ی",
    "ك": "ک",
    "ؤ": "و",
    "ۀ": "ه",
    "ة": "ه",
}

PERSIAN_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩"


def normalize(text: str) -> str:
    value = text.strip().lower()
    value = ARABIC_DIACRITICS.sub("", value)
    value = TATWEEL.sub("", value)
    for src, dst in REPLACEMENTS.items():
        value = value.replace(src, dst)
    for i in range(10):
        value = value.replace(PERSIAN_DIGITS[i], str(i)).replace(ARABIC_DIGITS[i], str(i))
    value = PUNCTUATION.sub(" ", value)
    value = WHITESPACE.sub(" ", value).strip()
    # Classical/transcribed sources sometimes separate Arabic clitics such as
    # 'وَ مِنْكَ', while users usually type 'ومنك'. Merge only standalone
    # one-letter Arabic clitics before Arabic letters; source display text is
    # never modified, only this derived search key.
    previous = None
    while previous != value:
        previous = value
        value = ARABIC_STANDALONE_CLITIC.sub(r"\1", value)
    return value


def tokens(text: str) -> list[str]:
    n = normalize(text)
    return [t for t in n.split(" ") if t]


def compact_ngrams(text: str, n: int = 3) -> list[str]:
    compact = normalize(text).replace(" ", "")
    if not compact:
        return []
    if len(compact) < n:
        return [compact]
    return [compact[i : i + n] for i in range(len(compact) - n + 1)]
