from __future__ import annotations

import csv
import hashlib
import json
import random
import sqlite3
from collections import defaultdict
from pathlib import Path

from reference_engine import SQLiteReferenceEngine, orthographic_skeleton
from text_normalizer import normalize, tokens

SEED = 14050329
CATEGORIES = ('exact','orthographic','one_token_deleted','one_token_replaced','short_snippet','unrelated')
DEV_PER_CATEGORY = 40
TEST_PER_CATEGORY = 80
SOURCE_WEIGHTS = [('quran', .70), ('nahjAlBalagha', .15), ('sahifaSajjadiya', .15)]
REPLACEMENTS = ['امروز','دیگر','بسیار','طریق','جدید','بعید','قریب','کثیر','قلیل','مختلف']

GENERAL_NEGATIVES = [
'امروز برای بررسی پروژه به دانشگاه رفتم و چند یادداشت تازه نوشتم',
'این جمله برای سنجش سامانه نوشته شده و به هیچ کتاب دینی نسبت داده نمی‌شود',
'گوشی من پس از به‌روزرسانی نرم افزار سریع‌تر از قبل کار می‌کند',
'دانشجو گزارش پژوهش را عصر امروز برای استاد خود ارسال کرد',
'هوا در آغاز صبح خنک بود و بعد از ظهر کمی گرم‌تر شد',
'برای سفر فردا باید بلیت و مدارک لازم را از قبل آماده کنیم',
'کتابخانه دانشگاه تا ساعت هشت شب برای دانشجویان باز است',
'نتیجه آزمایش پس از سه بار تکرار در جدول نهایی ثبت شد',
'این متن ساختگی فقط برای ارزیابی نرخ خطای مثبت کاذب سامانه است',
'کاربر می‌تواند اندازه نوشته را از بخش تنظیمات برنامه تغییر دهد',
'نسخه پشتیبان فایل‌ها روی حافظه جداگانه ذخیره شد',
'جلسه گروه پژوهشی هفته آینده در ساختمان مرکزی برگزار می‌شود',
'سامانه باید هنگام قطع اینترنت نیز بخش‌های اصلی را اجرا کند',
'طراح رابط کاربری فاصله میان دکمه‌ها را برای لمس آسان بیشتر کرد',
'پژوهشگر داده‌های آزمون را از داده‌های تنظیم آستانه جدا نگه داشت',
'گزارش نهایی شامل تعداد نمونه‌ها روش اندازه‌گیری و محدودیت‌های آزمون است',
'در این مثال هیچ ادعایی درباره انتساب متن به منبع تاریخی مطرح نشده است',
'برنامه پس از انتخاب تصویر متن را استخراج و برای بازبینی نمایش می‌دهد',
'کاربر پیش از ادامه می‌تواند خطای تشخیص نوشته را به صورت دستی اصلاح کند',
'پایگاه داده روی خود دستگاه قرار دارد و برای جستجو به شبکه نیاز ندارد',
'هذا النص التجريبي كتب لاختبار البرنامج ولا ينسب إلى كتاب تراثي',
'زار الطالب المكتبة صباح اليوم ثم عاد إلى منزله بعد انتهاء الدرس',
'يحتاج التطبيق إلى اختبار السرعة والدقة قبل نشر النسخة النهائية',
'كتب الباحث ملاحظاته في ملف مستقل ثم راجع النتائج مرة أخرى',
'تعمل هذه الجملة كمثال عام لقياس قدرة النظام على رفض النصوص غير المطابقة',
'وصل القطار إلى المحطة في الموعد المحدد وانتظر المسافرون فتح الأبواب',
'يستطيع المستخدم تغيير حجم الخط من صفحة الإعدادات داخل التطبيق',
'حفظ الفريق نسخة احتياطية من البيانات قبل بدء عملية التحديث',
'يعرض التقرير عدد الحالات المختبرة ومتوسط الزمن وحدود التجربة',
'اختار المصمم واجهة بسيطة كي تكون خطوات الاستخدام واضحة للمستخدم',
'راجع الطالب قائمة المراجع ثم أكمل كتابة الفصل الأخير من بحثه',
'هذا مثال حديث لا يقصد به الاقتباس من القرآن أو من كتاب روائي',
'تم تشغيل الاختبار على مجموعة منفصلة ولم تستخدم نتائجه في بناء البيانات',
'يفضل فحص المدخلات قبل حفظها لتقليل الأخطاء غير المتوقعة في النظام',
'أرسل المشرف ملاحظاته إلى الفريق وطلب تعديل صفحة النتائج',
'يعمل البحث المحلي بسرعة أكبر عندما يستخدم فهرسا مناسبا للكلمات',
'وضعت الملفات في مجلد واضح ليسهل العثور عليها عند مراجعة المشروع',
'تحتاج النسخة النهائية إلى دليل استخدام مختصر وواضح للمحكمين',
'قارن الباحث بين طريقتين للحساب ثم سجل الفروق في تقرير منفصل',
'أغلق المستخدم التطبيق بعد حفظ النتيجة وعاد إليه في اليوم التالي',
]


def load_passages(conn: sqlite3.Connection):
    conn.row_factory=sqlite3.Row
    rows=conn.execute('SELECT id,kind,source_id,original_text,normalized_text FROM passages').fetchall()
    return [dict(r) for r in rows]


def stable_split(passages, rng):
    by=defaultdict(list)
    for p in passages:
        by[p['kind']].append(p)
    out={'dev':{},'test':{}}
    for kind, arr in by.items():
        arr=arr.copy(); rng.shuffle(arr)
        cut=max(1, int(len(arr)*.30))
        out['dev'][kind]=arr[:cut]
        out['test'][kind]=arr[cut:]
    return out


def weighted_counts(total:int):
    q=round(total*.70); n=round(total*.15); s=total-q-n
    return {'quran':q,'nahjAlBalagha':n,'sahifaSajjadiya':s}


def choose_segment(p, rng, short=False):
    toks=p['original_text'].split()
    if short:
        size=min(len(toks), rng.randint(4,7))
    else:
        size=min(len(toks), rng.randint(9,18))
        if len(toks) < 9:
            size=len(toks)
    if size <= 0:
        return p['original_text']
    start=0 if len(toks)==size else rng.randint(0,len(toks)-size)
    return ' '.join(toks[start:start+size])


def orthographic_variant(text):
    # A realistic unvocalized copy/paste shape. Persian/Arabic keyboard variants
    # are deliberately mixed; the app's normalizer should collapse them.
    value=normalize(text)
    value=value.replace('ی','ي').replace('ک','ك')
    return value


def delete_token(text,rng):
    ts=text.split()
    if len(ts)<4: return text
    idx=rng.randrange(1,len(ts)-1) if len(ts)>2 else 0
    del ts[idx]
    return ' '.join(ts)


def replace_token(text,rng):
    ts=text.split()
    if len(ts)<4: return text
    idx=rng.randrange(1,len(ts)-1)
    replacement=rng.choice(REPLACEMENTS)
    while normalize(replacement)==normalize(ts[idx]):
        replacement=rng.choice(REPLACEMENTS)
    ts[idx]=replacement
    return ' '.join(ts)


def build_first_token_index(passages):
    idx=defaultdict(list)
    for p in passages:
        ts=p['normalized_text'].split()
        for t in set(ts):
            idx[t].append(p)
    return idx

def exact_gold_ids(base_text, first_token_index, cap=5):
    n=normalize(base_text)
    ts=n.split()
    if not ts:
        return []
    ids=[]
    for p in first_token_index.get(ts[0], []):
        if n in p['normalized_text']:
            ids.append(p['id'])
            if len(ids)>cap:
                break
    return ids


def build_positive_cases(split, category, count, split_pool, first_token_index, rng, serial_start):
    cases=[]; serial=serial_start
    counts=weighted_counts(count)
    for kind, wanted in counts.items():
        pool=[p for p in split_pool[kind] if len(tokens(p['original_text'])) >= (6 if category in ('one_token_deleted','one_token_replaced') else 4)]
        if not pool: raise RuntimeError(f'No eligible pool for {kind}/{category}')
        attempts=0
        while sum(1 for c in cases if c['source_kind']==kind) < wanted:
            attempts += 1
            if attempts>5000: raise RuntimeError('too many benchmark generation attempts')
            p=rng.choice(pool)
            base=choose_segment(p,rng,short=(category=='short_snippet'))
            gold=exact_gold_ids(base,first_token_index)
            if not gold or len(gold)>3: continue
            if category=='exact': query=base
            elif category=='orthographic': query=orthographic_variant(base)
            elif category=='one_token_deleted': query=delete_token(base,rng)
            elif category=='one_token_replaced': query=replace_token(base,rng)
            elif category=='short_snippet': query=base
            else: raise ValueError(category)
            serial += 1
            cases.append({
              'id':f'{split}-{category}-{serial:04d}','split':split,'category':category,'group':'correct' if category in ('exact','orthographic','short_snippet') else 'altered',
              'label':'match','query':query,'base_quote':base,'expected_passage_id':p['id'],'acceptable_passage_ids':gold,
              'expected_source_id':p['source_id'],'source_kind':kind,
              'mutation':category,'seed':SEED,
            })
    rng.shuffle(cases)
    return cases, serial


def is_verbatim_in_corpus(query, first_token_index):
    n=normalize(query); ts=n.split()
    if not ts: return False
    return any(n in p['normalized_text'] for p in first_token_index.get(ts[0], []))


def build_negative_cases(split,count,split_pool,first_token_index,rng,serial_start):
    cases=[]; serial=serial_start
    # half curated general negatives, with deterministic suffixes when reused.
    for i in range(count//2):
        base=GENERAL_NEGATIVES[i % len(GENERAL_NEGATIVES)]
        query=base if i < len(GENERAL_NEGATIVES) else f'{base} نمونه {i+1}'
        if is_verbatim_in_corpus(query,first_token_index):
            query=f'{query} آزمایشی'
        serial+=1
        cases.append({'id':f'{split}-unrelated-{serial:04d}','split':split,'category':'unrelated','group':'unrelated','label':'no_match','query':query,'base_quote':None,'expected_passage_id':None,'acceptable_passage_ids':[],'expected_source_id':None,'source_kind':'none','mutation':'general_non_source','seed':SEED})
    # hard negatives: splice two unrelated source snippets. They contain scripture-like
    # vocabulary but are not a contiguous quote from a single indexed passage.
    all_pool=sum((list(v) for v in split_pool.values()),[])
    attempts=0
    while len(cases)<count:
        attempts+=1
        if attempts>10000: raise RuntimeError('could not produce hard negatives')
        a,b=rng.sample(all_pool,2)
        if a['id']==b['id']: continue
        at=tokens(a['original_text']); bt=tokens(b['original_text'])
        if len(at)<5 or len(bt)<5: continue
        # Use normalized token forms so punctuation does not accidentally join terms.
        q=' '.join(at[:4]+bt[-4:])
        if is_verbatim_in_corpus(q,first_token_index): continue
        serial+=1
        cases.append({'id':f'{split}-unrelated-{serial:04d}','split':split,'category':'unrelated','group':'unrelated','label':'no_match','query':q,'base_quote':None,'expected_passage_id':None,'acceptable_passage_ids':[],'expected_source_id':None,'source_kind':'mixed','mutation':'hard_splice','seed':SEED})
    rng.shuffle(cases)
    return cases,serial


def main():
    root=Path(__file__).resolve().parents[1]
    db=root/'assets'/'data'/'amin_corpus.sqlite3'
    out=root/'benchmark'; out.mkdir(exist_ok=True)
    rng=random.Random(SEED)
    conn=sqlite3.connect(db)
    passages=load_passages(conn); conn.close()
    split_pool=stable_split(passages,rng)
    first_token_index=build_first_token_index(passages)
    cases=[]; serial=0
    for split,n in [('dev',DEV_PER_CATEGORY),('test',TEST_PER_CATEGORY)]:
        for cat in CATEGORIES[:-1]:
            c,serial=build_positive_cases(split,cat,n,split_pool[split],first_token_index,rng,serial); cases+=c
        c,serial=build_negative_cases(split,n,split_pool[split],first_token_index,rng,serial); cases+=c
    # Stable final order: split -> category -> id.
    cases.sort(key=lambda c:(0 if c['split']=='dev' else 1,CATEGORIES.index(c['category']),c['id']))
    (out/'benchmark_cases.jsonl').write_text(''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in cases),encoding='utf8')
    fields=['id','split','category','group','label','query','base_quote','expected_passage_id','acceptable_passage_ids','expected_source_id','source_kind','mutation','seed']
    with (out/'benchmark_cases.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for c in cases:
            row=c.copy(); row['acceptable_passage_ids']='|'.join(row['acceptable_passage_ids']); w.writerow(row)
    manifest={
      'name':'Amin Source Verification Benchmark v1','version':'1.0.0','seed':SEED,
      'design':'Reproducible synthetic+curated retrieval benchmark. Dev is used only for threshold calibration; final metrics are reported on frozen test cases.',
      'counts':{'total':len(cases),'dev':sum(c['split']=='dev' for c in cases),'test':sum(c['split']=='test' for c in cases)},
      'categories':{cat:{'dev':sum(c['split']=='dev' and c['category']==cat for c in cases),'test':sum(c['split']=='test' and c['category']==cat for c in cases)} for cat in CATEGORIES},
      'positive_source_mix':'70% Quran, 15% Nahj selected, 15% Sahifa selected per positive category',
      'gold_policy':'A positive case stores the sampled passage plus any other indexed passages containing the same unaltered base quote (maximum 3) as acceptable passage IDs. This avoids penalizing genuinely repeated quotations.',
      'limitations':['Generated perturbations are not a human-authored theological authenticity gold standard.','The benchmark measures retrieval/matching robustness and rejection of unrelated text; it does not validate hadith isnad or theological authenticity.','Nahj and Sahifa coverage in corpus v1 are selected verified subsets.'],
    }
    (out/'benchmark_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(manifest['counts']))

if __name__=='__main__': main()
