from __future__ import annotations
import hashlib, json, sqlite3
from pathlib import Path
from build_corpus import VERSE_COUNTS
from text_normalizer import normalize


def sha(s:str): return hashlib.sha256(s.encode('utf8')).hexdigest()

def main():
 root=Path(__file__).resolve().parents[1]
 db=root/'assets'/'data'/'amin_corpus.sqlite3'
 c=sqlite3.connect(db); c.row_factory=sqlite3.Row
 checks=[]
 def check(name, ok, detail):
  checks.append({'name':name,'passed':bool(ok),'detail':detail})
  if not ok: print('FAIL',name,detail)

 qc=c.execute('PRAGMA quick_check').fetchone()[0]
 check('sqlite_quick_check',qc=='ok',qc)
 total=c.execute('select count(*) from passages').fetchone()[0]
 check('total_passages',total==6317,total)
 qcount=c.execute("select count(*) from passages where kind='quran'").fetchone()[0]
 check('quran_ayah_count',qcount==6236,qcount)
 surahs=c.execute("select section_number,count(*) n from passages where kind='quran' group by section_number order by section_number").fetchall()
 check('quran_surah_count',len(surahs)==114,len(surahs))
 check('quran_per_surah_counts',[r['n'] for r in surahs]==VERSE_COUNTS,[r['n'] for r in surahs])
 empty=c.execute("select count(*) from passages where trim(original_text)='' or trim(normalized_text)=''").fetchone()[0]
 check('no_empty_passages',empty==0,empty)
 macros=c.execute("select count(*) from passages where kind='quran' and instr(original_text,'\\\\')>0").fetchone()[0]
 check('no_tex_macros_in_quran',macros==0,macros)
 # Recompute normalized text + per-passage hashes.
 bad_norm=bad_hash=0
 for r in c.execute('select original_text,normalized_text,sha256 from passages'):
  bad_norm += normalize(r['original_text']) != r['normalized_text']
  bad_hash += sha(r['original_text']) != r['sha256']
 check('normalized_text_reproducible',bad_norm==0,bad_norm)
 check('passage_hashes_valid',bad_hash==0,bad_hash)
 # Every passage should be discoverable by at least one token and gram unless too short.
 no_token=c.execute('''select count(*) from passages p where not exists (select 1 from token_index t where t.passage_id=p.id)''').fetchone()[0]
 no_gram=c.execute('''select count(*) from passages p where not exists (select 1 from gram_index g where g.passage_id=p.id)''').fetchone()[0]
 check('token_index_coverage',no_token==0,no_token)
 check('gram_index_coverage',no_gram==0,no_gram)
 # Known structural checkpoints.
 q11=c.execute("select original_text from passages where id='quran-1-1'").fetchone()[0]
 check('fatiha_1_1_basmala','ٱللَّهِ' in q11 and 'ٱلرَّحْمَـٰنِ' in q11,q11)
 q91=c.execute("select original_text from passages where id='quran-9-1'").fetchone()[0]
 check('tawba_9_1_no_presentation_basmala',not q91.startswith('بِسْمِ'),q91[:80])
 q2153=c.execute("select normalized_text from passages where id='quran-2-153'").fetchone()[0]
 check('quran_2_153_checkpoint','ان الله مع الصبرین' in q2153,q2153)
 ncount=c.execute("select count(*) from passages where kind='nahjAlBalagha'").fetchone()[0]
 scount=c.execute("select count(*) from passages where kind='sahifaSajjadiya'").fetchone()[0]
 check('nahj_selected_count',ncount==55,ncount)
 check('sahifa_selected_count',scount==26,scount)
 duplicate=c.execute('select count(*) from (select id,count(*) n from passages group by id having n>1)').fetchone()[0]
 check('unique_passage_ids',duplicate==0,duplicate)
 c.close()
 manifest=json.load(open(root/'assets'/'data'/'corpus_manifest.json',encoding='utf8'))
 db_hash=hashlib.sha256(db.read_bytes()).hexdigest()
 check('database_hash_matches_manifest',db_hash==manifest['database_sha256'],db_hash)
 result={'corpus_version':manifest['corpus_version'],'database_sha256':db_hash,'passed':all(x['passed'] for x in checks),'checks':checks}
 (root/'assets'/'data'/'corpus_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps({'passed':result['passed'],'checks':len(checks),'db_sha256':db_hash},ensure_ascii=False))
 if not result['passed']: raise SystemExit(1)
if __name__=='__main__':main()
