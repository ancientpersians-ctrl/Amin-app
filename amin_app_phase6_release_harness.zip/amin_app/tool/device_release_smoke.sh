#!/usr/bin/env bash
set -euo pipefail

APK="${1:-dist/Amin-0.5.0-build5.apk}"
PACKAGE="ir.amin.thaqalayn"
ACTIVITY="${PACKAGE}/.MainActivity"

if ! command -v adb >/dev/null 2>&1; then
  echo 'ERROR: adb is not installed.' >&2
  exit 2
fi
if [[ ! -f "$APK" ]]; then
  echo "ERROR: APK not found: $APK" >&2
  exit 2
fi

DEVICE_COUNT="$(adb devices | awk 'NR>1 && $2=="device" {c++} END{print c+0}')"
if [[ "$DEVICE_COUNT" -ne 1 ]]; then
  echo "ERROR: exactly one authorized Android device is required; found $DEVICE_COUNT." >&2
  adb devices -l >&2
  exit 2
fi

adb install -r "$APK"
adb shell pm clear "$PACKAGE" >/dev/null

echo '=== cold start ==='
adb shell am force-stop "$PACKAGE"
adb shell am start -W -n "$ACTIVITY" | tee /tmp/amin-cold-start.txt

sleep 2

echo '=== package version ==='
adb shell dumpsys package "$PACKAGE" | grep -E 'versionName|versionCode' | head

echo '=== memory snapshot ==='
adb shell dumpsys meminfo "$PACKAGE" | sed -n '1,45p'

echo '=== APK size ==='
ls -lh "$APK"
sha256sum "$APK" 2>/dev/null || shasum -a 256 "$APK"

echo
cat <<'EOF'
Manual judge-path smoke checklist on the connected phone:
1. Open Amin and verify RTL layout and splash/icon.
2. Text check: «ان الله مع الصابرین» -> Quran, Al-Baqarah 2:153.
3. Open Source Detail; scroll previous/next passage.
4. Open Sources; search the same phrase.
5. Image check: camera/gallery -> OCR review -> verification.
6. Reopen History after force-stop; result must remain.
7. Enable airplane mode and repeat text verification.
EOF
