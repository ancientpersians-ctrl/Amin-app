from __future__ import annotations

import hashlib
import json
import math
import os
import random
import sqlite3
import statistics
import subprocess
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps, ImageStat
from rapidfuzz.distance import Levenshtein

from reference_engine import SQLiteReferenceEngine
from text_normalizer import normalize, tokens

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / 'assets' / 'data' / 'amin_corpus.sqlite3'
TESSDATA = ROOT / 'assets' / 'tessdata'
OUT = ROOT / 'benchmark'
SAMPLE_OUT = OUT / 'ocr_samples'
SEED = 20260925
THRESHOLD = 0.63

FONTS = [
    '/usr/share/fonts/opentype/fonts-hosny-amiri/Amiri-Regular.ttf',
    '/usr/share/fonts/truetype/noto/NotoNaskhArabic-Regular.ttf',
    '/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf',
]

CONDITIONS = ('clean', 'low_contrast', 'small_jpeg', 'skew_noise')
PROFILES = ('raw', 'gray_contrast_upscale', 'binary_threshold')


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def choose_passages() -> list[dict]:
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    rows = con.execute('''SELECT id, kind, reference, original_text
                          FROM passages
                          WHERE length(original_text) BETWEEN 25 AND 120
                          ORDER BY display_order''').fetchall()
    con.close()
    by_kind = {}
    for r in rows:
        by_kind.setdefault(r['kind'], []).append(dict(r))
    rng = random.Random(SEED)
    wanted = {'quran': 9, 'nahjAlBalagha': 3, 'sahifaSajjadiya': 3}
    selected = []
    for kind, n in wanted.items():
        arr = by_kind[kind]
        # Systematic sampling spreads Quran cases across the whole corpus and
        # avoids cherry-picking only short/easy items.
        if len(arr) <= n:
            picks = arr
        else:
            step = (len(arr) - 1) / (n - 1)
            picks = [arr[round(i * step)] for i in range(n)]
        rng.shuffle(picks)
        selected.extend(picks)
    selected.sort(key=lambda x: x['id'])
    return selected


def wrap_words(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.FreeTypeFont, max_width: int) -> list[str]:
    words = text.split()
    if not words:
        return ['']
    lines = []
    current = words[0]
    for word in words[1:]:
        candidate = current + ' ' + word
        box = draw.textbbox((0, 0), candidate, font=font, direction='rtl')
        if box[2] - box[0] <= max_width:
            current = candidate
        else:
            lines.append(current)
            current = word
    lines.append(current)
    return lines[:4]


def render_base(text: str, font_path: str, font_size: int = 46) -> Image.Image:
    width = 1200
    margin = 70
    font = ImageFont.truetype(font_path, font_size)
    probe = Image.new('RGB', (width, 200), 'white')
    draw = ImageDraw.Draw(probe)
    lines = wrap_words(draw, text, font, width - 2 * margin)
    line_h = int(font_size * 1.8)
    height = margin * 2 + line_h * len(lines)
    image = Image.new('RGB', (width, height), 'white')
    draw = ImageDraw.Draw(image)
    y = margin
    for line in lines:
        draw.text((width - margin, y), line, font=font, fill=(10, 10, 10), direction='rtl', anchor='ra')
        y += line_h
    return image


def degrade(image: Image.Image, condition: str, rng: random.Random) -> Image.Image:
    if condition == 'clean':
        return image
    if condition == 'low_contrast':
        im = Image.new('RGB', image.size, (238, 238, 234))
        # Make original text lighter by blending.
        im = Image.blend(im, image, 0.48)
        return im.filter(ImageFilter.GaussianBlur(radius=0.55))
    if condition == 'small_jpeg':
        w, h = image.size
        small = image.resize((int(w * 0.58), int(h * 0.58)), Image.Resampling.LANCZOS)
        # Simulate a forwarded social-media screenshot.
        with tempfile.NamedTemporaryFile(suffix='.jpg') as tmp:
            small.save(tmp.name, 'JPEG', quality=48, optimize=True)
            return Image.open(tmp.name).convert('RGB').copy()
    if condition == 'skew_noise':
        angle = rng.choice([-2.4, -1.8, 1.7, 2.3])
        im = image.rotate(angle, resample=Image.Resampling.BICUBIC, expand=True, fillcolor='white')
        arr = np.array(im).astype(np.int16)
        noise = rng.randint(5, 10)
        rs = np.random.default_rng(SEED + int(abs(angle) * 1000) + image.width)
        arr += rs.normal(0, noise, arr.shape).astype(np.int16)
        arr = np.clip(arr, 0, 255).astype(np.uint8)
        return Image.fromarray(arr).filter(ImageFilter.GaussianBlur(radius=0.35))
    raise ValueError(condition)


def preprocess(image: Image.Image, profile: str) -> Image.Image:
    if profile == 'raw':
        return image.convert('RGB')
    if profile == 'adaptive_safe':
        im = image.convert('RGB')
        # Preserve clean/camera images as-is. Only intervene when a measurable
        # input property indicates likely OCR loss.
        if im.width < 900:
            ratio = min(1.6, 1050 / im.width)
            im = im.resize((round(im.width * ratio), round(im.height * ratio)), Image.Resampling.LANCZOS)
        gray_probe = ImageOps.grayscale(im)
        contrast_std = ImageStat.Stat(gray_probe).stddev[0]
        if contrast_std < 34:
            gray_probe = ImageOps.autocontrast(gray_probe, cutoff=0.5)
            gray_probe = ImageEnhance.Contrast(gray_probe).enhance(1.12)
            im = gray_probe.convert('RGB')
        return im
    gray = ImageOps.grayscale(image)
    gray = ImageOps.autocontrast(gray, cutoff=0.8)
    # Upscale small/forwarded images to preserve Arabic dots and diacritics.
    target_w = max(gray.width, 1600)
    if target_w > gray.width:
        ratio = min(2.2, target_w / gray.width)
        gray = gray.resize((round(gray.width * ratio), round(gray.height * ratio)), Image.Resampling.LANCZOS)
    gray = ImageEnhance.Contrast(gray).enhance(1.22)
    if profile == 'gray_contrast_upscale':
        return gray.convert('RGB')
    if profile == 'binary_threshold':
        arr = np.array(gray)
        # Global Otsu threshold: deterministic and close to an on-device
        # luminance threshold profile, while automatically adapting the cutoff.
        _, bw = cv2.threshold(arr, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        return Image.fromarray(bw).convert('RGB')
    raise ValueError(profile)


def run_tesseract(path: Path) -> tuple[str, float]:
    env = os.environ.copy()
    env['TESSDATA_PREFIX'] = str(TESSDATA)
    env['OMP_THREAD_LIMIT'] = '1'
    cmd = [
        'tesseract', str(path), 'stdout', '-l', 'ara+fas', '--psm', '6', '--oem', '1',
        '-c', 'preserve_interword_spaces=1',
    ]
    t0 = time.perf_counter()
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=env, check=True)
    elapsed = (time.perf_counter() - t0) * 1000
    return proc.stdout.decode('utf-8', errors='replace').strip(), elapsed


def char_error_rate(reference: str, hypothesis: str) -> float:
    ref = normalize(reference).replace(' ', '')
    hyp = normalize(hypothesis).replace(' ', '')
    if not ref:
        return 0.0 if not hyp else 1.0
    return Levenshtein.distance(ref, hyp) / len(ref)


def word_error_rate(reference: str, hypothesis: str) -> float:
    ref = tokens(reference)
    hyp = tokens(hypothesis)
    if not ref:
        return 0.0 if not hyp else 1.0
    # Encode tokens as stable integer symbols and reuse sequence Levenshtein.
    vocab = {tok: i for i, tok in enumerate(dict.fromkeys(ref + hyp))}
    a = [vocab[x] for x in ref]
    b = [vocab[x] for x in hyp]
    return Levenshtein.distance(a, b) / len(a)


def build_images(tmp_dir: Path, passages: list[dict]) -> list[dict]:
    cases = []
    rng = random.Random(SEED)
    SAMPLE_OUT.mkdir(parents=True, exist_ok=True)
    for i, p in enumerate(passages):
        font_path = FONTS[i % len(FONTS)]
        base = render_base(p['original_text'], font_path)
        for condition in CONDITIONS:
            degraded = degrade(base, condition, rng)
            case_id = f"ocr-{i:03d}-{condition}"
            original_path = tmp_dir / f'{case_id}-source.png'
            degraded.save(original_path)
            if i < 2 and condition in ('clean', 'skew_noise'):
                degraded.save(SAMPLE_OUT / f'{case_id}.png')
            cases.append({
                'case_id': case_id,
                'passage_id': p['id'],
                'source_kind': p['kind'],
                'reference': p['reference'],
                'ground_truth': p['original_text'],
                'condition': condition,
                'font': Path(font_path).name,
                'source_image': str(original_path),
            })
    return cases


def ocr_job(case: dict, profile: str, tmp_dir: Path) -> dict:
    source = Image.open(case['source_image']).convert('RGB')
    prepared = preprocess(source, profile)
    path = tmp_dir / f"{case['case_id']}-{profile}.png"
    prepared.save(path, optimize=True)
    text, latency = run_tesseract(path)
    return {
        **{k: v for k, v in case.items() if k != 'source_image'},
        'profile': profile,
        'ocr_text': text,
        'normalized_cer': char_error_rate(case['ground_truth'], text),
        'normalized_wer': word_error_rate(case['ground_truth'], text),
        'ocr_latency_ms': latency,
    }


def aggregate(records: list[dict], profile: str) -> dict:
    arr = [r for r in records if r['profile'] == profile]
    lats = sorted(r['ocr_latency_ms'] for r in arr)
    return {
        'profile': profile,
        'cases': len(arr),
        'normalized_cer_pct': round(100 * statistics.mean(r['normalized_cer'] for r in arr), 2),
        'normalized_wer_pct': round(100 * statistics.mean(r['normalized_wer'] for r in arr), 2),
        'median_ocr_latency_ms': round(statistics.median(lats), 2),
        'p95_ocr_latency_ms': round(lats[min(len(lats)-1, round(.95*(len(lats)-1)))], 2),
    }


def add_verification(records: list[dict]) -> None:
    engine = SQLiteReferenceEngine(DB)
    try:
        for r in records:
            # Bound pathological OCR garbage. The mobile text-review screen also
            # limits user input, so this keeps the reference benchmark realistic.
            safe_ocr = ' '.join(r['ocr_text'].split()[:80])[:1200]
            ranked = engine.verify(safe_ocr, candidate_limit=8) if normalize(safe_ocr) else []
            top = ranked[0] if ranked else None
            r['verification_score'] = top.score if top else 0.0
            r['predicted_passage_id'] = top.passage.id if top else None
            r['verification_top1'] = bool(top and top.passage.id == r['passage_id'])
            r['verification_accepted_correct'] = bool(top and top.passage.id == r['passage_id'] and top.score >= THRESHOLD)
    finally:
        engine.close()


def main():
    OUT.mkdir(exist_ok=True)
    passages = choose_passages()
    with tempfile.TemporaryDirectory(prefix='amin_ocr_') as td:
        tmp_dir = Path(td)
        cases = build_images(tmp_dir, passages)
        records = []
        started = time.perf_counter()
        jobs = []
        with ThreadPoolExecutor(max_workers=min(4, os.cpu_count() or 4)) as pool:
            for case in cases:
                for profile in PROFILES:
                    jobs.append(pool.submit(ocr_job, case, profile, tmp_dir))
            for n, future in enumerate(as_completed(jobs), 1):
                records.append(future.result())
                if n % 60 == 0:
                    print('ocr', n, '/', len(jobs), flush=True)
        runtime_ocr = time.perf_counter() - started

    summaries = [aggregate(records, p) for p in PROFILES]
    # Profile selection is based only on OCR transcription quality, before any
    # source-retrieval evaluation. This avoids tuning preprocessing on the same
    # downstream metric reported below.
    selected = min(
        summaries,
        key=lambda x: (x['normalized_cer_pct'], x['normalized_wer_pct'], x['median_ocr_latency_ms']),
    )
    selected_profile = selected['profile']
    selected_records = [r for r in records if r['profile'] == selected_profile]
    verify_started = time.perf_counter()
    add_verification(selected_records)
    runtime = runtime_ocr + (time.perf_counter() - verify_started)
    for summary in summaries:
        if summary['profile'] == selected_profile:
            summary['verification_top1_pct'] = round(100 * sum(r['verification_top1'] for r in selected_records) / len(selected_records), 2)
            summary['verification_accepted_correct_pct'] = round(100 * sum(r['verification_accepted_correct'] for r in selected_records) / len(selected_records), 2)
        else:
            summary['verification_top1_pct'] = None
            summary['verification_accepted_correct_pct'] = None

    by_condition = {}
    for condition in CONDITIONS:
        arr = [r for r in selected_records if r['condition'] == condition]
        by_condition[condition] = {
            'cases': len(arr),
            'normalized_cer_pct': round(100 * statistics.mean(r['normalized_cer'] for r in arr), 2),
            'normalized_wer_pct': round(100 * statistics.mean(r['normalized_wer'] for r in arr), 2),
            'verification_top1_pct': round(100 * sum(r['verification_top1'] for r in arr) / len(arr), 2),
            'verification_accepted_correct_pct': round(100 * sum(r['verification_accepted_correct'] for r in arr) / len(arr), 2),
        }
    by_source = {}
    for kind in ('quran', 'nahjAlBalagha', 'sahifaSajjadiya'):
        arr = [r for r in selected_records if r['source_kind'] == kind]
        by_source[kind] = {
            'cases': len(arr),
            'normalized_cer_pct': round(100 * statistics.mean(r['normalized_cer'] for r in arr), 2),
            'verification_top1_pct': round(100 * sum(r['verification_top1'] for r in arr) / len(arr), 2),
            'verification_accepted_correct_pct': round(100 * sum(r['verification_accepted_correct'] for r in arr) / len(arr), 2),
        }

    report = {
        'benchmark_version': '1.0.0',
        'executed': True,
        'engine': 'Tesseract 5 CLI using the same ara+fas traineddata files bundled with Amin',
        'tesseract_version': subprocess.check_output(['tesseract', '--version'], stderr=subprocess.STDOUT).decode().splitlines()[0],
        'tessdata_sha256': {
            'ara.traineddata': sha256(TESSDATA / 'ara.traineddata'),
            'fas.traineddata': sha256(TESSDATA / 'fas.traineddata'),
        },
        'base_passages': len(passages),
        'conditions': list(CONDITIONS),
        'image_count': len(cases),
        'ocr_runs': len(records),
        'profiles_compared': summaries,
        'selected_profile': {
            'name': selected_profile,
            'selection_rule': 'minimize normalized CER; tie-break by normalized WER then median OCR latency; downstream verification is evaluated only after selection',
        },
        'overall_metrics': {k: v for k, v in selected.items() if k not in ('profile', 'cases')},
        'by_condition': by_condition,
        'by_source_kind': by_source,
        'runtime_seconds': round(runtime, 2),
        'verification_threshold': THRESHOLD,
        'limitations': [
            'This is a real OCR-engine execution benchmark, but the images are controlled rendered/stressed images rather than independent camera photographs.',
            'Rendered cases use three Arabic fonts and four image conditions; results do not guarantee accuracy on every social-media layout, handwriting, calligraphy, or extreme camera capture.',
            'Ground truth is taken from the versioned Amin corpus; the benchmark measures OCR transcription and downstream source retrieval, not hadith-chain authenticity.',
            'Latency is from the current container CPU, not Android hardware.',
        ],
    }

    records.sort(key=lambda r: (r['case_id'], r['profile']))
    (OUT / 'ocr_benchmark_results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    (OUT / 'ocr_benchmark_predictions.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in records), encoding='utf8')
    manifest = {
        'benchmark_version': report['benchmark_version'],
        'seed': SEED,
        'database_sha256': sha256(DB),
        'tessdata_sha256': report['tessdata_sha256'],
        'case_selection': '9 Quran + 3 Nahj + 3 Sahifa base passages (25-120 chars); 4 conditions each',
        'selected_profile': selected_profile,
    }
    (OUT / 'ocr_benchmark_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
