#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if ! command -v flutter >/dev/null 2>&1; then
  echo "ERROR: Flutter SDK is not available in PATH." >&2
  echo "Install a stable Flutter SDK, then rerun this script." >&2
  exit 2
fi

: "${AMIN_AUTHOR_NAME:?Set AMIN_AUTHOR_NAME to the exact competition entrant name before building.}"
AMIN_AUTHOR_AFFILIATION="${AMIN_AUTHOR_AFFILIATION:-}"
AMIN_AUTHOR_CONTACT="${AMIN_AUTHOR_CONTACT:-}"

PYTHON_BIN="$(command -v python3 || command -v python || true)"
if [[ -z "$PYTHON_BIN" ]]; then
  echo "ERROR: Python 3 is required by the build preparation script." >&2
  exit 2
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

# Generate platform files with the exact Flutter version installed on the build machine.
# This avoids pinning stale Gradle/AGP template versions in the source archive.
flutter create \
  --platforms=android \
  --org ir.amin \
  --project-name amin_app \
  "$TMP/scaffold" >/dev/null

rm -rf "$ROOT/android"
cp -R "$TMP/scaffold/android" "$ROOT/android"
"$PYTHON_BIN" "$ROOT/tool/apply_android_branding.py" "$ROOT"

flutter pub get
flutter analyze
flutter test

DART_DEFINES=(
  "--dart-define=AMIN_AUTHOR_NAME=${AMIN_AUTHOR_NAME}"
  "--dart-define=AMIN_AUTHOR_AFFILIATION=${AMIN_AUTHOR_AFFILIATION}"
  "--dart-define=AMIN_AUTHOR_CONTACT=${AMIN_AUTHOR_CONTACT}"
)

flutter build apk --release "${DART_DEFINES[@]}"

mkdir -p "$ROOT/dist"
APK="$ROOT/build/app/outputs/flutter-apk/app-release.apk"
OUT="$ROOT/dist/Amin-0.5.0-build5.apk"
cp "$APK" "$OUT"

if command -v sha256sum >/dev/null 2>&1; then
  sha256sum "$OUT" > "$OUT.sha256"
fi

cat <<EOF

Competition build completed.
Package: ir.amin.thaqalayn
APK: $OUT
Author: $AMIN_AUTHOR_NAME
EOF
