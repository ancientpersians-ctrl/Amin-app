from __future__ import annotations

import math
import sqlite3
from collections import Counter
from rapidfuzz.distance import Levenshtein as RFLevenshtein
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from text_normalizer import compact_ngrams, normalize, tokens


def orthographic_skeleton(text: str) -> str:
    """Fold common Uthmani/imla'i differences for *equivalence checks only*.

    This deliberately removes alef and standalone hamza after the ordinary
    normalizer. It is never displayed or stored as source text. Requiring a
    minimum query length prevents very short strings from becoming false exact
    matches.
    """
    return normalize(text).replace('ا', '').replace('ء', '').replace(' ', '')


def levenshtein(a: str, b: str) -> int:
    return int(RFLevenshtein.distance(a, b))


def character_similarity(a: str, b: str) -> float:
    if a == b:
        return 1.0
    if not a or not b:
        return 0.0
    # RapidFuzz uses the same max-length normalization as the Dart reference.
    return float(RFLevenshtein.normalized_similarity(a, b))

def query_coverage(query: list[str], candidate: list[str]) -> float:
    if not query or not candidate:
        return 0.0
    remaining = candidate.copy()
    hits = 0
    for tok in query:
        try:
            i = remaining.index(tok)
        except ValueError:
            continue
        hits += 1
        remaining.pop(i)
    return hits / len(query)


def token_jaccard(a: list[str], b: list[str]) -> float:
    if not a or not b:
        return 0.0
    aa, bb = set(a), set(b)
    return len(aa & bb) / len(aa | bb)


def bigram_dice(a: str, b: str) -> float:
    if a == b:
        return 1.0
    ac=a.replace(' ', '')
    bc=b.replace(' ', '')
    if len(ac)<2 or len(bc)<2:
        return 0.0
    aa=Counter(ac[i:i+2] for i in range(len(ac)-1))
    bb=Counter(bc[i:i+2] for i in range(len(bc)-1))
    inter=sum((aa & bb).values())
    return 2 * inter / (sum(aa.values()) + sum(bb.values()))

def lcs_len(a: list[str], b: list[str]) -> int:
    if len(a) > len(b):
        a, b = b, a
    prev = [0] * (len(b) + 1)
    for x in a:
        curr = [0]
        for j, y in enumerate(b, 1):
            curr.append(prev[j - 1] + 1 if x == y else max(curr[-1], prev[j]))
        prev = curr
    return prev[-1]


def token_sequence_similarity(a: list[str], b: list[str]) -> float:
    if not a or not b:
        return 0.0
    return 2 * lcs_len(a, b) / (len(a) + len(b))


@dataclass(frozen=True)
class Passage:
    id: str
    source_id: str
    kind: str
    reference: str
    text: str
    normalized_text: str


@dataclass(frozen=True)
class ScoredCandidate:
    passage: Passage
    matched_text: str
    score: float
    token_similarity: float
    character_similarity: float
    ngram_similarity: float
    sequence_similarity: float


class SQLiteReferenceEngine:
    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row

    def close(self):
        self.conn.close()

    def _sample_items(self, values: list[str], limit: int) -> list[str]:
        values = list(dict.fromkeys(v for v in values if v))
        if len(values) <= limit:
            return values
        # Deterministically cover the whole phrase instead of taking only prefix.
        step = (len(values) - 1) / (limit - 1)
        return [values[round(i * step)] for i in range(limit)]

    def candidate_ids(self, query: str, limit_each: int = 100, max_total: int = 180) -> list[str]:
        q_tokens = self._sample_items(tokens(query), 48)
        q_grams = self._sample_items(compact_ngrams(query, 3), 180)
        scores: dict[str, float] = {}
        if q_tokens:
            ph = ','.join('?' * len(q_tokens))
            sql = f'''SELECT passage_id, COUNT(*) hits FROM token_index
                      WHERE token IN ({ph}) GROUP BY passage_id
                      ORDER BY hits DESC LIMIT ?'''
            for row in self.conn.execute(sql, (*q_tokens, limit_each)):
                scores[row['passage_id']] = scores.get(row['passage_id'], 0) + 3.0 * row['hits']
        if q_grams:
            ph = ','.join('?' * len(q_grams))
            sql = f'''SELECT passage_id, COUNT(*) hits FROM gram_index
                      WHERE gram IN ({ph}) GROUP BY passage_id
                      ORDER BY hits DESC LIMIT ?'''
            for row in self.conn.execute(sql, (*q_grams, limit_each)):
                scores[row['passage_id']] = scores.get(row['passage_id'], 0) + 1.0 * row['hits']
        return [pid for pid, _ in sorted(scores.items(), key=lambda kv: (-kv[1], kv[0]))[:max_total]]

    def passages_by_ids(self, ids: list[str]) -> list[Passage]:
        if not ids:
            return []
        ph = ','.join('?' * len(ids))
        rows = self.conn.execute(f'''SELECT id,source_id,kind,reference,original_text,normalized_text
                                    FROM passages WHERE id IN ({ph})''', ids).fetchall()
        by_id = {r['id']: Passage(r['id'],r['source_id'],r['kind'],r['reference'],r['original_text'],r['normalized_text']) for r in rows}
        return [by_id[i] for i in ids if i in by_id]

    def _best_window(self, query: str, passage: Passage) -> tuple[str, str]:
        q_tokens = tokens(query)
        source_norm_tokens = passage.normalized_text.split()
        # Original split is used for display only; Quranic punctuation marks may be
        # standalone tokens, so the robust normalized window is the scoring source.
        # We reconstruct display from normalized tokens when counts diverge.
        original_tokens = passage.text.split()
        if not q_tokens or not source_norm_tokens:
            return passage.text, passage.normalized_text
        target = len(q_tokens)
        best = (-1.0, passage.text, passage.normalized_text)
        for delta in (-2,-1,0,1,2,3):
            size = max(1, min(len(source_norm_tokens), target + delta))
            for start in range(0, len(source_norm_tokens)-size+1):
                w = source_norm_tokens[start:start+size]
                wn = ' '.join(w)
                s = 0.55 * character_similarity(normalize(query), wn) + 0.45 * query_coverage(q_tokens, w)
                # Exact display-token alignment is best-effort; score never uses it.
                if len(original_tokens) == len(source_norm_tokens):
                    display=' '.join(original_tokens[start:start+size])
                else:
                    display=wn
                if s > best[0]:
                    best=(s,display,wn)
        return best[1], best[2]

    def score_passage(self, query: str, passage: Passage) -> ScoredCandidate:
        normalized_input = normalize(query)
        q_tokens = tokens(query)
        display_window, normalized_window = self._best_window(query, passage)
        w_tokens = normalized_window.split()
        contained = normalized_input in passage.normalized_text
        coverage = query_coverage(q_tokens,w_tokens)
        token = token_jaccard(q_tokens,w_tokens)
        char = character_similarity(normalized_input,normalized_window)
        ngram = bigram_dice(normalized_input,normalized_window)
        sequence = token_sequence_similarity(q_tokens,w_tokens)
        final = .30*coverage + .20*token + .25*char + .15*ngram + .10*sequence
        if contained:
            final=max(final,.98)
            if normalized_input == passage.normalized_text:
                final=1.0
        # Orthographic equivalence catches Uthmani-vs-imla'i conventions (e.g.
        # dagger-alif / standalone hamza) without rewriting the source corpus.
        sk_q = orthographic_skeleton(query)
        sk_w = orthographic_skeleton(normalized_window)
        if len(sk_q) >= 8 and sk_q == sk_w and char >= .70:
            final=max(final,.985)
        return ScoredCandidate(passage,display_window,min(1.0,max(0.0,final)),token,char,ngram,sequence)

    def verify(self, query: str, candidate_limit: int = 180) -> list[ScoredCandidate]:
        ids=self.candidate_ids(query,max_total=candidate_limit)
        passages=self.passages_by_ids(ids)
        scored=[self.score_passage(query,p) for p in passages]
        scored.sort(key=lambda x:(-x.score,x.passage.id))
        return scored


if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('db')
    ap.add_argument('query')
    args=ap.parse_args()
    e=SQLiteReferenceEngine(args.db)
    try:
        for s in e.verify(args.query)[:5]:
            print(round(s.score*100,2),s.passage.id,s.passage.reference,s.matched_text)
    finally:
        e.close()
