#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
checks={}
def ck(name, ok, detail=''):
    checks[name]={'passed':bool(ok),'detail':detail}

workflow=ROOT/'.github/workflows/android-release.yml'
smoke=ROOT/'integration_test/release_smoke_test.dart'
perf=ROOT/'integration_test/device_performance_test.dart'
device=ROOT/'tool/device_release_smoke.sh'
pubspec=(ROOT/'pubspec.yaml').read_text(encoding='utf-8')
wf=workflow.read_text(encoding='utf-8') if workflow.exists() else ''

ck('github_workflow', workflow.exists(), 'CI release workflow exists')
ck('flutter_3_47_5', "flutter-version: '3.47.5'" in wf, 'stable SDK pinned')
ck('analyze_gate', 'flutter analyze --fatal-warnings' in wf, 'compiler/static analyzer gate')
ck('unit_test_gate', 'flutter test --reporter expanded' in wf, 'unit/widget tests gate')
ck('release_apk_gate', 'flutter build apk --release' in wf, 'release APK build gate')
ck('emulator_smoke', 'android-emulator-runner@v2' in wf and smoke.exists(), 'Android emulator integration smoke')
ck('device_perf_probe', perf.exists() and 'AMIN_PERF' in perf.read_text(encoding='utf-8'), 'runtime performance probe')
ck('physical_device_script', device.exists(), 'ADB physical-device smoke script')
ck('integration_dependency', 'integration_test:' in pubspec, 'integration_test SDK declared')
ck('package_id', 'ir.amin.thaqalayn' in (ROOT/'tool/apply_android_branding.py').read_text(encoding='utf-8'), 'competition package id')
ck('flutter_available_here', shutil.which('flutter') is not None, 'current execution environment')
ck('adb_available_here', shutil.which('adb') is not None, 'current execution environment')

payload={
  'phase':6,
  'status':'READY_FOR_EXTERNAL_ANDROID_TOOLCHAIN' if all(v['passed'] for k,v in checks.items() if k not in {'flutter_available_here','adb_available_here'}) else 'FAIL',
  'checks':checks,
  'local_environment_blockers': [k for k in ('flutter_available_here','adb_available_here') if not checks[k]['passed']],
  'workflow_sha256': hashlib.sha256(workflow.read_bytes()).hexdigest() if workflow.exists() else None,
}
out=ROOT/'benchmark/phase6_release_readiness.json'
out.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(payload,ensure_ascii=False,indent=2))
