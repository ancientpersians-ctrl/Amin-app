from __future__ import annotations

import json
import statistics
import time
from collections import defaultdict
from pathlib import Path

from reference_engine import SQLiteReferenceEngine

CANDIDATE_LIMIT=8


def pct(x): return round(100*x,2)

def metrics(records, threshold):
    positives=[r for r in records if r['label']=='match']
    negatives=[r for r in records if r['label']=='no_match']
    accepted=[r for r in records if r['score']>=threshold]
    correct_accepted=[r for r in positives if r['score']>=threshold and r['top1_gold']]
    wrong_accepted=[r for r in accepted if r['label']=='no_match' or not r['top1_gold']]
    p=len(correct_accepted)/len(accepted) if accepted else 1.0
    rec=len(correct_accepted)/len(positives) if positives else 0.0
    f1=2*p*rec/(p+rec) if p+rec else 0.0
    fpr=sum(r['score']>=threshold for r in negatives)/len(negatives) if negatives else 0.0
    detection_precision=sum(r['label']=='match' and r['score']>=threshold for r in records)/len(accepted) if accepted else 1.0
    detection_recall=sum(r['label']=='match' and r['score']>=threshold for r in records)/len(positives) if positives else 0.0
    return {'threshold':threshold,'accepted':len(accepted),'strict_precision':p,'strict_recall':rec,'strict_f1':f1,'false_positive_rate':fpr,'detection_precision':detection_precision,'detection_recall':detection_recall,'wrong_accepted':len(wrong_accepted)}


def main():
    root=Path(__file__).resolve().parents[1]
    cases=[json.loads(x) for x in (root/'benchmark'/'benchmark_cases.jsonl').read_text(encoding='utf8').splitlines() if x.strip()]
    eng=SQLiteReferenceEngine(root/'assets'/'data'/'amin_corpus.sqlite3')
    records=[]
    started=time.perf_counter()
    try:
      for i,c in enumerate(cases,1):
        t0=time.perf_counter()
        ranked=eng.verify(c['query'],candidate_limit=CANDIDATE_LIMIT)
        elapsed_ms=(time.perf_counter()-t0)*1000
        top=ranked[0] if ranked else None
        top3=[x.passage.id for x in ranked[:3]]
        gold=set(c['acceptable_passage_ids'])
        records.append({
          **c,
          'score':top.score if top else 0.0,
          'predicted_passage_id':top.passage.id if top else None,
          'predicted_source_id':top.passage.source_id if top else None,
          'top1_gold': bool(top and top.passage.id in gold) if c['label']=='match' else False,
          'top3_gold': bool(gold.intersection(top3)) if c['label']=='match' else False,
          'top3_ids':top3,
          'latency_ms_python_reference':elapsed_ms,
        })
        if i%100==0: print('processed',i,'/',len(cases))
    finally:
      eng.close()
    runtime=time.perf_counter()-started

    dev=[r for r in records if r['split']=='dev']
    test=[r for r in records if r['split']=='test']
    candidates=[]
    for x in range(400,951,5):
      m=metrics(dev,x/1000)
      if m['false_positive_rate']<=.05:
        candidates.append(m)
    if not candidates:
      raise RuntimeError('No threshold met FPR constraint')
    best=max(candidates,key=lambda m:(m['strict_f1'],m['strict_precision'],-m['threshold']))
    threshold=best['threshold']
    test_metrics=metrics(test,threshold)

    positives=[r for r in test if r['label']=='match']
    category={}
    for cat in sorted(set(r['category'] for r in test)):
      arr=[r for r in test if r['category']==cat]
      pos=[r for r in arr if r['label']=='match']
      category[cat]={
        'count':len(arr),
        'accepted_rate':pct(sum(r['score']>=threshold for r in arr)/len(arr)),
        'top1_accuracy':pct(sum(r['top1_gold'] for r in pos)/len(pos)) if pos else None,
        'top3_accuracy':pct(sum(r['top3_gold'] for r in pos)/len(pos)) if pos else None,
        'median_score':round(statistics.median(r['score'] for r in arr)*100,2),
      }
    source={}
    for kind in ('quran','nahjAlBalagha','sahifaSajjadiya'):
      arr=[r for r in positives if r['source_kind']==kind]
      source[kind]={
        'count':len(arr),
        'top1_accuracy':pct(sum(r['top1_gold'] for r in arr)/len(arr)),
        'top3_accuracy':pct(sum(r['top3_gold'] for r in arr)/len(arr)),
        'accepted_correct_rate':pct(sum(r['score']>=threshold and r['top1_gold'] for r in arr)/len(arr)),
      } if arr else {'count':0}
    lats=[r['latency_ms_python_reference'] for r in test]
    lats_sorted=sorted(lats)
    p95=lats_sorted[min(len(lats_sorted)-1,round(.95*(len(lats_sorted)-1)))]
    results={
      'benchmark_version':'1.0.0','engine_reference':'Python equivalent of Dart similarity engine + SQLite candidate retrieval',
      'candidate_limit':CANDIDATE_LIMIT,
      'threshold_calibration':{'constraint':'dev false-positive rate <= 5%; maximize strict end-to-end F1','selected_threshold':round(threshold,3),'dev_metrics':{k:(pct(v) if isinstance(v,float) and k!='threshold' else v) for k,v in best.items()}},
      'test_metrics':{
        'cases':len(test),'positive_cases':len(positives),'negative_cases':sum(r['label']=='no_match' for r in test),
        'acceptance_threshold':round(threshold,3),
        'strict_precision_pct':pct(test_metrics['strict_precision']),
        'strict_recall_pct':pct(test_metrics['strict_recall']),
        'strict_f1_pct':pct(test_metrics['strict_f1']),
        'false_positive_rate_pct':pct(test_metrics['false_positive_rate']),
        'detection_precision_pct':pct(test_metrics['detection_precision']),
        'detection_recall_pct':pct(test_metrics['detection_recall']),
        'top1_passage_accuracy_pct':pct(sum(r['top1_gold'] for r in positives)/len(positives)),
        'top3_passage_accuracy_pct':pct(sum(r['top3_gold'] for r in positives)/len(positives)),
      },
      'by_category':category,'by_source_kind':source,
      'latency_python_reference':{'median_ms':round(statistics.median(lats),2),'p95_ms':round(p95,2),'note':'Python desktop/container reference only; not an Android runtime benchmark.'},
      'total_reference_runtime_seconds':round(runtime,2),
      'limitations':['Synthetic+curated perturbation benchmark, not an independent human gold corpus.','Metrics evaluate source retrieval and rejection, not hadith chain/authenticity.','Android timing must be measured separately on target hardware.'],
    }
    (root/'benchmark'/'benchmark_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
    (root/'benchmark'/'benchmark_predictions.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records),encoding='utf8')
    print(json.dumps(results,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
