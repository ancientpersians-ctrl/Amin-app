from __future__ import annotations
import json, os, subprocess, tempfile, time, statistics, hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import run_ocr_benchmark as base

ROOT=base.ROOT
OUT=base.OUT
SYSTEM_TESSDATA=Path('/usr/share/tesseract-ocr/5/tessdata')
PROFILES=('raw','binary_threshold')

def run_tesseract_arabic(path: Path):
    env=os.environ.copy(); env['TESSDATA_PREFIX']=str(SYSTEM_TESSDATA); env['OMP_THREAD_LIMIT']='1'
    cmd=['tesseract',str(path),'stdout','-l','Arabic','--psm','6','--oem','1','-c','preserve_interword_spaces=1']
    t0=time.perf_counter()
    proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,env=env,check=True)
    return proc.stdout.decode('utf8',errors='replace').strip(), (time.perf_counter()-t0)*1000

def job(case,profile,tmp):
    from PIL import Image
    source=Image.open(case['source_image']).convert('RGB')
    prepared=base.preprocess(source,profile)
    path=tmp/f"{case['case_id']}-Arabic-{profile}.png"; prepared.save(path,optimize=True)
    text,lat=run_tesseract_arabic(path)
    return {**{k:v for k,v in case.items() if k!='source_image'},'profile':profile,'ocr_text':text,
            'normalized_cer':base.char_error_rate(case['ground_truth'],text),
            'normalized_wer':base.word_error_rate(case['ground_truth'],text),'ocr_latency_ms':lat}

def main():
    ps=base.choose_passages()
    with tempfile.TemporaryDirectory(prefix='amin_ocr_script_') as td:
        tmp=Path(td); cases=base.build_images(tmp,ps); records=[]
        with ThreadPoolExecutor(max_workers=4) as pool:
            fs=[pool.submit(job,c,p,tmp) for c in cases for p in PROFILES]
            for n,f in enumerate(as_completed(fs),1):
                records.append(f.result())
                if n%40==0: print('ocr-script',n,'/',len(fs),flush=True)
    summaries=[]
    for p in PROFILES:
        arr=[r for r in records if r['profile']==p]
        summaries.append(base.aggregate(records,p))
    selected=min(summaries,key=lambda x:(x['normalized_cer_pct'],x['normalized_wer_pct'],x['median_ocr_latency_ms']))
    selected_records=[r for r in records if r['profile']==selected['profile']]
    base.add_verification(selected_records)
    selected['verification_top1_pct']=round(100*sum(r['verification_top1'] for r in selected_records)/len(selected_records),2)
    selected['verification_accepted_correct_pct']=round(100*sum(r['verification_accepted_correct'] for r in selected_records)/len(selected_records),2)
    report={'engine':'Tesseract Arabic script model','language':'Arabic','image_count':len(cases),'profiles':summaries,
            'selected':selected,'model_sha256':hashlib.sha256((SYSTEM_TESSDATA/'Arabic.traineddata').read_bytes()).hexdigest()}
    (OUT/'ocr_arabic_script_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    (OUT/'ocr_arabic_script_predictions.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in sorted(records,key=lambda x:(x['case_id'],x['profile']))),encoding='utf8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
