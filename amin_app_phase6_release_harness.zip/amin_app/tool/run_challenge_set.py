from __future__ import annotations
import json, statistics, time
from pathlib import Path
from reference_engine import SQLiteReferenceEngine
THRESHOLD=.63
CANDIDATE_LIMIT=8

def main():
 root=Path(__file__).resolve().parents[1]
 cases=[json.loads(x) for x in (root/'benchmark'/'challenge_set.jsonl').read_text(encoding='utf8').splitlines() if x.strip()]
 e=SQLiteReferenceEngine(root/'assets'/'data'/'amin_corpus.sqlite3')
 recs=[]
 try:
  for c in cases:
   t=time.perf_counter(); r=e.verify(c['query'],candidate_limit=CANDIDATE_LIMIT); ms=(time.perf_counter()-t)*1000
   top=r[0] if r else None; accepted=bool(top and top.score>=THRESHOLD)
   gold=bool(top and top.passage.id in set(c['acceptable_passage_ids'])) if c['label']=='match' else False
   correct=(accepted and gold) if c['label']=='match' else (not accepted)
   recs.append({**c,'score':round((top.score if top else 0)*100,2),'predicted_passage_id':top.passage.id if top else None,'accepted':accepted,'top1_gold':gold,'correct':correct,'latency_ms_python_reference':round(ms,2)})
 finally:e.close()
 by={}
 for cat in sorted(set(r['category'] for r in recs)):
  a=[r for r in recs if r['category']==cat]
  by[cat]={'count':len(a),'correct':sum(r['correct'] for r in a),'accuracy_pct':round(100*sum(r['correct'] for r in a)/len(a),2),'median_score':round(statistics.median(r['score'] for r in a),2)}
 result={'version':'1.0.0','threshold':THRESHOLD,'candidate_limit':CANDIDATE_LIMIT,'cases':len(recs),'correct':sum(r['correct'] for r in recs),'accuracy_pct':round(100*sum(r['correct'] for r in recs)/len(recs),2),'by_category':by,'note':'Manually curated challenge set, frozen after the threshold was selected on the synthetic dev split. It is not used for calibration.'}
 (root/'benchmark'/'challenge_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
 (root/'benchmark'/'challenge_predictions.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in recs),encoding='utf8')
 print(json.dumps(result,ensure_ascii=False,indent=2))
 print('\nFailures:')
 for r in recs:
  if not r['correct']: print(r['id'],r['score'],r['predicted_passage_id'],r['query'])
if __name__=='__main__':main()
