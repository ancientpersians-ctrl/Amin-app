from __future__ import annotations
import json, tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import run_ocr_benchmark as b

def main():
    passages=b.choose_passages()
    with tempfile.TemporaryDirectory(prefix='amin_ocr_adaptive_') as td:
        tmp=Path(td); cases=b.build_images(tmp,passages); records=[]
        with ThreadPoolExecutor(max_workers=4) as pool:
            fs=[pool.submit(b.ocr_job,c,'adaptive_safe',tmp) for c in cases]
            for f in as_completed(fs): records.append(f.result())
    summary=b.aggregate(records,'adaptive_safe')
    b.add_verification(records)
    summary['verification_top1_pct']=round(100*sum(r['verification_top1'] for r in records)/len(records),2)
    summary['verification_accepted_correct_pct']=round(100*sum(r['verification_accepted_correct'] for r in records)/len(records),2)
    out={'profile':summary,'by_condition':{}}
    for cond in b.CONDITIONS:
        arr=[r for r in records if r['condition']==cond]
        out['by_condition'][cond]={
            'normalized_cer_pct':round(100*sum(r['normalized_cer'] for r in arr)/len(arr),2),
            'normalized_wer_pct':round(100*sum(r['normalized_wer'] for r in arr)/len(arr),2),
            'verification_top1_pct':round(100*sum(r['verification_top1'] for r in arr)/len(arr),2),
            'verification_accepted_correct_pct':round(100*sum(r['verification_accepted_correct'] for r in arr)/len(arr),2),
        }
    (b.OUT/'ocr_adaptive_profile_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
